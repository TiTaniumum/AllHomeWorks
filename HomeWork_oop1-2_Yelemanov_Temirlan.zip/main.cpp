#include <iostream>
#include <string>
#include <fstream>
#include "problem1.h"
#include "problem2.h"
using namespace std;


int main() {
  //problem1();
  problem2();
}