#include <iostream>
#include <string>
#include <algorithm>
#include <stdlib.h>
#include <random>
#include "win10.h"
using namespace std;

string mainMenu[]{
  "StartGame",
  "Settings",
  "About",
  "Exit"
};

string settingMenu[]{
  "Random generation of a Pole",
};

int row = 10, col = 50;
int mainMenulength = sizeof(mainMenu) / sizeof(mainMenu[0]);
int settingLength = sizeof(settingMenu) / sizeof(settingMenu[0]);

int menu(string *m,int length, int row, int col, int select = 0);
void settings(string* m, int length, int row, int col);
void about();
void game();

int main() {
  srand(time(NULL));
  int select = 0;
  while (true) {
    switch (menu(mainMenu, mainMenulength, row, col, select)) {
    case 0:
      game();
      break;
    case 1:
      settings(settingMenu, settingLength, row, col);
      break;
    case 2:
      about();
      break;
    case 3:
    case -1:
      SetColor(0, 7);
      return 0;
    }
  }
}

void about() {
  SetPos(10, 50);
  SetColor(7, 0);
  cout << " Maid by Yelemanov Temrlan ";
  SetPos(11, 50);
  cout << "  Idea owner John Conway  ";
  SetPos(12, 49);
  cout << " started making in 16.09.2022 ";
  SetPos(15, 50);
  cout << "                    controls:                            ";
  SetPos(16, 50);
  cout << " Hold ENTER To progress                                  ";
  SetPos(17, 50);
  cout << " Or press ENTER one time to progress one step            ";
  SetPos(18, 50);
  cout << " press SPACE to edit the pole by mouse                   ";
  SetPos(19, 50);
  cout << " Hold left mouse button to draw                          ";
  SetPos(20, 50);
  cout << " press ENTER while editting to change mode (draw, erase) ";
  SetPos(21, 50);
  cout << " press SPACE again to exit editting mode                 ";
  SetPos(22, 50);
  cout << " press ESC to exit the game                              ";
  SetPos(24, 50);
  cout << "                               game rules:                                      ";
  SetPos(25, 50);
  cout << " cell that has 2 naighbours will stay alive or stay dead                        ";
  SetPos(26, 50);
  cout << " cell that has 3 naighbours will be born                                        ";
  SetPos(27, 50);
  cout << " cell that has less than 2 or more than 3 naighbours will die                   ";
  SetPos(28, 50);
  cout << " black cells are dead                                                           ";
  SetPos(29, 50);
  cout << " white cells are alive                                                          ";
  SetPos(30, 50);
  cout << " there is no goal in this game, it's just satisfing to watch. it's life sim  :) ";
  SetPos(32, 50);
  cout << " in case you can't draw you have to toggle down mouse selection in cmd settings ";
  SetColor(0, 7);
  cin.get();
}