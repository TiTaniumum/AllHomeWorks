﻿using csharp2;
using System;
using System.Data;

namespace HomeWork2
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            Problem1 problem1 = new Problem1();
            problem1.Start();
            Problem2 problem2 = new Problem2();
            problem2.Start();
            Problem3 problem3 = new Problem3();
            problem3.Start();
            Problem4 problem4 = new Problem4();
            problem4.Start();
        }
    }
}