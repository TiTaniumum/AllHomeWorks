﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Преобразовать массив так, чтобы сначала шли все
//отрицательные элементы, а потом положительные
//(0 считать положительным)

namespace csharp2
{
    public class Problem2
    {
        private int[] nums;
        private void Init()
        {
            Random random = new Random();
            nums = new int[20];
            for (int i = 0; i < nums.Length; i++)
            {
                nums[i] = random.Next(-3,3);
            }
        }
        private void SortBySign()
        {
            int[]temp = new int[nums.Length];
            int cnt = 0;
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] < 0) temp[cnt++] = nums[i];
            }
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i]>=0) temp[cnt++] = nums[i];
            }
            nums = temp;
        }
        public void Start()
        {
            Console.WriteLine("Problem2: ");
            Init();
            Console.Write("Before sort: ");
            Problem1.Print(nums);
            SortBySign();
            Console.Write("After  sort: ");
            Problem1.Print(nums);
        }
    }
}
