﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Написать программу, которая предлагает пользова-
//телю ввести число и считает, сколько раз это число
//встречается в массиве

namespace csharp2
{
    public class Problem3
    {
        private int[] nums;
        private void Init()
        {
            Random random = new Random();
            nums = new int[100];
            for (int i = 0; i < nums.Length; i++)
            {
                nums[i] = random.Next(20);
            }
        }
        static public int GetNumFromUser()
        {
            int num = 0;
            string userText = "";
            bool isSuccess = false;
            while (!isSuccess) {
                Console.WriteLine("Type in some int num: ");
                userText = Console.ReadLine();
                if(int.TryParse(userText, out num))
                {
                    isSuccess = true;
                }
                else
                {
                    Console.WriteLine("Not a number or out of int range! try again.");
                }
            }
            return num;
        }
        private int SearchByIntValue(int val)
        {
            int cnt = 0;
            for (int i = 0; i < nums.Length; i++)
            {
                cnt = nums[i] == val ? ++cnt : cnt;
            }
            return cnt;
        }
        public void Start() { 
            Console.WriteLine("Problem3: ");
            Init();
            Problem1.Print(nums);
            Console.WriteLine("Count result: " + SearchByIntValue(GetNumFromUser()));
        }
    }
}
