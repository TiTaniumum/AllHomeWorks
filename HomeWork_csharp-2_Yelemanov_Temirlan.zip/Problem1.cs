﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Сжать массив, удалив из него все 0 и, заполнить ос-
//вободившиеся справа элементы значениями –1

namespace csharp2
{
    public class Problem1
    {
        private int[] nums;
        private void Init()
        {
            Random random= new Random();    
            nums = new int[20];
            for (int i = 0; i < nums.Length; i++)
            {
                nums[i] = random.Next(3);
            }
        }
        private void SortZeroes()
        {
            int cnt = 0;
            for (int i = 0; i < nums.Length; ++i)
            {
                if (nums[i] == 0) {
                    ++cnt;
                }
                else
                {
                    nums[i-cnt] = nums[i];
                }
            }
            for (int i = nums.Length-cnt; i < nums.Length; i++)
            {
                nums[i] = -1;
            }
        }
        static public void Print(int[]nums)
        {
            
            for (int i = 0; i < nums.Length; ++i)
            {
                if(i%20 == 0) Console.WriteLine();
                Console.Write(nums[i] + " ");
            }
            Console.WriteLine();
        }
        public void Start()
        {
            Console.WriteLine("Problem1: ");
            Init();
            Console.Write("Before Sort: ");
            Print(nums);
            SortZeroes();
            Console.Write("After  Sort: ");
            Print(nums);
        }
    }
}
