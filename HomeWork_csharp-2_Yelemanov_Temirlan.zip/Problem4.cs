﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//В двумерном массиве порядка M на N поменяйте
//местами заданные столбцы

namespace csharp2
{
    public class Problem4
    {
        private int[][] arr;
        private void Init() {
            int M = 5;
            int N = 5;
            arr = new int[M][];
            Random r = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = new int[N];
                for (int j = 0; j < arr[i].Length; j++)
                {
                    arr[i][j] = r.Next(5);
                }
            }
        }
        private void ReverceColumns()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Array.Reverse(arr[i]);
            }
        }
        public void Print()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Problem1.Print(arr[i]);
            }
        }
        public void Start()
        {
            Console.WriteLine("Problem4: ");
            Init();
            Console.WriteLine("Before revercing columns: ");
            Print();
            ReverceColumns();
            Console.WriteLine("After revercing columns: ");
            Print();
        }
    }
}
