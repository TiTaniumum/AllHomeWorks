﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace winformsWPF11
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CreateField();
        }

        private Image image;
        private ImageBrush imageBrush;
        double ScaleX, ScaleY;  // масштабные коэффициенты

        private void CreateField()
        {
            image = new Image
            {
                Source =
              new BitmapImage(
                new Uri("clipart-field.png", UriKind.Relative)
              )
            };
            imageBrush = new ImageBrush();
            imageBrush.Stretch = Stretch.None;
            imageBrush.ImageSource = image.Source; // bmp
            imageBrush.AlignmentX = AlignmentX.Left;
            imageBrush.AlignmentY = AlignmentY.Top;

            double x = 0, y = 0;
            ScaleX = 1.0 / imageBrush.ImageSource.Width;
            ScaleY = 1.0 / imageBrush.ImageSource.Height;
            
            Scrolling(x, y);
        }

        private void Window_KeyDown(object sender,
          KeyEventArgs e)
        {
            this.Title = e.Key.ToString();
            double x = imageBrush.Viewbox.X;
            double y = imageBrush.Viewbox.Y;
            double dx = ScaleX * 10; // на 10 пикселов по X
            double dy = ScaleY * 10; // на 10 пикселов по Y
            if (e.Key == Key.Up) { y -= dy; }
            else if (e.Key == Key.Down) { y += dy; }
            else if (e.Key == Key.Left) { x -= dx; }
            else if (e.Key == Key.Right) { x += dx; }
            if (x >= 0 && y >= 0 &&
              x < 1.0 - imageBrush.Viewbox.Width &&
              y < 1.0 - imageBrush.Viewbox.Height)
            {
                Scrolling(x, y);
            }
        }

        private void UpdateScale()
        {
            ScaleX = 1.0 / imageBrush.ImageSource.Width;
            ScaleY = 1.0 / imageBrush.ImageSource.Height;
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            imageBrush.ImageSource = new BitmapImage(new Uri("clipart-field.png", UriKind.Relative));
            UpdateScale();
        }

        private void MenuItem2_Click(object sender, RoutedEventArgs e)
        {
            imageBrush.ImageSource = new BitmapImage(new Uri("Cave.png", UriKind.Relative));
            UpdateScale();
        }

        private void MenuItem3_Click(object sender, RoutedEventArgs e)
        {
            imageBrush.ImageSource = new BitmapImage(new Uri("map.png", UriKind.Relative));
            UpdateScale();
        }

        private void MenuItem4_Click(object sender, RoutedEventArgs e)
        {
            imageBrush.ImageSource = new BitmapImage(new Uri("Skyrim.png", UriKind.Relative));
            UpdateScale();
        }

        private void MenuItem5_Click(object sender, RoutedEventArgs e)
        {
            imageBrush.ImageSource = new BitmapImage(new Uri("StarDewValley.png", UriKind.Relative));
            UpdateScale();
        }

        private void MenuItem6_Click(object sender, RoutedEventArgs e)
        {
            imageBrush.ImageSource = new BitmapImage(new Uri("ThedasMap.png", UriKind.Relative));
            UpdateScale();
        }

        private void Scrolling(double x, double y)
        {
            double width = canvas.ActualWidth * ScaleX;
            double height = canvas.ActualHeight * ScaleY;
            imageBrush.Viewbox = new Rect(x, y, width, height);
            canvas.Background = imageBrush;
        }
    }
}
