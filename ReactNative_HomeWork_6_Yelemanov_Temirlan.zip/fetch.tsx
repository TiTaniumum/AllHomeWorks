export enum WeatherType {
  standard = 'standard',
  metric = 'metric',
  imperial = 'imperial',
}

export async function fetchWeather<Type>(city: string, weatherType: WeatherType = WeatherType.metric): Promise<Awaited<Type | null>> {
  try {
    const api = "cddeb6aba3195facd31fcdde86d70713";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${api}&units=${weatherType}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("404");
    }
    const data = await response.json();
    console.info(data);
    return data;
  } catch (ex) {
    console.error("Ошибка при загрузки API: ", ex);
  }
  return null;
}