import AsyncStorage from "@react-native-async-storage/async-storage";
import { NavigationContainer, useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { View, Text, Button, StyleSheet, Image } from "react-native";
import { WeatherType, fetchWeather } from "../fetch";
import { CommonCity } from "./Selection";

export interface WeatherData {
  main: {
    temp: number;
    feels_like: number;
    grnd_level: number;
    humidity: number;
    pressure: number;
    sea_level: number;
    temp_max: number;
    temp_min: number;
  };
  weather: {
    main: string;
    description: string;
    icon: string;
  }[];
}

// cddeb6aba3195facd31fcdde86d70713

export default function Weather({ navigation }: any) {
  const [city, setCity] = useState<CommonCity | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);

  async function fetchCity() {
    const jsonCity = await AsyncStorage.getItem("city");
    if (jsonCity) {
      const savedCity: CommonCity = JSON.parse(jsonCity);
      setCity(savedCity);
      const data = await fetchWeather<WeatherData>(
        savedCity.city,
        savedCity.weatherType
      );
      setWeather(data);
    } else {
      navigation.navigate("Selection");
    }
  }

  function getSymbolByMetric(weatherType: WeatherType) {
    switch (weatherType) {
      case WeatherType.imperial:
        return "F°";
      case WeatherType.metric:
        return "C°";
      case WeatherType.standard:
        return "K°";
    }
  }

  useFocusEffect(
    useCallback(() => {
      fetchCity();
    }, [])
  );

  return (
    <View style={styles.container}>
      <Text style={{fontSize: 25}}>{city?.city}</Text>
      {weather ? (
        <View style={styles.subContainer}>
          <View style={{ flexDirection: "row" }}>
            <Image
              style={styles.image}
              source={{
                uri: `https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`,
              }}
            />
            <View style={styles.subContainer}>
              <Text style={styles.text}>
                {weather.main.temp}{" "}
                {city ? getSymbolByMetric(city.weatherType) : ""}
              </Text>
              <Text style={styles.text}>{weather.weather[0].main}</Text>
            </View>
          </View>
          <View>
            <Text style={styles.text}>Ощущается как: {weather.main.feels_like} {city ? getSymbolByMetric(city.weatherType) : ""}</Text>
            <Text style={styles.text}>Давление: {weather.main.pressure}</Text>
            <Text style={styles.text}>
              Минимальная температура: {weather.main.temp_min}{" "}
              {city ? getSymbolByMetric(city.weatherType) : ""}
            </Text>
            <Text style={styles.text}>
              Максимальная температура: {weather.main.temp_max}{" "}
              {city ? getSymbolByMetric(city.weatherType) : ""}
            </Text>
          </View>
        </View>
      ) : (
        <Text style={styles.text}>Загрузка данных</Text>
      )}
      <Button
        title="Сохраненные города"
        onPress={() => {
          navigation.navigate("CityList");
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    gap: 20,
  },
  subContainer: {
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    gap: 20,
  },
  image: {
    height: 140,
    width: 140,
  },
  text:{
    fontSize: 15
  }
});
