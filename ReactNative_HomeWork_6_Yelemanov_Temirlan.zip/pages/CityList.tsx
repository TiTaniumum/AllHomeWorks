import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState, useEffect } from "react";
import { FlatList, View, Text, Button, Pressable, StyleSheet} from "react-native";
import { WeatherData } from "./Weather";
import { WeatherType, fetchWeather } from "../fetch";
import { CommonCity } from "./Selection";

interface City{
    city: string;
    weatherType: WeatherType;
    temp: number | null;
}

export default function CityList({navigation}:any){
    const [cities, setCitites] = useState<City[]>([]);
    const fetchCities = async()=>{
        const savedCities = await AsyncStorage.getItem('cities');
        if(savedCities){
            let arr: CommonCity[] = JSON.parse(savedCities);
            let res: City[] = [];
            for(let i = 0; i < arr.length; i++){
                let weather = await fetchWeather<WeatherData>(arr[i].city, arr[i].weatherType);
                let obj = {city: arr[i].city, weatherType: arr[i].weatherType, temp: (weather ? weather.main.temp : null)} as City;
                res.push(obj);
            }
            setCitites(res);
        }
    };
    useEffect(()=>{
        fetchCities();
    },[]);

    async function selectCity(city: CommonCity){
        await AsyncStorage.setItem('city', JSON.stringify(city));
        navigation.navigate('Weather');
    }

    async function deleteCity(cityName: string){
        let modifiedCities = cities.filter((item)=>item.city != cityName);
        await AsyncStorage.setItem('cities',JSON.stringify(modifiedCities));
        setCitites(modifiedCities);
    }

    async function changeMetric(cityName:string, weatherType: WeatherType) {

        let cityToChange = cities.find((item)=>item.city === cityName);
        if(cityToChange){
            cityToChange.weatherType = weatherType;
        }
        await AsyncStorage.setItem('cities',JSON.stringify(cities));
        fetchCities();
    }

    function getSymbolByMetric(weatherType: WeatherType){
        switch(weatherType){
            case WeatherType.imperial: return 'F°';
            case WeatherType.metric: return 'C°';
            case WeatherType.standard: return 'K°';
        }
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={cities}
                keyExtractor={(item)=>item.city}
                renderItem={({item})=>(
                    <View style={styles.weatherItem}>
                        <Pressable style={styles.button} onPress={()=>{selectCity({city: item.city, weatherType: item.weatherType})}}>
                            <Text>{item.city}</Text>
                            <Text>{item.temp} {getSymbolByMetric(item.weatherType)}</Text>
                        </Pressable>
                        <Pressable style={styles.button} onPress={()=>{changeMetric(item.city, WeatherType.imperial)}}>
                            <Text>{WeatherType.imperial}</Text>
                        </Pressable>
                        <Pressable style={styles.button} onPress={()=>{changeMetric(item.city, WeatherType.metric)}}>
                            <Text>{WeatherType.metric}</Text>
                        </Pressable>
                        <Pressable style={styles.button} onPress={()=>{changeMetric(item.city, WeatherType.standard)}}>
                            <Text>{WeatherType.standard}</Text>
                        </Pressable>
                        <Pressable style={styles.button} onPress={()=>{deleteCity(item.city)}}>
                            <Text>Delete</Text>
                        </Pressable>
                    </View>
                )}
            />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    weatherItem: {
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 10,
        padding: 5,
        flexDirection: 'row',
    },
    button: {
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 10,
        padding: 5,
        alignItems: 'center',
        justifyContent: 'center',
    }
});