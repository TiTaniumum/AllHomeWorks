import AsyncStorage from "@react-native-async-storage/async-storage";
import { useState } from "react";
import { Button, TextInput, View, StyleSheet, Text } from "react-native";
import { WeatherType } from "../fetch";

export interface CommonCity {
  city: string;
  weatherType: WeatherType;
}

export default function Selection({ navigation }: any) {
  const [city, setCity] = useState("");

  async function saveCity() {
    const savedCities = await AsyncStorage.getItem("cities");
    const cities: CommonCity[] = savedCities ? JSON.parse(savedCities) : [];
    if (!cities.find((item) => item.city == city)) {
      cities.push({ city: city, weatherType: WeatherType.metric });
      await AsyncStorage.setItem("cities", JSON.stringify(cities));
    }
    await AsyncStorage.setItem(
      "city",
      JSON.stringify({ city: city, weatherType: WeatherType.metric })
    );
    navigation.navigate("Weather");
  }

  return (
    <View style={sytles.container}>
      <Text>Введите название города:</Text>
      <TextInput
        style={sytles.input}
        value={city}
        onChangeText={setCity}
        placeholder="..."
      />
      <Button title="Сохранить город" onPress={saveCity} />
    </View>
  );
}

const sytles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    gap: 20,
    padding: 30,
  },
  input: {
    borderWidth: 1,
    borderColor: "black",
    padding: 5,
    borderRadius: 10,
    width: '100%'
  }
});
