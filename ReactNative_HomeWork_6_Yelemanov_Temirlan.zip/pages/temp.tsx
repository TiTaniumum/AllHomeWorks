import { useState } from "react";
import { TextInput, View } from "react-native";


export default function temp(){
    const [text, setText] = useState("");

    console.log(text);

    return(
        <View>
            <TextInput onChangeText={setText} value= {text}/>
        </View>
    )
}