import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import React from "react";
import { StyleSheet, Text, View, Button, Pressable } from "react-native";

const RootStack = createNativeStackNavigator();
import Weather from "./pages/Weather";
import Selection from "./pages/Selection";
import CityList from "./pages/CityList";

export default function App() {
  return (
    <NavigationContainer>
      <RootStack.Navigator>
        <RootStack.Group>
          <RootStack.Screen
            name="Weather"
            component={Weather}
            options={({ navigation }) => ({
              headerRight: () => (
                <Pressable style={styles.button} onPress={() => navigation.navigate("Selection")}>
                  <Text style={{color: "white", fontWeight: 700, fontSize: 18}}>+ Добавить город</Text>
                </Pressable>
              ),
            })}
          />
        </RootStack.Group>
        <RootStack.Group screenOptions={{ presentation: "modal" }}>
          <RootStack.Screen
            name="CityList"
            component={CityList}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen
            name="Selection"
            component={Selection}
            options={({ navigation }) => ({})}
          />
        </RootStack.Group>
      </RootStack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  button: {
    padding:10,
    // height: 30,
    // width: 30,
    borderRadius: 100,
    backgroundColor: '#00bfff',
    alignItems: 'center',
    justifyContent: 'center'
  }
});
