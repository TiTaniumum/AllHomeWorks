<?php
// echo "$_SERVER[HTTP_HOST].$_SERVER[REQUEST_URI]";
// echo "<br>";
// switch ($_GET["action"]) {
//     case "product":
//         require_once("product.php");
//         break;
//     default:
//         require_once("notFound.php");
//         break;
// }

require_once "app/bootstrap.php";
?>
