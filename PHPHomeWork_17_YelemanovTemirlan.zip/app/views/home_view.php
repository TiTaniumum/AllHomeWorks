<?php 
$isAdmin = true;
$return = new stdClass;
if($isAdmin){
    $return->actions = $json;
    $return->status = $code;
}else{
    $return = $json;
}
echo json_encode($return, JSON_PRETTY_PRINT);
?>