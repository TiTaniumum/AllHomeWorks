<?php 
header("Content-type: application/json;charset=utf-8");
include("app/views/$view");
?>