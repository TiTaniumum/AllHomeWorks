<?php 
interface Model{
    public function getData();
    public function insertData();
}
?>