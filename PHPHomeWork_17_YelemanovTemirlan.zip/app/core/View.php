<?php 
class View{
    public function generate($view, $template, $data = null){
        include("app/views/$template");
    }
}
?>