<?php 
class Model_Home implements Model{
    function getdata(){
        $acceptLang = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0,2);
        return array(
            "json" => "object",
            "code" => 200
        );
    } 
    public function insertData()
    {
        
    }
}
?>