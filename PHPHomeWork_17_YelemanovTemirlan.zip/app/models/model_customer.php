<?php 
class Model_customer implements Model{
    public function getData()
    {
        if(isset($_GET["id"])){
            $sql = "SELECT * FROM customers WHERE customerId = ?;";
            return Database::getRow($sql, $_GET["id"]);
        }else{
            $sql = "SELECT * FROM customers;";
            return Database::getAll($sql);
        }
    }
    public function insertData()
    {
        $data = json_decode(file_get_contents("php://input"));

        $sql = "INSERT INTO customers(
            addressLine1,
            addressLine2,
            city,
            contactFirstName,
            contactLastName,
            country,
            customerName,
            phone,
            postalCode,
            salesRepemployeeId,
            state) values(:addressLine1,:addressLine2,:city,:contactFirstName,:contactLastName,:country,:customerName,:phone,:postalCode,:salesRepemployeeId,:state);";

        $array = [];
        $array["addressLine1"] = $data->addressLine1;
        $array["addressLine2"] = $data->addressLine2;
        $array["city"] = $data->city;
        $array["contactFirstName"] = $data->contactFirstName;
        $array["contactLastName"] = $data->contactLastName;
        $array["country"] = $data->country;
        $array["customerName"] = $data->customerName;
        $array["phone"] = $data->phone;
        $array["postalCode"] = $data->postalCode;
        $array["salesRepemployeeId"] = $data->salesRepemployeeId !== "0" ? (int) $data->salesRepemployeeId : null;
        $array["state"] = $data->state;

        $lastId = Database::insert($sql, $array);
        return '{"lastid": "'."$lastId".'"}';
    }
}
?>