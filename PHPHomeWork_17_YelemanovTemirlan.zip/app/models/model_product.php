<?php
class Model_Product implements Model
{
    public function getData()
    {
        if(isset($_GET["id"])){
            $sql = "SELECT * FROM products WHERE productId = ?;";
            return Database::getRow($sql, $_GET["id"]);
        }else{
            $sql = "SELECT * FROM products;";
            return Database::getAll($sql);
        }
    }
    public function insertData(){
        $data = json_decode(file_get_contents("php://input"));
        $sql = "INSERT INTO products(
        productId,
        productName,
        productLine,
        productScale,
        productVendor,
        productDescription,
        quantityInStock,
        buyPrice,
        MSRP)
        values
        (
        :productId,
        :productName,
        :productLine,
        :productScale,
        :productVendor,
        :productDescription,
        :quantityInStock,
        :buyPrice,
        :MSRP
        )";
        $array = [];
        $array["productId"] = $data->productId;
        $array["productName"] = $data->productName;
        $array["productLine"] = $data->productLine;
        $array["productScale"] = $data->productScale;
        $array["productVendor"] = $data->productVendor;
        $array["productDescription"] = $data->productDescription;
        $array["quantityInStock"] = $data->quantityInStock;
        $array["buyPrice"] = $data->buyPrice;
        $array["MSRP"] = $data->MSRP;
        $lastId = Database::insert($sql, $array);
        return '{"lastid": "'."$lastId".'"}';
    }
}
?>