<?php 
class Model_office implements Model{
    public function getData(){
        if(isset($_GET["id"])){
            $sql = "SELECT * FROM offices WHERE officeId = ?;";
            return Database::getRow($sql, $_GET["id"]);
        }else{
            $sql = "SELECT * FROM offices;";
            return Database::getAll($sql);
        }
    }
    public function insertData(){
        $data = json_decode(file_get_contents("php://input"));

        $sql = "INSERT INTO offices(
        officeId,
        city,
        phone,
        addressLine1,
        addressLine2,
        state,
        country,
        postalCode,
        territory) VALUES(
        :officeId,
        :city,
        :phone,
        :addressLine1,
        :addressLine2,
        :state,
        :country,
        :postalCode,
        :territory)";

        $array = [];
        $array["officeId"] = $data->officeId;
        $array["city"] = $data->city;
        $array["phone"] = $data->phone;
        $array["addressLine1"] = $data->addressLine1;
        $array["addressLine2"] = $data->addressLine2;
        $array["state"] = $data->state;
        $array["country"] = $data->country;
        $array["postalCode"] = $data->postalCode;
        $array["territory"] = $data->territory;

        $lastId = Database::insert($sql, $array);
        return '{"lastid": "'."$lastId".'"}';
    }
}

?>