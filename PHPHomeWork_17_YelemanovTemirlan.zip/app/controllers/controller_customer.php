<?php 
class Controller_customer extends Controller{
    public function __construct(){
        $this->model = new Model_customer;
        parent::__construct();
    }
    public function action_index(){
        $data = $this->model->getData();
        $this->view->generate("echoJson_view.php","template_view.php", $data);
    }
    public function action_insert(){
        $data = $this->model->insertData();
        $this->view->generate("echoJson_view.php", "template_view.php", $data);
    }
}
?>