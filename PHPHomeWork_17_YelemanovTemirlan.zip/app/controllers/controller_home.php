<?php 
class Controller_Home extends Controller{
    public function __construct(){
        $this->model = new Model_Home;
        parent::__construct();
    }
    private function localization($data){
        if(isset($_GET["lang"])){
            $lang = $_GET["lang"];
        }else{
            $acceptLang = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0,2);
            $supportedLang = ["en","kk","uk","ru"];
            $lang = in_array($acceptLang, $supportedLang) ? $acceptLang : "en";
        }
        $data["lang"] = $lang;
        return $data;
    }
    function action_index(){
        $data = $this->model->getData();
        $data = $this->localization($data);
        $this->view->generate("home_view.php","template_view.php", $data);
    }
    function action_about(){
        $data = $this->model->getData();
        $this->view->generate("home_view.php","template_view.php", $data);
    }
}
?>