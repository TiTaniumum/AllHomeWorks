<?php 
class Controller_Product extends Controller {
    public function __construct(){
        $this->model = new Model_Product;
        parent::__construct();
    }
    function action_index(){
        $data = $this->model->getData();
        $this->view->generate("echoJson_view.php","template_view.php", $data);
    }
    function action_insert(){
        $data = $this->model->insertData();
        $this->view->generate("echoJson_view.php", "template_view.php", $data);
    }
}
?>