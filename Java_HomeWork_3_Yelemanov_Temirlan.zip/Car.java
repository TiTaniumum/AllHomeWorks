// Реализуйте класс «Автомобиль». Необходимо хранить 
// в полях класса: название автомобиля, название производителя, 
// год выпуска, объём двигателя. Реализуйте конструкторы и методы класса для ввода данных, вывода данных, 
// реализуйте доступ к отдельным полям через методы класса. 
// Используйте механизм перегрузки методов.
import java.util.Date;
public class Car {
    private String name;
    private String manufacturer;
    private Date publishDate;
    private int fuelVolume;
    public Car() {
    }
    public Car(String name, String manufacturer, Date publishDate, int fuelVolume){
        this.name = name;
        this.manufacturer = manufacturer;
        this.publishDate = publishDate;
        this.fuelVolume = fuelVolume;
    }
    public String getName() {
        return name;
    }
    public int getFuelVolume() {
        return fuelVolume;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    public Date getPublishDate() {
        return publishDate;
    }
    public void setFuelVolume(int fuelVolume) {
        this.fuelVolume = fuelVolume;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }
}
