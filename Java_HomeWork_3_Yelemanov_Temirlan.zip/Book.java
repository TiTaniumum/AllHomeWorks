// еализуйте класс «Книга». Необходимо хранить в полях класса: название книги, ФИО автора, год выпуска, 
// название издательства, жанр книги, количество страниц. 
// Реализуйте конструкторы и методы класса для ввода 
// данных, вывода данных, реализуйте доступ к отдельным 
// полям через методы класса. Используйте механизм перегрузки методов
import java.util.Date;

public class Book {
    private String name;
    private String auth;
    private Date publishDate;
    private String publisher;
    private String genre;
    private int pageCount;

    public Book(){

    }
    public Book(String name,String auth,Date publishDate, String publisher, String genre, int pageCount) {
        super();
        this.name = name;
        this.auth = auth;
        this.publishDate = publishDate;
        this.publisher = publisher;
        this.genre = genre;
        this.pageCount = pageCount;
    }
    public String getName() {
        return name;
    }
    public String getAuth() {
        return auth;
    }
    public Date getPublishDate() {
        return publishDate;
    }
    public String getPublisher() {
        return publisher;
    }
    public String getGenre() {
        return genre;
    }
    public int getPageCount() {
        return pageCount;
    }
    public void setAuth(String auth) {
        this.auth = auth;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
}
