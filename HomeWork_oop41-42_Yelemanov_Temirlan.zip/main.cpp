#include "Win10.h"
#include "problem1.h"
#include "problem2.h"
#include "Game.h"

int main() {
  Game game;
  game.Start();
}