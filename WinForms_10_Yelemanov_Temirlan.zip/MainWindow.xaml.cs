﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace winformsWPF10
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random random = new Random();
        public MainWindow()
        {
            InitializeComponent();
            TextBoxCurrentText.Text = GenerateText();
            TextBoxUserText.Background = new SolidColorBrush(Colors.White);
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.A: PressBtn(ButtonA); break;
                case Key.B: PressBtn(ButtonB); break;
                case Key.C: PressBtn(ButtonC); break;
                case Key.D: PressBtn(ButtonD); break;
                case Key.E: PressBtn(ButtonE); break;
                case Key.F: PressBtn(ButtonF); break;
                case Key.G: PressBtn(ButtonG); break;
                case Key.H: PressBtn(ButtonH); break;
                case Key.I: PressBtn(ButtonI); break;
                case Key.J: PressBtn(ButtonJ); break;
                case Key.K: PressBtn(ButtonK); break;
                case Key.L: PressBtn(ButtonL); break;
                case Key.M: PressBtn(ButtonM); break;
                case Key.N: PressBtn(ButtonN); break;
                case Key.O: PressBtn(ButtonO); break;
                case Key.P: PressBtn(ButtonP); break;
                case Key.Q: PressBtn(ButtonQ); break;
                case Key.R: PressBtn(ButtonR); break;
                case Key.S: PressBtn(ButtonS); break;
                case Key.T: PressBtn(ButtonT); break;
                case Key.U: PressBtn(ButtonU); break;
                case Key.V: PressBtn(ButtonV); break;
                case Key.W: PressBtn(ButtonW); break;
                case Key.X: PressBtn(ButtonX); break;
                case Key.Y: PressBtn(ButtonY); break;
                case Key.Z: PressBtn(ButtonZ); break;
                case Key.OemTilde: PressBtn(ButtonGravis); break;
                case Key.D0: PressBtn(Button0);break;
                case Key.D1: PressBtn(Button1);break;
                case Key.D2: PressBtn(Button2);break;
                case Key.D3: PressBtn(Button3);break;
                case Key.D4: PressBtn(Button4);break;
                case Key.D5: PressBtn(Button5);break;
                case Key.D6: PressBtn(Button6);break;
                case Key.D7: PressBtn(Button7);break;
                case Key.D8: PressBtn(Button8);break;
                case Key.D9: PressBtn(Button9);break;
                case Key.OemMinus: PressBtn(ButtonMinus); break;
                case Key.OemPlus: PressBtn(ButtonEqual); break;
                case Key.Back: PressBtn(ButtonBackspace); break;
                case Key.Tab: PressBtn(ButtonTab); break;
                case Key.OemOpenBrackets: PressBtn(ButtonOpeningBracket); break;
                case Key.OemCloseBrackets: PressBtn(ButtonClosingBracket); break;
                case Key.OemPipe: PressBtn(ButtonLeftSlash); break;
                case Key.CapsLock: ActivateBtn(ButtonCapsLK); break;
                case Key.OemSemicolon: PressBtn(ButtonSemicolon); break;
                case Key.OemQuotes: PressBtn(ButtonApostrophe); break;
                case Key.Enter: PressBtn(ButtonEnter); break;
                case Key.LeftShift: PressBtn(ButtonShiftLeft); break;
                case Key.RightShift: PressBtn(ButtonShiftRight);  break;
                case Key.LeftCtrl: PressBtn(ButtonCtrlLeft); break;
                case Key.RightCtrl:PressBtn(ButtonCtrlRight); break;
                case Key.LeftAlt: PressBtn(ButtonAltLeft); break;
                case Key.RightAlt: PressBtn(ButtonAltRight); break;
                case Key.Space: PressBtn(ButtonSpace); break;
                case Key.OemComma: PressBtn(ButtonComma); break;
                case Key.OemQuestion: PressBtn(ButtonSlashRight); break;
                case Key.OemPeriod: PressBtn(ButtonDot); break;
            }
        }
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.A: ReleaseBtn(ButtonA); break;
                case Key.B: ReleaseBtn(ButtonB); break;
                case Key.C: ReleaseBtn(ButtonC); break;
                case Key.D: ReleaseBtn(ButtonD); break;
                case Key.E: ReleaseBtn(ButtonE); break;
                case Key.F: ReleaseBtn(ButtonF); break;
                case Key.G: ReleaseBtn(ButtonG); break;
                case Key.H: ReleaseBtn(ButtonH); break;
                case Key.I: ReleaseBtn(ButtonI); break;
                case Key.J: ReleaseBtn(ButtonJ); break;
                case Key.K: ReleaseBtn(ButtonK); break;
                case Key.L: ReleaseBtn(ButtonL); break;
                case Key.M: ReleaseBtn(ButtonM); break;
                case Key.N: ReleaseBtn(ButtonN); break;
                case Key.O: ReleaseBtn(ButtonO); break;
                case Key.P: ReleaseBtn(ButtonP); break;
                case Key.Q: ReleaseBtn(ButtonQ); break;
                case Key.R: ReleaseBtn(ButtonR); break;
                case Key.S: ReleaseBtn(ButtonS); break;
                case Key.T: ReleaseBtn(ButtonT); break;
                case Key.U: ReleaseBtn(ButtonU); break;
                case Key.V: ReleaseBtn(ButtonV); break;
                case Key.W: ReleaseBtn(ButtonW); break;
                case Key.X: ReleaseBtn(ButtonX); break;
                case Key.Y: ReleaseBtn(ButtonY); break;
                case Key.Z: ReleaseBtn(ButtonZ); break;
                case Key.OemTilde: ReleaseBtn(ButtonGravis); break;
                case Key.D0: ReleaseBtn(Button0); break;
                case Key.D1: ReleaseBtn(Button1); break;
                case Key.D2: ReleaseBtn(Button2); break;
                case Key.D3: ReleaseBtn(Button3); break;
                case Key.D4: ReleaseBtn(Button4); break;
                case Key.D5: ReleaseBtn(Button5); break;
                case Key.D6: ReleaseBtn(Button6); break;
                case Key.D7: ReleaseBtn(Button7); break;
                case Key.D8: ReleaseBtn(Button8); break;
                case Key.D9: ReleaseBtn(Button9); break;
                case Key.OemMinus: ReleaseBtn(ButtonMinus); break;
                case Key.OemPlus: ReleaseBtn(ButtonEqual); break;
                case Key.Back: ReleaseBtn(ButtonBackspace); break;
                case Key.Tab: ReleaseBtn(ButtonTab); break;
                case Key.OemOpenBrackets: ReleaseBtn(ButtonOpeningBracket); break;
                case Key.OemCloseBrackets: ReleaseBtn(ButtonClosingBracket); break;
                case Key.OemPipe: ReleaseBtn(ButtonLeftSlash); break;
                case Key.OemSemicolon: ReleaseBtn(ButtonSemicolon); break;
                case Key.OemQuotes:    ReleaseBtn(ButtonApostrophe); break;
                case Key.Enter:        ReleaseBtn(ButtonEnter); break;
                case Key.LeftShift:    ReleaseBtn(ButtonShiftLeft); break;
                case Key.RightShift:   ReleaseBtn(ButtonShiftRight); break;
                case Key.LeftCtrl:     ReleaseBtn(ButtonCtrlLeft); break;
                case Key.RightCtrl:    ReleaseBtn(ButtonCtrlRight); break;
                case Key.LeftAlt:      ReleaseBtn(ButtonAltLeft); break;
                case Key.RightAlt:     ReleaseBtn(ButtonAltRight); break;
                case Key.Space:        ReleaseBtn(ButtonSpace); break;
                case Key.OemComma:     ReleaseBtn(ButtonComma); break;
                case Key.OemQuestion:  ReleaseBtn(ButtonSlashRight); break;
                case Key.OemPeriod:    ReleaseBtn(ButtonDot); break;
            }
        }
        private void ActivateBtn(Button btn)
        {
            byte A = (btn.Background as SolidColorBrush).Color.A;
            byte R = (btn.Background as SolidColorBrush).Color.R;
            byte G = (btn.Background as SolidColorBrush).Color.G;
            byte B = (btn.Background as SolidColorBrush).Color.B;
            if(A == 0)
            {
                A = 255;
            }
            else
            {
                A = 0;
            }
            (btn.Background as SolidColorBrush).Color = Color.FromArgb(A, R, G, B);
        }
        private void PressBtn(Button btn)
        {
            byte A = (btn.Background as SolidColorBrush).Color.A;
            byte R = (btn.Background as SolidColorBrush).Color.R;
            byte G = (btn.Background as SolidColorBrush).Color.G;
            byte B = (btn.Background as SolidColorBrush).Color.B;
            A = Convert.ToByte((A+30)%256);
            (btn.Background as SolidColorBrush).Color = Color.FromArgb(A, R, G, B);
        }
        private void ReleaseBtn(Button btn)
        {
            byte A = (btn.Background as SolidColorBrush).Color.A;
            byte R = (btn.Background as SolidColorBrush).Color.R;
            byte G = (btn.Background as SolidColorBrush).Color.G;
            byte B = (btn.Background as SolidColorBrush).Color.B;
            A = 255;
            (btn.Background as SolidColorBrush).Color = Color.FromArgb(A, R, G, B);
        }

        private string GenerateWord()
        {
            int length = random.Next(1, 20);
            string word = string.Empty;
            for(int i=0; i< length; i++)
            {
                word+= (char)random.Next('a', 'z');
            }
            return word;
        }
        private string GenerateText()
        {
            int length = random.Next(1, 10);
            string text = string.Empty;
            for(int i=0; i<length; i++)
            {
                text+= GenerateWord();
                if (i== length-1) break;
                text+=" ";
            }
            return text;
        }

        private void TextBoxUserText_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(TextBoxUserText.Text == TextBoxCurrentText.Text)
            {
                TextBoxCurrentText.Text = GenerateText();
                TextBoxUserText.Text = string.Empty;
            }
            if (TextBoxCurrentText.Text.Contains(TextBoxUserText.Text))
            {
                TextBoxUserText.Background = new SolidColorBrush(Colors.LightGreen);
            }
            else
            {
                TextBoxUserText.Background = new SolidColorBrush(Colors.Red);
            }
        }
    }
}
