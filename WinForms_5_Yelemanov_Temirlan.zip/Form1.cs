﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HWwinforms5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitPole();
        }

        public void InitPole()
        {
            int cnt = 0;
            foreach (var item in Controls)
            {

                if (item is Panel)
                {
                    if(int.Parse(((item as Panel).Tag.ToString())[0].ToString())%2 == 0){
                        if(int.Parse(((item as Panel).Tag.ToString())[1].ToString())%2 == 0)
                        {
                            (item as Panel).BackColor = Color.White;
                        }
                        else
                        {
                            (item as Panel).BackColor = Color.Gray;
                        }
                    }
                    else{
                        if (int.Parse(((item as Panel).Tag.ToString())[1].ToString())%2 == 0)
                        {
                            (item as Panel).BackColor = Color.Gray;
                        }
                        else
                        {
                            (item as Panel).BackColor = Color.White;
                        }
                    }
                }
                
            }
        }
    }
}
