﻿namespace HWwinforms5
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(51, 44);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(73, 68);
            this.panel1.TabIndex = 0;
            this.panel1.Tag = "00";
            this.toolTip1.SetToolTip(this.panel1, "Rook");
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Location = new System.Drawing.Point(124, 44);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(73, 68);
            this.panel2.TabIndex = 1;
            this.panel2.Tag = "01";
            this.toolTip1.SetToolTip(this.panel2, "Knight");
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel3.Location = new System.Drawing.Point(270, 44);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(73, 68);
            this.panel3.TabIndex = 3;
            this.panel3.Tag = "03";
            this.toolTip1.SetToolTip(this.panel3, "Queen");
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel4.Location = new System.Drawing.Point(197, 44);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(73, 68);
            this.panel4.TabIndex = 2;
            this.panel4.Tag = "02";
            this.toolTip1.SetToolTip(this.panel4, "Bishop");
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel5.Location = new System.Drawing.Point(562, 44);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(73, 68);
            this.panel5.TabIndex = 7;
            this.panel5.Tag = "07";
            this.toolTip1.SetToolTip(this.panel5, "Rook");
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel6.Location = new System.Drawing.Point(489, 44);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(73, 68);
            this.panel6.TabIndex = 6;
            this.panel6.Tag = "06";
            this.toolTip1.SetToolTip(this.panel6, "Knight");
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel7.Location = new System.Drawing.Point(416, 44);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(73, 68);
            this.panel7.TabIndex = 5;
            this.panel7.Tag = "05";
            this.toolTip1.SetToolTip(this.panel7, "Bishop");
            // 
            // panel8
            // 
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel8.Location = new System.Drawing.Point(343, 44);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(73, 68);
            this.panel8.TabIndex = 4;
            this.panel8.Tag = "04";
            this.toolTip1.SetToolTip(this.panel8, "King");
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel9.Location = new System.Drawing.Point(562, 112);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(73, 68);
            this.panel9.TabIndex = 15;
            this.panel9.Tag = "17";
            this.toolTip1.SetToolTip(this.panel9, "Pawn");
            // 
            // panel10
            // 
            this.panel10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel10.BackgroundImage")));
            this.panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel10.Location = new System.Drawing.Point(270, 112);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(73, 68);
            this.panel10.TabIndex = 11;
            this.panel10.Tag = "13";
            this.toolTip1.SetToolTip(this.panel10, "Pawn");
            // 
            // panel11
            // 
            this.panel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel11.BackgroundImage")));
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel11.Location = new System.Drawing.Point(489, 112);
            this.panel11.Margin = new System.Windows.Forms.Padding(0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(73, 68);
            this.panel11.TabIndex = 14;
            this.panel11.Tag = "16";
            this.toolTip1.SetToolTip(this.panel11, "Pawn");
            // 
            // panel12
            // 
            this.panel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel12.BackgroundImage")));
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel12.Location = new System.Drawing.Point(416, 112);
            this.panel12.Margin = new System.Windows.Forms.Padding(0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(73, 68);
            this.panel12.TabIndex = 13;
            this.panel12.Tag = "15";
            this.toolTip1.SetToolTip(this.panel12, "Pawn");
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel13.Location = new System.Drawing.Point(197, 112);
            this.panel13.Margin = new System.Windows.Forms.Padding(0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(73, 68);
            this.panel13.TabIndex = 10;
            this.panel13.Tag = "12";
            this.toolTip1.SetToolTip(this.panel13, "Pawn");
            // 
            // panel14
            // 
            this.panel14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel14.BackgroundImage")));
            this.panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel14.Location = new System.Drawing.Point(343, 112);
            this.panel14.Margin = new System.Windows.Forms.Padding(0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(73, 68);
            this.panel14.TabIndex = 12;
            this.panel14.Tag = "14";
            this.toolTip1.SetToolTip(this.panel14, "Pawn");
            // 
            // panel15
            // 
            this.panel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel15.BackgroundImage")));
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel15.Location = new System.Drawing.Point(124, 112);
            this.panel15.Margin = new System.Windows.Forms.Padding(0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(73, 68);
            this.panel15.TabIndex = 9;
            this.panel15.Tag = "11";
            this.toolTip1.SetToolTip(this.panel15, "Pawn");
            // 
            // panel16
            // 
            this.panel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel16.BackgroundImage")));
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel16.Location = new System.Drawing.Point(51, 112);
            this.panel16.Margin = new System.Windows.Forms.Padding(0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(73, 68);
            this.panel16.TabIndex = 8;
            this.panel16.Tag = "10";
            this.toolTip1.SetToolTip(this.panel16, "Pawn");
            // 
            // panel17
            // 
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel17.Location = new System.Drawing.Point(562, 248);
            this.panel17.Margin = new System.Windows.Forms.Padding(0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(73, 68);
            this.panel17.TabIndex = 31;
            this.panel17.Tag = "37";
            // 
            // panel18
            // 
            this.panel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel18.Location = new System.Drawing.Point(562, 180);
            this.panel18.Margin = new System.Windows.Forms.Padding(0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(73, 68);
            this.panel18.TabIndex = 23;
            this.panel18.Tag = "27";
            // 
            // panel19
            // 
            this.panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel19.Location = new System.Drawing.Point(270, 248);
            this.panel19.Margin = new System.Windows.Forms.Padding(0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(73, 68);
            this.panel19.TabIndex = 27;
            this.panel19.Tag = "33";
            // 
            // panel20
            // 
            this.panel20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel20.Location = new System.Drawing.Point(270, 180);
            this.panel20.Margin = new System.Windows.Forms.Padding(0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(73, 68);
            this.panel20.TabIndex = 19;
            this.panel20.Tag = "23";
            // 
            // panel21
            // 
            this.panel21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel21.Location = new System.Drawing.Point(489, 248);
            this.panel21.Margin = new System.Windows.Forms.Padding(0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(73, 68);
            this.panel21.TabIndex = 30;
            this.panel21.Tag = "36";
            // 
            // panel22
            // 
            this.panel22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel22.Location = new System.Drawing.Point(489, 180);
            this.panel22.Margin = new System.Windows.Forms.Padding(0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(73, 68);
            this.panel22.TabIndex = 22;
            this.panel22.Tag = "26";
            // 
            // panel23
            // 
            this.panel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel23.Location = new System.Drawing.Point(416, 248);
            this.panel23.Margin = new System.Windows.Forms.Padding(0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(73, 68);
            this.panel23.TabIndex = 29;
            this.panel23.Tag = "35";
            // 
            // panel24
            // 
            this.panel24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel24.Location = new System.Drawing.Point(416, 180);
            this.panel24.Margin = new System.Windows.Forms.Padding(0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(73, 68);
            this.panel24.TabIndex = 21;
            this.panel24.Tag = "25";
            // 
            // panel25
            // 
            this.panel25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel25.Location = new System.Drawing.Point(197, 248);
            this.panel25.Margin = new System.Windows.Forms.Padding(0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(73, 68);
            this.panel25.TabIndex = 26;
            this.panel25.Tag = "32";
            // 
            // panel26
            // 
            this.panel26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel26.Location = new System.Drawing.Point(197, 180);
            this.panel26.Margin = new System.Windows.Forms.Padding(0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(73, 68);
            this.panel26.TabIndex = 18;
            this.panel26.Tag = "22";
            // 
            // panel27
            // 
            this.panel27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel27.Location = new System.Drawing.Point(343, 248);
            this.panel27.Margin = new System.Windows.Forms.Padding(0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(73, 68);
            this.panel27.TabIndex = 28;
            this.panel27.Tag = "34";
            // 
            // panel28
            // 
            this.panel28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel28.Location = new System.Drawing.Point(343, 180);
            this.panel28.Margin = new System.Windows.Forms.Padding(0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(73, 68);
            this.panel28.TabIndex = 20;
            this.panel28.Tag = "24";
            // 
            // panel29
            // 
            this.panel29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel29.Location = new System.Drawing.Point(124, 248);
            this.panel29.Margin = new System.Windows.Forms.Padding(0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(73, 68);
            this.panel29.TabIndex = 25;
            this.panel29.Tag = "31";
            // 
            // panel30
            // 
            this.panel30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel30.Location = new System.Drawing.Point(124, 180);
            this.panel30.Margin = new System.Windows.Forms.Padding(0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(73, 68);
            this.panel30.TabIndex = 17;
            this.panel30.Tag = "21";
            // 
            // panel31
            // 
            this.panel31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel31.Location = new System.Drawing.Point(51, 248);
            this.panel31.Margin = new System.Windows.Forms.Padding(0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(73, 68);
            this.panel31.TabIndex = 24;
            this.panel31.Tag = "30";
            // 
            // panel32
            // 
            this.panel32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel32.Location = new System.Drawing.Point(51, 180);
            this.panel32.Margin = new System.Windows.Forms.Padding(0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(73, 68);
            this.panel32.TabIndex = 16;
            this.panel32.Tag = "20";
            // 
            // panel33
            // 
            this.panel33.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel33.BackgroundImage")));
            this.panel33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel33.Location = new System.Drawing.Point(562, 520);
            this.panel33.Margin = new System.Windows.Forms.Padding(0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(73, 68);
            this.panel33.TabIndex = 63;
            this.panel33.Tag = "77";
            this.toolTip1.SetToolTip(this.panel33, "Rook");
            // 
            // panel34
            // 
            this.panel34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel34.Location = new System.Drawing.Point(562, 384);
            this.panel34.Margin = new System.Windows.Forms.Padding(0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(73, 68);
            this.panel34.TabIndex = 47;
            this.panel34.Tag = "57";
            // 
            // panel35
            // 
            this.panel35.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel35.BackgroundImage")));
            this.panel35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel35.Location = new System.Drawing.Point(562, 452);
            this.panel35.Margin = new System.Windows.Forms.Padding(0);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(73, 68);
            this.panel35.TabIndex = 55;
            this.panel35.Tag = "67";
            this.toolTip1.SetToolTip(this.panel35, "Pawn");
            // 
            // panel36
            // 
            this.panel36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel36.Location = new System.Drawing.Point(562, 316);
            this.panel36.Margin = new System.Windows.Forms.Padding(0);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(73, 68);
            this.panel36.TabIndex = 39;
            this.panel36.Tag = "47";
            // 
            // panel37
            // 
            this.panel37.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel37.BackgroundImage")));
            this.panel37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel37.Location = new System.Drawing.Point(270, 520);
            this.panel37.Margin = new System.Windows.Forms.Padding(0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(73, 68);
            this.panel37.TabIndex = 59;
            this.panel37.Tag = "73";
            this.toolTip1.SetToolTip(this.panel37, "Queen");
            // 
            // panel38
            // 
            this.panel38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel38.Location = new System.Drawing.Point(270, 384);
            this.panel38.Margin = new System.Windows.Forms.Padding(0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(73, 68);
            this.panel38.TabIndex = 43;
            this.panel38.Tag = "53";
            // 
            // panel39
            // 
            this.panel39.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel39.BackgroundImage")));
            this.panel39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel39.Location = new System.Drawing.Point(270, 452);
            this.panel39.Margin = new System.Windows.Forms.Padding(0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(73, 68);
            this.panel39.TabIndex = 51;
            this.panel39.Tag = "63";
            this.toolTip1.SetToolTip(this.panel39, "Pawn");
            // 
            // panel40
            // 
            this.panel40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel40.Location = new System.Drawing.Point(270, 316);
            this.panel40.Margin = new System.Windows.Forms.Padding(0);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(73, 68);
            this.panel40.TabIndex = 35;
            this.panel40.Tag = "43";
            // 
            // panel41
            // 
            this.panel41.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel41.BackgroundImage")));
            this.panel41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel41.Location = new System.Drawing.Point(489, 520);
            this.panel41.Margin = new System.Windows.Forms.Padding(0);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(73, 68);
            this.panel41.TabIndex = 62;
            this.panel41.Tag = "76";
            this.toolTip1.SetToolTip(this.panel41, "Knight");
            // 
            // panel42
            // 
            this.panel42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel42.Location = new System.Drawing.Point(489, 384);
            this.panel42.Margin = new System.Windows.Forms.Padding(0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(73, 68);
            this.panel42.TabIndex = 46;
            this.panel42.Tag = "56";
            // 
            // panel43
            // 
            this.panel43.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel43.BackgroundImage")));
            this.panel43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel43.Location = new System.Drawing.Point(489, 452);
            this.panel43.Margin = new System.Windows.Forms.Padding(0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(73, 68);
            this.panel43.TabIndex = 54;
            this.panel43.Tag = "66";
            this.toolTip1.SetToolTip(this.panel43, "Pawn");
            // 
            // panel44
            // 
            this.panel44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel44.Location = new System.Drawing.Point(489, 316);
            this.panel44.Margin = new System.Windows.Forms.Padding(0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(73, 68);
            this.panel44.TabIndex = 38;
            this.panel44.Tag = "46";
            // 
            // panel45
            // 
            this.panel45.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel45.BackgroundImage")));
            this.panel45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel45.Location = new System.Drawing.Point(416, 520);
            this.panel45.Margin = new System.Windows.Forms.Padding(0);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(73, 68);
            this.panel45.TabIndex = 61;
            this.panel45.Tag = "75";
            this.toolTip1.SetToolTip(this.panel45, "Bishop");
            // 
            // panel46
            // 
            this.panel46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel46.Location = new System.Drawing.Point(416, 384);
            this.panel46.Margin = new System.Windows.Forms.Padding(0);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(73, 68);
            this.panel46.TabIndex = 45;
            this.panel46.Tag = "55";
            // 
            // panel47
            // 
            this.panel47.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel47.BackgroundImage")));
            this.panel47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel47.Location = new System.Drawing.Point(416, 452);
            this.panel47.Margin = new System.Windows.Forms.Padding(0);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(73, 68);
            this.panel47.TabIndex = 53;
            this.panel47.Tag = "65";
            this.toolTip1.SetToolTip(this.panel47, "Pawn");
            // 
            // panel48
            // 
            this.panel48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel48.Location = new System.Drawing.Point(416, 316);
            this.panel48.Margin = new System.Windows.Forms.Padding(0);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(73, 68);
            this.panel48.TabIndex = 37;
            this.panel48.Tag = "45";
            // 
            // panel49
            // 
            this.panel49.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel49.BackgroundImage")));
            this.panel49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel49.Location = new System.Drawing.Point(197, 520);
            this.panel49.Margin = new System.Windows.Forms.Padding(0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(73, 68);
            this.panel49.TabIndex = 58;
            this.panel49.Tag = "72";
            this.toolTip1.SetToolTip(this.panel49, "Bishop");
            // 
            // panel50
            // 
            this.panel50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel50.Location = new System.Drawing.Point(197, 384);
            this.panel50.Margin = new System.Windows.Forms.Padding(0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(73, 68);
            this.panel50.TabIndex = 42;
            this.panel50.Tag = "52";
            // 
            // panel51
            // 
            this.panel51.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel51.BackgroundImage")));
            this.panel51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel51.Location = new System.Drawing.Point(197, 452);
            this.panel51.Margin = new System.Windows.Forms.Padding(0);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(73, 68);
            this.panel51.TabIndex = 50;
            this.panel51.Tag = "62";
            this.toolTip1.SetToolTip(this.panel51, "Pawn");
            // 
            // panel52
            // 
            this.panel52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel52.Location = new System.Drawing.Point(197, 316);
            this.panel52.Margin = new System.Windows.Forms.Padding(0);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(73, 68);
            this.panel52.TabIndex = 34;
            this.panel52.Tag = "42";
            // 
            // panel53
            // 
            this.panel53.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel53.BackgroundImage")));
            this.panel53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel53.Location = new System.Drawing.Point(343, 520);
            this.panel53.Margin = new System.Windows.Forms.Padding(0);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(73, 68);
            this.panel53.TabIndex = 60;
            this.panel53.Tag = "74";
            this.toolTip1.SetToolTip(this.panel53, "King");
            // 
            // panel54
            // 
            this.panel54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel54.Location = new System.Drawing.Point(343, 384);
            this.panel54.Margin = new System.Windows.Forms.Padding(0);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(73, 68);
            this.panel54.TabIndex = 44;
            this.panel54.Tag = "54";
            // 
            // panel55
            // 
            this.panel55.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel55.BackgroundImage")));
            this.panel55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel55.Location = new System.Drawing.Point(343, 452);
            this.panel55.Margin = new System.Windows.Forms.Padding(0);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(73, 68);
            this.panel55.TabIndex = 52;
            this.panel55.Tag = "64";
            this.toolTip1.SetToolTip(this.panel55, "Pawn");
            // 
            // panel56
            // 
            this.panel56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel56.Location = new System.Drawing.Point(343, 316);
            this.panel56.Margin = new System.Windows.Forms.Padding(0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(73, 68);
            this.panel56.TabIndex = 36;
            this.panel56.Tag = "44";
            // 
            // panel57
            // 
            this.panel57.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel57.BackgroundImage")));
            this.panel57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel57.Location = new System.Drawing.Point(124, 520);
            this.panel57.Margin = new System.Windows.Forms.Padding(0);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(73, 68);
            this.panel57.TabIndex = 57;
            this.panel57.Tag = "71";
            this.toolTip1.SetToolTip(this.panel57, "Knight");
            // 
            // panel58
            // 
            this.panel58.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel58.Location = new System.Drawing.Point(124, 384);
            this.panel58.Margin = new System.Windows.Forms.Padding(0);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(73, 68);
            this.panel58.TabIndex = 41;
            this.panel58.Tag = "51";
            // 
            // panel59
            // 
            this.panel59.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel59.BackgroundImage")));
            this.panel59.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel59.Location = new System.Drawing.Point(124, 452);
            this.panel59.Margin = new System.Windows.Forms.Padding(0);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(73, 68);
            this.panel59.TabIndex = 49;
            this.panel59.Tag = "61";
            this.toolTip1.SetToolTip(this.panel59, "Pawn");
            // 
            // panel60
            // 
            this.panel60.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel60.Location = new System.Drawing.Point(124, 316);
            this.panel60.Margin = new System.Windows.Forms.Padding(0);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(73, 68);
            this.panel60.TabIndex = 33;
            this.panel60.Tag = "41";
            // 
            // panel61
            // 
            this.panel61.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel61.BackgroundImage")));
            this.panel61.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel61.Location = new System.Drawing.Point(51, 520);
            this.panel61.Margin = new System.Windows.Forms.Padding(0);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(73, 68);
            this.panel61.TabIndex = 56;
            this.panel61.Tag = "70";
            this.toolTip1.SetToolTip(this.panel61, "Rook");
            // 
            // panel62
            // 
            this.panel62.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel62.Location = new System.Drawing.Point(51, 384);
            this.panel62.Margin = new System.Windows.Forms.Padding(0);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(73, 68);
            this.panel62.TabIndex = 40;
            this.panel62.Tag = "50";
            // 
            // panel63
            // 
            this.panel63.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel63.BackgroundImage")));
            this.panel63.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel63.Location = new System.Drawing.Point(51, 452);
            this.panel63.Margin = new System.Windows.Forms.Padding(0);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(73, 68);
            this.panel63.TabIndex = 48;
            this.panel63.Tag = "60";
            this.toolTip1.SetToolTip(this.panel63, "Pawn");
            // 
            // panel64
            // 
            this.panel64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel64.Location = new System.Drawing.Point(51, 316);
            this.panel64.Margin = new System.Windows.Forms.Padding(0);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(73, 68);
            this.panel64.TabIndex = 32;
            this.panel64.Tag = "40";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(70, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 31);
            this.label1.TabIndex = 64;
            this.label1.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(148, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 31);
            this.label2.TabIndex = 65;
            this.label2.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(295, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 31);
            this.label3.TabIndex = 67;
            this.label3.Text = "4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(217, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 31);
            this.label4.TabIndex = 66;
            this.label4.Text = "3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(586, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 31);
            this.label5.TabIndex = 71;
            this.label5.Text = "8";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(508, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 31);
            this.label6.TabIndex = 70;
            this.label6.Text = "7";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(439, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 31);
            this.label7.TabIndex = 69;
            this.label7.Text = "6";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(361, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 31);
            this.label8.TabIndex = 68;
            this.label8.Text = "5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(12, 541);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 31);
            this.label9.TabIndex = 79;
            this.label9.Text = "h";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(12, 469);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 31);
            this.label10.TabIndex = 78;
            this.label10.Text = "g";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(12, 403);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 31);
            this.label11.TabIndex = 77;
            this.label11.Text = "f";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(12, 331);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 31);
            this.label12.TabIndex = 76;
            this.label12.Text = "e";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(12, 265);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 31);
            this.label13.TabIndex = 75;
            this.label13.Text = "d";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(12, 200);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 31);
            this.label14.TabIndex = 74;
            this.label14.Text = "c";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(12, 128);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 31);
            this.label15.TabIndex = 73;
            this.label15.Text = "b";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(12, 62);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 31);
            this.label16.TabIndex = 72;
            this.label16.Text = "a";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(586, 588);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 31);
            this.label17.TabIndex = 87;
            this.label17.Text = "8";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(508, 588);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 31);
            this.label18.TabIndex = 86;
            this.label18.Text = "7";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(439, 588);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 31);
            this.label19.TabIndex = 85;
            this.label19.Text = "6";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(361, 588);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 31);
            this.label20.TabIndex = 84;
            this.label20.Text = "5";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(295, 588);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 31);
            this.label21.TabIndex = 83;
            this.label21.Text = "4";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(217, 588);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 31);
            this.label22.TabIndex = 82;
            this.label22.Text = "3";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(148, 588);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 31);
            this.label23.TabIndex = 81;
            this.label23.Text = "2";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(70, 588);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 31);
            this.label24.TabIndex = 80;
            this.label24.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(641, 541);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 31);
            this.label25.TabIndex = 95;
            this.label25.Text = "h";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(641, 469);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 31);
            this.label26.TabIndex = 94;
            this.label26.Text = "g";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(641, 403);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(22, 31);
            this.label27.TabIndex = 93;
            this.label27.Text = "f";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(641, 331);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 31);
            this.label28.TabIndex = 92;
            this.label28.Text = "e";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(641, 265);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 31);
            this.label29.TabIndex = 91;
            this.label29.Text = "d";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(641, 200);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(28, 31);
            this.label30.TabIndex = 90;
            this.label30.Text = "c";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(641, 128);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 31);
            this.label31.TabIndex = 89;
            this.label31.Text = "b";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(641, 62);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 31);
            this.label32.TabIndex = 88;
            this.label32.Text = "a";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 626);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel33);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel34);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel35);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel36);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel37);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel38);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel39);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel40);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel41);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel42);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel43);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel44);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel45);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel46);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel47);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel48);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel49);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.panel50);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel51);
            this.Controls.Add(this.panel26);
            this.Controls.Add(this.panel52);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel53);
            this.Controls.Add(this.panel27);
            this.Controls.Add(this.panel54);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel55);
            this.Controls.Add(this.panel28);
            this.Controls.Add(this.panel56);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel57);
            this.Controls.Add(this.panel29);
            this.Controls.Add(this.panel58);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel59);
            this.Controls.Add(this.panel30);
            this.Controls.Add(this.panel60);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel61);
            this.Controls.Add(this.panel31);
            this.Controls.Add(this.panel62);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel63);
            this.Controls.Add(this.panel32);
            this.Controls.Add(this.panel64);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
    }
}

