<?php 
class Category{
    public string $name;
    public $list_products;
    public function __construct($name, $list_products){
        $this->name = $name;
        $this->list_products = $list_products;
    }
    public function getCategoryName(){
        return $this->name;
    }
    public function getCategoryProducts(){
        return $this->list_products;
    }
    public static function FindCategory($categoryList, string $name){
        foreach($categoryList as $category){
            if($category->name == $name){
            return $category;
            }
        }
        return null;
    }
}
?>