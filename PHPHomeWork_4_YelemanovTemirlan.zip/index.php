<?php
require_once("Category.php");
require_once("Product.php");
$categories = [];
$categories[] = new Category("Dairy", [new Product("Milka"), new Product("Jactel"), new Product("Moyo")]);
$categories[] = new Category("Candies", [new Product("Snikers"), new Product("Twix"), new Product("Yarche")]);
$categories[] = new Category("Macarons", [new Product("Sultan"), new Product("Aldente"), new Product("Alem")]);
$arr = [];
echo "<code><pre>";
if (isset($_POST["categories"])) {
    $arr = json_decode($_POST["categories"]);
    if ($arr != null) {
        $temp = [];
        foreach ($arr as $category) {
            $temp1 = [];
            foreach ($category->list_products as $product) {
                $temp1[] = new Product($product->name);
            }
            $temp[] = new Category($category->name, $temp1);
        }
        $arr = $temp;
        $categories = array_merge($categories, $arr);
    }
}
if (isset($_POST["categoryName"])) {
    $products = [];
    if (isset($_POST["products"])) {
        $list = explode(" ", $_POST["products"]);
        foreach ($list as $productName) {
            $products[] = new Product($productName);
        }
    }
    $newCategory = new Category($_POST["categoryName"], $products);
    $categories[] = $newCategory;
    $arr[] = $newCategory;
}
$selectedCategory = null;
if (isset($_POST["buttonCategoryClick"])) {
    $selectedCategory = Category::FindCategory($categories, $_POST["buttonCategoryClick"]);
    if ($selectedCategory != null) {
        $selectedCategory = $selectedCategory->getCategoryProducts();
    }
}

if (isset($_POST["buttonClick"])) {
    switch ($_POST["buttonClick"]) {
        case "clear":
            echo "clearing list";
            $arr = [];
            break;
    }
}
echo "</pre></code>";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <form action="index.php" method="post">
        Categories:
        <?php foreach ($categories as $category): ?>
            <button type=submit name=buttonCategoryClick value="<?= $category->name ?>">
                <?= $category->name ?>
            </button>
        <?php endforeach ?>
        <br>
        <?php if ($selectedCategory != null): ?>
            <?php foreach ($selectedCategory as $product): ?>
                <div class="product">
                    <?= $product->ToString() ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <input type="hidden" name=categories value=<?= htmlspecialchars(json_encode($arr)) ?>>
    </form>
    <form action=index.php method=post>
        <input type="text" name=categoryName placeholder="Category Name...">
        Type in products separated by spaces: <input type="text" name=products placeholder="chocolate milk banana...">
        <button type=submit name=buttonClick value="Add">Add</button>
        <input type="hidden" name=categories value=<?= htmlspecialchars(json_encode($arr)) ?>>
        <br>
        <button type=submit name=buttonClick value=clear>Clear list</button>
    </form>
</body>

</html>