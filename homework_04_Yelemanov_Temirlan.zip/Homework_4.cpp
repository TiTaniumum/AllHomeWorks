﻿#include <iostream>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
using namespace std;


int main()
{
  setlocale(LC_CTYPE, "Russian");
  problem1(); // тут в задаче можно ввести отрицательное 4-х значное число.
  problem2(); // тут я использовал небольшую хитрость.
  problem3(); // та самая задачка с убыванием из A,B,C,D   вы просили ее скинуть.

  cout << "E N D  ......\n";
}
