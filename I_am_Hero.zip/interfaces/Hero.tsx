export default interface Hero{
    id: number
    nickname: string
    fullname: string | null
    password: string
    birthday: Date | null
    deathday: Date | null
    bio: string | null
    createDate: Date
    set: (key: string, value: any)=>void
}

export const heroMock: Hero = 
{
    id: 1,
    nickname: "Temirlan",
    fullname: "Temirlan Yelemanov",
    password: "admin",
    birthday: new Date("1999-11-30"),
    deathday: null,
    bio: "Very cool guy. Hot boy. Millionair. Playboy. Filantrop. God programmer. Best developer.",
    createDate: new Date("2024-07-11"),
    set (key: string, value: any) {
        switch(key){
            case 'nickname': this.nickname = value; break;
            case 'fullname': this.fullname = value; break;
            case 'birthday': this.birthday = value; break;
            case 'deathday': this.deathday = value; break;
            case 'bio': this.bio = value; break;
        }
    }    
}