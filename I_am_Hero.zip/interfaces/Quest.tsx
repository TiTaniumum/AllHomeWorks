import uuid from 'react-native-uuid';

export default interface Quest{
    id: number[] | string,
    name: string,
    description: string,
    xpValue: number,
    difficulty: QuestDifficulty,
    isComplete: boolean,
    createDate: Date,
    completeDate: Date | undefined | null,
    priority: number,
}

export enum QuestDifficulty{
    EASY = "Easy",
    MEDIUM = "Mid",
    TRICKY = "Tricky",
    HARD = "Hard",
    SUPERHARD = "Super hard",
    LIFEGOAL = "Life goal",
    WORLDWIDE = "World wide",
    UNIVERSAL = "Universal",
}

export const questMock: Quest[] = [
    {
        id: uuid.v4(),
        name: "First quest",
        description: "This quest serves the purpose of mock object",
        xpValue: 100,
        difficulty: QuestDifficulty.EASY,
        isComplete: false,
        createDate: new Date(),
        completeDate: undefined,
        priority: 1,
    },
    {
        id: uuid.v4(),
        name: "Second quest",
        description: "This quest serves the purpose of mock object",
        xpValue: 200,
        difficulty: QuestDifficulty.MEDIUM,
        isComplete: false,
        createDate: new Date(),
        completeDate: undefined,
        priority: 2,
    },
]