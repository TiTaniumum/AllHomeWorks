export interface Stat{name: string, value: number, maxValue: number | undefined};

export default interface Stats{
    id: number,
    HP: Stat,
    MH: Stat,
    MP: Stat,
    exp: number,
    strength: Stat,
    perception: Stat,
    endurance: Stat,
    charisma: Stat,
    intelligence: Stat,
    agility: Stat,
    luck: Stat,
}

export const statsMock = {
    id: 1,
    HP: {name: 'Health points', value: 90, maxValue: 100},
    MH: {name: 'Mental health', value: 90, maxValue: 100},
    MP: {name: 'Mana points', value: 0, maxValue: 0},
    exp: 9145919,
    strength: {name: 'Strength', value: 3, maxValue: 10},
    perception: {name: 'Perception', value: 2, maxValue: 10},
    endurance: {name: 'Endurance', value: 4, maxValue: 10},
    charisma: {name: 'Charisma', value: 2, maxValue: 10},
    intelligence: {name: 'Intelligence', value: 7, maxValue: 10},
    agility: {name: 'Agility', value: 4, maxValue: 10},
    luck: {name: 'Luck', value: 8, maxValue: 10},
}

export const statsMockArr = [
    ['id', 1],
    ['exp', 0],
    ['HP', {name: 'Health points', value: 90, maxValue: 100}],
    ['MH', {name: 'Mental health', value: 90, maxValue: 100}],
    ['MP', {name: 'Mana points', value: 0, maxValue: 0}],
    ['strength', {name: 'Strength', value: 3, maxValue: 10}],
    ['perception', {name: 'Perception', value: 2, maxValue: 10}],
    ['endurance', {name: 'Endurance', value: 4, maxValue: 10}],
    ['charisma', {name: 'Charisma', value: 2, maxValue: 10}],
    ['intelligence', {name: 'Intelligence', value: 7, maxValue: 10}],
    ['agility', {name: 'Agility', value: 4, maxValue: 10}],
    ['luck', {name: 'Luck', value: 8, maxValue: 10}],
]

export const immutableStats = [
    'id',
    'exp',
    'HP',
    'MH',
    'MP',
    'strength', 
    'perception',
    'endurance',
    'charisma', 
    'intelligence',
    'agility', 
    'luck',
]

export function isImmutableStat(key:string){   
    return immutableStats.indexOf(key)>=0;
}