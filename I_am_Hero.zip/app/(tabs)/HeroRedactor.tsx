import { Collapsible } from "@/components/Collapsible";
import { useGlobalContext } from "@/components/ContextProvider";
import Redactable, { RedactableDate } from "@/components/Redactable";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { isImmutableStat, Stat } from "@/interfaces/Stats";
import { setStatusBarStyle } from "expo-status-bar";
import {
  View,
  StyleSheet,
  Pressable,
  Button,
  TextInput,
  Alert,
  Platform,
} from "react-native";
import { ScrollView, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BlurView } from "expo-blur";
import Spacer from "@/components/Spacer";
import { useState } from "react";
import Animated, {
  FadeIn,
  FadeOut,
  FlipInEasyX,
  FlipInXUp,
  FlipOutEasyX,
  FlipOutXDown,
  FlipOutXUp,
  LightSpeedOutLeft,
} from "react-native-reanimated";
import { formatDate } from ".";

function Capitalize(word: string) {
  if (!word) return word;
  return word[0].toUpperCase() + word.substr(1).toLowerCase();
}

export default function HeroRedactor() {
  const [isVisible, setIsVisible] = useState(false);
  const [statName, setStatName] = useState("");
  const [statValue, setStatValue] = useState("");
  const [statMaxValue, setStatMaxValue] = useState("");

  const { hero, stats, setHero, setStats } = useGlobalContext();

  function HandleAddStat() {
    if (
      !stats.find((item) => item[0] == statName) &&
      statName != "" &&
      statValue != ""
    ) {
      const stat: Stat = {
        name: statName,
        value: +statValue,
        maxValue: statMaxValue == "" ? undefined : +statMaxValue,
      };
      setStats([...stats, [statName, stat]]);
    } else {
      Alert.alert(
        "Warning!",
        "Such stat cannot be created! Either it already exists or it has empty fields"
      );
    }
    setStatName("");
    setStatValue("");
    setStatMaxValue("");
    setIsVisible(false);
  }

  return (
    <SafeAreaView style={styles.container}>
      {Platform.OS === "web" || Platform.OS === "ios" ? (
        <BlurView
          style={[styles.absolute, styles.header, styles.row]}
          tint="dark"
          intensity={60}
        >
          <Pressable
            onPress={() => {
              setIsVisible(!isVisible);
            }}
            style={({ pressed }) => [
              styles.item,
              {
                width: "30%",
                backgroundColor: pressed
                  ? "rgba(51, 51, 51, 0.7)"
                  : "transparent",
              },
              styles.center,
            ]}
          >
            <ThemedText>New stat</ThemedText>
          </Pressable>
        </BlurView>
      ) : (
        <Animated.View
          entering={FlipInEasyX}
          exiting={FlipOutEasyX}
          style={[
            styles.absolute,
            styles.header,
            styles.row,
            { backgroundColor: "rgba(0, 0, 0, 0.9)" },
          ]}
        >
          <Pressable
            onPress={() => {
              setIsVisible(!isVisible);
            }}
            style={({ pressed }) => [
              styles.item,
              {
                width: "30%",
                backgroundColor: pressed
                  ? "rgba(51, 51, 51, 0.7)"
                  : "transparent",
              },
              styles.center,
            ]}
          >
            <ThemedText>New stat</ThemedText>
          </Pressable>
        </Animated.View>
      )}
      {isVisible && (Platform.OS === "web" || Platform.OS === "ios") && (
        <BlurView
          style={[styles.absolute, styles.modal]}
          tint="dark"
          intensity={60}
        >
          <TextInput
            value={statName}
            onChangeText={setStatName}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Name of the stat..."
          />
          <TextInput
            value={statValue}
            onChangeText={setStatValue}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Value..."
          />
          <TextInput
            value={statMaxValue}
            onChangeText={setStatMaxValue}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Max value..."
          />
          <Pressable
            onPress={HandleAddStat}
            style={[styles.item, styles.center]}
          >
            <ThemedText>Add</ThemedText>
          </Pressable>
        </BlurView>
      )}
      {isVisible && Platform.OS !== "web" && Platform.OS !== "ios" && (
        <Animated.View
          entering={FlipInXUp}
          exiting={FlipOutXDown}
          style={[
            styles.absolute,
            styles.modal,
            { backgroundColor: "rgba(0, 0, 0, 0.9)" },
          ]}
        >
          <TextInput
            value={statName}
            onChangeText={setStatName}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Name of the stat..."
          />
          <TextInput
            value={statValue}
            onChangeText={setStatValue}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Value..."
          />
          <TextInput
            value={statMaxValue}
            onChangeText={setStatMaxValue}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Max value..."
          />
          <Pressable
            onPress={HandleAddStat}
            style={[styles.item, styles.center]}
          >
            <ThemedText>Add</ThemedText>
          </Pressable>
        </Animated.View>
      )}
      <ScrollView contentContainerStyle={{ gap: 10, padding: 20 }}>
        <Spacer height={50} />
        <ThemedText style={styles.title}>Your profile:</ThemedText>
        {Object.entries(hero).map(([key, value]) => {
          if (key == "id" || key == "password" || key == "set") return;
          return (
            <Collapsible key={key} title={Capitalize(key)}>
              <Animated.View entering={FadeIn}>
                {key == "birthday" ||
                key == "deathday" ||
                key == "createDate" ? (
                  <RedactableDate
                    initialDate={value == null ? new Date() : value}
                    redact={(date) => {
                      hero.set(key, date);
                      setHero({ ...hero });
                    }}
                  >
                    <ThemedText>
                      {value != null ? formatDate(value) : "..."}
                    </ThemedText>
                  </RedactableDate>
                ) : (
                  <Redactable
                    title={value}
                    redact={(value) => {
                      hero.set(key, value);
                      setHero({ ...hero });
                    }}
                  >
                    <ThemedText style={styles.redactable}> {value}</ThemedText>
                  </Redactable>
                )}
              </Animated.View>
            </Collapsible>
          );
        })}
        <ThemedText style={styles.title}>Your stats:</ThemedText>
        {stats.map(([key, value]) => {
          if (key == "id" || key == "MP") return;
          if (key == "exp")
            return (
              <Animated.View
                entering={FlipInXUp}
                exiting={LightSpeedOutLeft}
                key={key}
                style={[
                  styles.item,
                  styles.row,
                  { justifyContent: "space-between", alignItems: "center" },
                ]}
              >
                <ThemedView
                  style={{ width: isImmutableStat(key) ? "100%" : "76%" }}
                >
                  <Collapsible title={key}>
                    <Animated.View entering={FadeIn}>
                      <Redactable
                        title={value + ""}
                        redact={(n) => {
                          if (value == "") v.value = 0;
                          else stats.find((item) => item[0] == "exp")[1] = n;
                          setStats([...stats]);
                        }}
                      >
                        <ThemedText style={styles.redactable}>
                          Amount: {value}
                        </ThemedText>
                      </Redactable>
                    </Animated.View>
                  </Collapsible>
                </ThemedView>
              </Animated.View>
            );
          let v: Stat = value;
          return (
            <Animated.View
              entering={FlipInXUp}
              exiting={LightSpeedOutLeft}
              key={key}
              style={[
                styles.item,
                styles.row,
                { justifyContent: "space-between", alignItems: "center" },
              ]}
            >
              <ThemedView
                style={{ width: isImmutableStat(key) ? "100%" : "76%" }}
              >
                <Collapsible title={v.name}>
                  <Animated.View entering={FadeIn}>
                    <Redactable
                      title={v.value + ""}
                      redact={(value) => {
                        if (value == "") v.value = 0;
                        else v.value = value;
                        if (v.maxValue && v.value > v.maxValue)
                          v.value = v.maxValue;
                        setStats([...stats]);
                      }}
                    >
                      <ThemedText style={styles.redactable}>
                        Value: {v.value}
                      </ThemedText>
                    </Redactable>
                  </Animated.View>
                </Collapsible>
                <Collapsible title={v.name + " max"}>
                  <Animated.View entering={FadeIn}>
                    <Redactable
                      title={v.maxValue + ""}
                      redact={(value) => {
                        if (value == "") v.maxValue = undefined;
                        else v.maxValue = value;
                        if (v.maxValue && v.value > v.maxValue)
                          v.value = v.maxValue;
                        setStats([...stats]);
                      }}
                    >
                      <ThemedText style={styles.redactable}>
                        Max value: {v.maxValue}
                      </ThemedText>
                    </Redactable>
                  </Animated.View>
                </Collapsible>
              </ThemedView>
              {!isImmutableStat(key) && (
                <Pressable
                  onPress={() => {
                    setStats(stats.filter((item) => item[0] != key));
                  }}
                  style={[
                    styles.item,
                    styles.center,
                    { width: 80, height: 40 },
                  ]}
                >
                  <ThemedText>Remove</ThemedText>
                </Pressable>
              )}
            </Animated.View>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
  },
  container: {
    flex: 1,
    backgroundColor: "black",
  },
  absolute: {
    zIndex: 2,
    position: "absolute",
    top: 26,
    left: 0,
    bottom: 0,
    right: 0,
    width: "100%",
    height: 50,
  },
  redactable: {
    color: "#809dd1",
  },
  title: {
    width: "100%",
    textAlign: "center",
    fontSize: 25,
    color: "white",
  },
  item: {
    color: "white",
    borderWidth: 2,
    borderColor: "white",
    padding: 3,
    borderRadius: 10,
    width: "100%",
  },
  header: {
    justifyContent: "space-between",
    alignItems: "center",
    paddingLeft: 30,
    paddingRight: 30,
  },
  modal: {
    top: 76,
    height: 300,
    justifyContent: "center",
    alignItems: "center",
    gap: 30,
    padding: 30,
  },
  center: {
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    color: "white",
  },
});
