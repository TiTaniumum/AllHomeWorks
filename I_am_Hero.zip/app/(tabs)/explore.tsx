import Ionicons from "@expo/vector-icons/Ionicons";
import {
  StyleSheet,
  Image,
  Platform,
  ScrollView,
  Pressable,
  TextInput,
  Alert,
} from "react-native";
import uuid from "react-native-uuid";
import { Collapsible } from "@/components/Collapsible";
import { ExternalLink } from "@/components/ExternalLink";
import ParallaxScrollView from "@/components/ParallaxScrollView";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useGlobalContext } from "@/components/ContextProvider";
import Animated, {
  FadeIn,
  FlipInEasyX,
  FlipInXUp,
  FlipOutEasyX,
  FlipOutXDown,
  ZoomOut,
} from "react-native-reanimated";
import { useState } from "react";
import Quest, { QuestDifficulty } from "@/interfaces/Quest";
import { Picker } from "@react-native-picker/picker";
import RNPickerSelect from "react-native-picker-select";

export default function TabTwoScreen() {
  const { quests, setQuests, updateExp } = useGlobalContext();

  const [filteredQuests, setFilteredQuests] = useState<Quest[]>([]);
  const [isVisible, setIsVisible] = useState(false);

  const [questName, setQuestName] = useState("");
  const [questDescription, setQuestDescription] = useState("");
  const [questXpValue, setQuestXpValue] = useState("");
  const [questDifficulty, setQuestDifficulty] = useState<QuestDifficulty>(
    QuestDifficulty.EASY
  );
  const [questPriority, setQuestPriotiy] = useState("");

  function HandleAddQuest() {
    if (
      questName == "" ||
      questDescription == "" ||
      questXpValue == "" ||
      questPriority == ""
    ) {
      Alert.alert("Warning!", "Some fields are empty");
      return;
    }
    const newQeust = {
      id: uuid.v4(),
      name: questName,
      description: questDescription,
      xpValue: +questXpValue,
      difficulty: questDifficulty,
      isComplete: false,
      createDate: new Date(),
      completeDate: null,
      priority: +questPriority,
    };
    setQuests([...quests, newQeust]);
    setQuestName("");
    setQuestDescription("");
    setQuestXpValue("");
    setQuestDifficulty(QuestDifficulty.EASY);
    setQuestPriotiy("");
    setIsVisible(false);
  }
  function getComplete() {
    return quests.filter((item) => !item.isComplete);
  }
  function getUncomplete(){
    return quests.filter((item)=>item.isComplete);
  }

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: "#D0D0D0", dark: "#353636" }}
      headerImage={
        <Ionicons size={310} name="pulse" style={styles.headerImage} />
      }
    >
      <Animated.View
        entering={FlipInEasyX}
        style={[
          styles.absolute,
          styles.header,
          styles.row,
          { backgroundColor: "rgba(0, 0, 0, 0.9)" },
        ]}
      >
        <Pressable
          onPress={() => {
            setIsVisible(!isVisible);
          }}
          style={({ pressed }) => [
            styles.item,
            {
              width: "30%",
              backgroundColor: pressed
                ? "rgba(51, 51, 51, 0.7)"
                : "transparent",
            },
            styles.center,
          ]}
        >
          <ThemedText>New quest</ThemedText>
        </Pressable>
      </Animated.View>
      {isVisible && (
        <Animated.View
          entering={FlipInXUp}
          exiting={FlipOutXDown}
          style={[
            styles.absolute,
            styles.modal,
            { backgroundColor: "rgba(0, 0, 0, 0.9)" },
          ]}
        >
          <TextInput
            value={questName}
            onChangeText={setQuestName}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Name of the qeust..."
          />
          <TextInput
            value={questDescription}
            onChangeText={setQuestDescription}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Quest description..."
          />
          <TextInput
            value={questXpValue}
            onChangeText={setQuestXpValue}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Quest xp value..."
          />
          <RNPickerSelect
            value={questDifficulty}
            onValueChange={(value) => {
              setQuestDifficulty(value);
            }}
            items={[
              { label: "Easy", value: QuestDifficulty.EASY },
              { label: "Mid", value: QuestDifficulty.MEDIUM },
              { label: "Tricky", value: QuestDifficulty.TRICKY },
              { label: "Hard", value: QuestDifficulty.HARD },
              { label: "Super hard", value: QuestDifficulty.SUPERHARD },
              { label: "Life goal", value: QuestDifficulty.LIFEGOAL },
              { label: "World wide", value: QuestDifficulty.WORLDWIDE },
              { label: "Universal", value: QuestDifficulty.UNIVERSAL },
            ]}
            style={{
              inputAndroid: { color: "white" },
              viewContainer: styles.item,
            }}
          />
          <TextInput
            value={questPriority}
            onChangeText={setQuestPriotiy}
            style={styles.item}
            placeholderTextColor="#adadad"
            placeholder="Quest priority..."
          />
          <Pressable
            onPress={HandleAddQuest}
            style={[styles.item, styles.center]}
          >
            <ThemedText>Add</ThemedText>
          </Pressable>
        </Animated.View>
      )}
      <ThemedView style={{ minHeight: 400 }}>
        <ThemedText type="title">Active quests:</ThemedText>
        {getComplete().map((item) => (
          <Animated.View
            key={item.id.toString()}
            entering={FlipInXUp}
            exiting={ZoomOut}
          >
            <Collapsible
              title={item.name}
              titleStyle={{ color: item.isComplete ? "gray" : "white" }}
            >
              <Animated.View entering={FadeIn}>
                <ThemedText>{item.description}</ThemedText>
                <ThemedText>Difficulty: {item.difficulty}</ThemedText>
                <ThemedText>
                  Experience for completion: {item.xpValue}
                </ThemedText>
                <ThemedText>Priority: {item.priority}</ThemedText>
                <ThemedText>
                  Quest accept date: {item.createDate.toLocaleDateString()}
                </ThemedText>
                {item.completeDate && (
                  <ThemedText>
                    {item.completeDate.toLocaleDateString()}
                  </ThemedText>
                )}
                <ThemedText>
                  Is complete: {item.isComplete ? "Complete" : "Active"}
                </ThemedText>
                <Pressable
                  onPress={() => {
                    item.isComplete = !item.isComplete;
                    updateExp();
                    setQuests([...quests]);
                  }}
                  style={[styles.item, styles.center]}
                >
                  <ThemedText>Complete</ThemedText>
                </Pressable>
                <Pressable
                  onPress={() => {
                    setQuests(
                      quests.filter(
                        (i) => i.id.toString() != item.id.toString()
                      )
                    );
                  }}
                  style={[styles.item, styles.center]}
                >
                  <ThemedText>Remove</ThemedText>
                </Pressable>
              </Animated.View>
            </Collapsible>
          </Animated.View>
        ))}
        <ThemedText type="title">Completed quests:</ThemedText>
        {getUncomplete().map((item) => (
          <Animated.View
            key={item.id.toString()}
            entering={FlipInXUp}
            exiting={ZoomOut}
          >
            <Collapsible
              title={item.name}
              titleStyle={{ color: item.isComplete ? "gray" : "white" }}
            >
              <Animated.View entering={FadeIn}>
                <ThemedText>{item.description}</ThemedText>
                <ThemedText>Difficulty: {item.difficulty}</ThemedText>
                <ThemedText>
                  Experience for completion: {item.xpValue}
                </ThemedText>
                <ThemedText>Priority: {item.priority}</ThemedText>
                <ThemedText>
                  Quest accept date: {item.createDate.toLocaleDateString()}
                </ThemedText>
                {item.completeDate && (
                  <ThemedText>
                    {item.completeDate.toLocaleDateString()}
                  </ThemedText>
                )}
                <ThemedText>
                  Is complete: {item.isComplete ? "Complete" : "Active"}
                </ThemedText>
                <Pressable
                  onPress={() => {
                    item.isComplete = !item.isComplete;
                    updateExp();
                    setQuests([...quests]);
                  }}
                  style={[styles.item, styles.center]}
                >
                  <ThemedText>{item.isComplete ? "Complete" : "Cancel complete"}</ThemedText>
                </Pressable>
                <Pressable
                  onPress={() => {
                    setQuests(
                      quests.filter(
                        (i) => i.id.toString() != item.id.toString()
                      )
                    );
                  }}
                  style={[styles.item, styles.center]}
                >
                  <ThemedText>Remove</ThemedText>
                </Pressable>
              </Animated.View>
            </Collapsible>
          </Animated.View>
        ))}
      </ThemedView>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  headerImage: {
    color: "#808080",
    bottom: -90,
    left: -35,
    position: "absolute",
  },
  absolute: {
    zIndex: 2,
    position: "absolute",
    top: -400,
    left: 0,
    bottom: 0,
    right: 0,
    width: "120%",
    height: 50,
  },
  row: {
    flexDirection: "row",
  },
  header: {
    justifyContent: "space-between",
    alignItems: "center",
    paddingLeft: 30,
    paddingRight: 30,
    height: 140,
  },
  item: {
    color: "white",
    borderWidth: 2,
    borderColor: "white",
    padding: 3,
    borderRadius: 10,
    width: "100%",
  },
  center: {
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    top: -260,
    height: 500,
    justifyContent: "center",
    alignItems: "center",
    gap: 30,
    padding: 30,
    //width: '100%'
  },
});
