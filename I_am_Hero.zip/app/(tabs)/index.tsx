import { Image, StyleSheet, Platform, View, Text } from 'react-native';

import { HelloWave } from '@/components/HelloWave';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useGlobalContext } from '@/components/ContextProvider';
import StatRow from '@/components/StatRow';
import { Stat } from '@/interfaces/Stats';
import { useEffect } from 'react';

export function formatDate(date: Date){
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
  const day = String(date.getDate()).padStart(2, '0');

  return `${day}.${month}.${year}`;
};

export default function HomeScreen() {
  const {hero, stats, calcLevel, nextLevelStat} = useGlobalContext();

  

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}
      headerImage={
        <Image
          source={require('@/assets/images/Human.jpg')}
          style={styles.reactLogo}
        />
      }>
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title">{hero.nickname}</ThemedText>
      </ThemedView>
      <ThemedView style={styles.stepContainer}>
        <ThemedText type="subtitle">Birthday:</ThemedText>
        <ThemedText>{hero.birthday && formatDate(hero.birthday)}</ThemedText>
        <ThemedText type="subtitle">Bio:</ThemedText>
        <ThemedText>{hero.bio}</ThemedText>
        <ThemedText type='subtitle'>Your Stats</ThemedText>
        {stats.map(([key,value])=>{ 
          if(key == 'id') return;
          if(key == 'exp')
            return (<View key={key}><StatRow statName='Level:' statCurrent={calcLevel(value)}/><StatRow statName='Exp to next level:' statCurrent={nextLevelStat(value).currentExp} statMax={nextLevelStat(value).maxExp}/></View>)
          let v: Stat = value;
          if(key == 'strength')
            return (<View key={key}><ThemedText type="defaultSemiBold" style={{width: '100%', textAlign:'center'}}>Your S.P.E.C.I.A.L.</ThemedText><StatRow statName={v.name} statCurrent={v.value} statMax={v.maxValue}/></View>)
          if(key == 'luck')
            return (<View key={key}><StatRow statName={v.name} statCurrent={v.value} statMax={v.maxValue}/><ThemedText type="defaultSemiBold" style={{width: '100%', textAlign:'center'}}>Other stats:</ThemedText></View>)
          return (<StatRow key={key} statName={v.name} statCurrent={v.value} statMax={v.maxValue}/>)
          })}
      </ThemedView>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 300,
    width: 300,
    position: 'absolute',
  },
});
