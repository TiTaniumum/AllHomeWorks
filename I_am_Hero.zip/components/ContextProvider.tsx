import React, {
  createContext,
  useState,
  useContext,
  ReactNode,
  useEffect,
  useRef,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import Hero, { heroMock } from "@/interfaces/Hero";
import Stats, { statsMock, statsMockArr } from "@/interfaces/Stats";
import Quest, { questMock } from "@/interfaces/Quest";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

async function sendNotification(title: string, body: string) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: title,
      body: body,
      data: { someData: "данные" },
    },
    trigger: {
      seconds: 1,
    },
  });
}

async function registerForPush() {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  if (existingStatus !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== "granted") {
    alert("Ошибка получения прав");
    return;
  }
}

function getDelay(timestamp: number) {
  let time = new Date(timestamp);
  let now = new Date();
  let timeEx = (time.getHours() * 60 + time.getMinutes()) * 60000;
  let timeNow = (now.getHours() * 60 + now.getMinutes()) * 60000;
  return timeEx - timeNow;
}

type GlobalContext = {
  hero: Hero;
  stats: any[];
  quests: Quest[];
  calcLevel: (exp: number) => number;
  nextLevelStat: (exp: number) => {
    currentExp: number;
    maxExp: number;
    getString: () => string;
  };
  setHero: (value: Hero) => void;
  setStats: (value: any[]) => void;
  setQuests: (value: Quest[]) => void;
  updateExp: ()=>void;
};

const Context = createContext<GlobalContext>({} as GlobalContext);

export function ContextProvider({ children }: { children: ReactNode }) {
  const [hero, setHero] = useState<Hero>(heroMock);
  const [stats, setStats] = useState<any[]>(statsMockArr);
  const [quests, setQuests] = useState<Quest[]>(questMock);
  const notificationListener = useRef<Notifications.Subscription | undefined>(
    undefined
  );
  const responseListener = useRef<Notifications.Subscription | undefined>();
  const [notification, setNotification] = useState<
    Notifications.Notification | undefined
  >(undefined);

  function updateExp(){
    let exp:number = 0;
    quests.forEach((item)=>{if(item.isComplete) exp += item.xpValue;})
    stats.find((item)=>item[0] == 'exp')[1] = exp;
  }
  function calcLevel(exp: number) {
    const multiplier = 5
    return (Math.sqrt(exp) / multiplier) | 0;
  }
  function nextLevelStat(exp: number) {
    const multiplier = 5
    const currentLevel = calcLevel(exp);
    const currentLevelExp = Math.pow(currentLevel * multiplier, 2);
    const nextlevelExp = Math.pow((currentLevel + 1) * multiplier, 2);
    const maxExp = nextlevelExp - currentLevelExp;
    const currentExp = exp - currentLevelExp;
    function getString() {
      return currentExp + " / " + maxExp;
    }
    return { currentExp, maxExp, getString };
  }

  useEffect(() => {
    registerForPush();
    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        setNotification(notification);
      });
    responseListener.current =
      Notifications.addNotificationResponseReceivedListener((response) => {
        console.info(response);
      });
    return () => {
      notificationListener.current?.remove();
      responseListener.current?.remove();
    };
  }, []);

  return (
    <Context.Provider
      value={{
        hero,
        stats,
        quests,
        calcLevel,
        nextLevelStat,
        setHero,
        setStats,
        setQuests,
        updateExp,
      }}
    >
      {children}
    </Context.Provider>
  );
}

export function useGlobalContext() {
  const context = useContext(Context);
  if (context === undefined) {
    throw new Error("useGlobalContext должен использовать ContextProvider");
  }
  return context;
}
