import React, { PropsWithChildren, useState } from "react";
import { ThemedView } from "./ThemedView";
import { ThemedText } from "./ThemedText";
import { Pressable, TextInput, StyleSheet } from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import Animated, { ZoomIn, ZoomOut } from "react-native-reanimated";

export default function Redactable({
  children,
  title,
  redact,
}: PropsWithChildren & { title: string } & { redact: (value: any) => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [text, setText] = useState(title ? title : "");
  const [isFocused, setIsFocused] = useState(false);
  function handleDone() {
    redact(text);
    setIsOpen(false);
  }
  return (
    <ThemedView>
      {isOpen ? (
        <ThemedView style={{ flexDirection: "row", gap: 5 }}>
          <TextInput
            value={text}
            onBlur={() => setIsFocused(false)}
            onFocus={() => setIsFocused(true)}
            onChangeText={setText}
            style={[
              styles.border,
              styles.width,
              isFocused && styles.inputFocus,
            ]}
          />
          <Pressable style={styles.border} onPress={handleDone}>
            <ThemedText>Done</ThemedText>
          </Pressable>
        </ThemedView>
      ) : (
        <Pressable
          onPress={() => {
            setIsOpen(true);
          }}
          style={[styles.border, styles.redactable]}
        >
          {children}
        </Pressable>
      )}
    </ThemedView>
  );
}

export function RedactableDate({
  children,
  initialDate,
  redact,
}: PropsWithChildren & {initialDate: Date} & { redact: (value: Date) => void }) {
  const [isOpen, setIsOpen] = useState(false);
  function handleConfirm(date: Date) {
    redact(date);
    setIsOpen(false);
  }
  return (
    <ThemedView>
      <DateTimePickerModal
        isVisible={isOpen}
        mode="date"
        date={initialDate}
        isDarkModeEnabled={true}
        onConfirm={handleConfirm}
        onCancel={() => {
          setIsOpen(false);
        }}
      />
      <Pressable
        onPress={() => {
          setIsOpen(true);
        }}
        style={[styles.border, styles.redactable]}
      >
        {children}
      </Pressable>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  border: {
    color: "white",
    borderWidth: 2,
    borderColor: "white",
    padding: 3,
    borderRadius: 10,
  },
  width: {
    width: "80%",
  },
  maxWidth: {
    maxWidth: "80%",
  },
  minWidth: {
    minWidth: "80%",
  },
  inputFocus: {
    borderWidth: 2,
    borderColor: "#96c26d",
  },
  redactable: {
    borderTopWidth: 0,
    borderLeftWidth: 0,
    borderRightWidth: 0,
    width: "100%",
    borderRadius: 0,
    padding: 0,
    borderStyle: "solid",
  },
});
