import { ThemedView } from "./ThemedView";

export default function Spacer(props: {height: number}){
    return(
        <ThemedView style={{width: '100%', height: props.height}}/>
    )
}