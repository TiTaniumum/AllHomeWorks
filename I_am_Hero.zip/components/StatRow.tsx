import { ThemedText } from "./ThemedText";
import { ThemedView } from "./ThemedView";
import { StyleSheet } from "react-native";
type Props = {
  statName: string;
  statCurrent: number;
  statMax?: number;
};

export default function StatRow({ statName, statCurrent, statMax }: Props) {
  return (
    <ThemedView style={styles.container}>
      <ThemedText style={styles.statName}>{statName}</ThemedText>
      {statMax !== undefined ? (
        <ThemedView style={styles.stats}>
          <ThemedText>{statCurrent}</ThemedText>
          <ThemedText>/</ThemedText>
          <ThemedText>{statMax}</ThemedText>
        </ThemedView>
      ) : (
        <ThemedText>{statCurrent}</ThemedText>
      )}
    </ThemedView>
  );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    stats: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        minWidth: '20%',
    },
    statName: {
        fontSize: 14,
    }
});