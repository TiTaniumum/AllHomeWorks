package com.MySecretDiary.MySecretDiary.exception;

import com.MySecretDiary.MySecretDiary.enums.ErrorCode;
import lombok.Getter;

public class CustomException extends RuntimeException{
    @Getter
    private ErrorCode errorCode;
    public CustomException(ErrorCode errorCode, String message) {

        super(message);
        this.errorCode = errorCode;
    }
}
