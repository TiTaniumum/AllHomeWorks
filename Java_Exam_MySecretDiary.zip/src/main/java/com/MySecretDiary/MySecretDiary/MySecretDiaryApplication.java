package com.MySecretDiary.MySecretDiary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySecretDiaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySecretDiaryApplication.class, args);
	}

}
