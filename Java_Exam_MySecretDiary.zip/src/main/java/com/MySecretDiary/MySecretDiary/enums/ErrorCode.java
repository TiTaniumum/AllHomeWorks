package com.MySecretDiary.MySecretDiary.enums;

public enum ErrorCode {
    NOT_FOUND,
    SERVER_ERROR,
    VALIDATION_ERROR,
    TOO_MANY_ATTEMPTS,
    ALREADY_EXISTS
}