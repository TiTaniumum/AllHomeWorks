package com.MySecretDiary.MySecretDiary.controller;

import com.MySecretDiary.MySecretDiary.dto.*;
import com.MySecretDiary.MySecretDiary.service.DiaryService;
import com.MySecretDiary.MySecretDiary.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/diary")
public class DiaryController {

    private final DiaryService diaryService;
    private final UserService userService;
    private final HttpServletRequest httpServletRequest;

    @GetMapping("/getAll")
    public DiaryListDto GetAllDiaries(){
        return diaryService.GetAll(userService.getUserByToken(httpServletRequest));
    }

    @GetMapping("/getByTitle")
    public DiaryListDto GetByTitle(@RequestParam(required = true) String title){
        return diaryService.GetByTitle(userService.getUserByToken(httpServletRequest), title);
    }

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/add")
    public void AddDiary(@RequestBody NewDiaryDto body){
        diaryService.AddDiary(userService.getUserByToken(httpServletRequest), body);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/editContent")
    public void EditContentDiary(@RequestBody DiaryEditContentDto body){
        diaryService.EditContentDiary(userService.getUserByToken(httpServletRequest),body);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/invite")
    public void InviteContributorToDiary(@RequestBody InvitationDto body){
        diaryService.Invite(userService.getUserByToken(httpServletRequest), body);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/delete")
    public void DeleteDiary(@RequestParam(required = true) Integer diaryId){
        diaryService.Delete(userService.getUserByToken(httpServletRequest), diaryId);
    }

    @GetMapping("/find")
    public DiaryListDto FindDiariesByText(@RequestParam(required = true) String text){
        return diaryService.FindDiariesByText(userService.getUserByToken(httpServletRequest), text);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/updateTags")
    public void UpdateTags(@RequestBody DiaryTagsUpdateDto body){
        diaryService.UpdateTags(userService.getUserByToken(httpServletRequest), body);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/archive")
    public void Archive(@RequestBody ArchiveDto body){
        diaryService.Archive(userService.getUserByToken(httpServletRequest), body);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/unArchive")
    public void UnArchive(@RequestParam(required = true) Integer diaryId){
        diaryService.UnArchive(userService.getUserByToken(httpServletRequest), diaryId);
    }
}
