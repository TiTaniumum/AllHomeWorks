package com.MySecretDiary.MySecretDiary.controller;

import com.MySecretDiary.MySecretDiary.dto.AuthDto;
import com.MySecretDiary.MySecretDiary.dto.LoginRequestDto;
import com.MySecretDiary.MySecretDiary.dto.SignRequestDto;
import com.MySecretDiary.MySecretDiary.service.security.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;


@RestController
@RequiredArgsConstructor
@RequestMapping("/auth")
public class AuthController {
    private final AuthService authService;
    private final HttpServletRequest httpServletRequest;

    @PostMapping("/signup")
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    public void registerUser(@RequestBody SignRequestDto signRequestDto){
        authService.RegisterUser(signRequestDto);
    }

    @PostMapping("/signin")
    public AuthDto authUser(@RequestBody LoginRequestDto loginRequestDto){
        return authService.AuthUser(loginRequestDto, httpServletRequest);
    }
}
