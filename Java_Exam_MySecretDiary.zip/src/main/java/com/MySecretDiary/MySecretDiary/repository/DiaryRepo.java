package com.MySecretDiary.MySecretDiary.repository;

import com.MySecretDiary.MySecretDiary.model.Diary;
import com.MySecretDiary.MySecretDiary.model.security.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DiaryRepo extends JpaRepository<Diary, Integer> {
    List<Diary> findAllByUser(User user);

    List<Diary> findAllByTitle(String title);

    @Query(value = "SELECT * FROM Diary WHERE content LIKE '%?1%';", nativeQuery = true)
    List<Diary> findAllByText(String text);
}
