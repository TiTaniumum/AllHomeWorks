package com.MySecretDiary.MySecretDiary.repository.security;

import com.MySecretDiary.MySecretDiary.model.security.AuthLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface AuthLogRepo extends JpaRepository<AuthLog, Integer> {
    @Query(value="SELECT * FROM auth_log AS a " +
            "WHERE a.user_id = ?1 AND a.user_ip LIKE ?2 " +
            "ORDER BY a.auth_date DESC " +
            "LIMIT 3", nativeQuery = true)
    List<AuthLog> last3AttemptsByUserID(Integer user_id, String user_ip);
}