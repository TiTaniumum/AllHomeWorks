package com.MySecretDiary.MySecretDiary.model.security;

import com.MySecretDiary.MySecretDiary.enums.security.CustomRole;
import com.MySecretDiary.MySecretDiary.model.Diary;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;
import java.util.Set;

@Entity
@Table(name = "user")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "login")
    private String login;

    @Column(name = "password")
    private String password;

    @Column(name = "nickname")
    private String nickname;

    @Column(name = "email")
    private String email;

    @JsonIgnore
    @ManyToMany(mappedBy = "contributors")
    private Set<Diary> diaries;

    @ElementCollection(targetClass = CustomRole.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id"))
    @Enumerated(EnumType.STRING)
    private Set<CustomRole> roles;
}