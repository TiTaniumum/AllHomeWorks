package com.MySecretDiary.MySecretDiary.model.security;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "auth_log")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AuthLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer user_id;

    private LocalDateTime auth_date;

    private String user_ip;

    private Boolean is_successfull;
}