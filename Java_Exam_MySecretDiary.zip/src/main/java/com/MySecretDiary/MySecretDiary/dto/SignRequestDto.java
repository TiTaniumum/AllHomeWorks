package com.MySecretDiary.MySecretDiary.dto;

import lombok.Data;

@Data
public class SignRequestDto {
    private String username;
    private String password;
}
