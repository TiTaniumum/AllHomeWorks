package com.MySecretDiary.MySecretDiary.dto;

import com.MySecretDiary.MySecretDiary.model.Diary;
import lombok.Data;

import java.util.List;

@Data
public class DiaryListDto {
    private final List<Diary> diaries;
}
