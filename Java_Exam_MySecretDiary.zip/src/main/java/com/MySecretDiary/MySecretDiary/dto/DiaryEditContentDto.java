package com.MySecretDiary.MySecretDiary.dto;

import lombok.Data;

@Data
public class DiaryEditContentDto {
    private Integer diary_id;
    private String new_content;
}
