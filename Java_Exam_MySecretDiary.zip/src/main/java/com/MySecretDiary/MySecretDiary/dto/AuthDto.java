package com.MySecretDiary.MySecretDiary.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthDto {
    private String token;
    private String username;
}
