package com.MySecretDiary.MySecretDiary.dto;

import lombok.Data;

@Data
public class InvitationDto {
    private String login;
    private Integer diary_id;
}
