package com.MySecretDiary.MySecretDiary.dto;

import lombok.Data;

import java.util.List;

@Data
public class DiaryTagsUpdateDto {
    private Integer diary_id;
    private List<String> tags;
}
