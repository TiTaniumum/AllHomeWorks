package com.MySecretDiary.MySecretDiary.dto;

import lombok.Data;

import java.util.List;

@Data
public class NewDiaryDto {
    private String title;
    private String content;
    private List<String> tags;
}
