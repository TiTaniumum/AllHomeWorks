package com.MySecretDiary.MySecretDiary.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ArchiveDto {
    private Integer diary_id;
    private LocalDateTime archive_to;
}
