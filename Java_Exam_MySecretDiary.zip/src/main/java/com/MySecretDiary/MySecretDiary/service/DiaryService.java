package com.MySecretDiary.MySecretDiary.service;

import com.MySecretDiary.MySecretDiary.dto.*;
import com.MySecretDiary.MySecretDiary.enums.ErrorCode;
import com.MySecretDiary.MySecretDiary.exception.CustomException;
import com.MySecretDiary.MySecretDiary.exception.UserNotFoundException;
import com.MySecretDiary.MySecretDiary.model.Diary;
import com.MySecretDiary.MySecretDiary.model.security.User;
import com.MySecretDiary.MySecretDiary.repository.DiaryRepo;
import com.MySecretDiary.MySecretDiary.repository.security.UserRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class DiaryService {
    private final DiaryRepo diaryRepo;
    private final UserRepo userRepo;

    private void UserDiaryRelationCheck(User user, Diary diary){
        if(!diary.getUser().getLogin().equals(user.getLogin())) {
            throw new CustomException(ErrorCode.VALIDATION_ERROR, "Current user do not own requested diary.");
        }
    }

    public void AddDiary(User currentUser, NewDiaryDto body){
        Set<String> tags = new HashSet<>(body.getTags());
        Diary diary = new Diary(null,body.getTitle(), body.getContent(), currentUser, new HashSet<>(), tags, LocalDateTime.now(), null);
        diaryRepo.save(diary);
    }

    public DiaryListDto GetAll(User currentUser) {
        List<Diary> list = diaryRepo.findAll();
        List<Diary> result = list.stream().filter((diary)->diary.getUser().getLogin().equals(user.getLogin()) || diary.getContributors().stream().anyMatch((u)->u.getLogin().equals(currentUser.getLogin()))).toList();
        return new DiaryListDto(result);
    }

    public DiaryListDto GetByTitle(User currentUser, String title) {
        List<Diary> list = diaryRepo.findAllByTitle(title);
        List<Diary> result = list.stream().filter((diary)->diary.getUser().getLogin().equals(currentUser.getLogin()) || diary.getContributors().stream().anyMatch((u)->u.getLogin().equals(currentUser.getLogin()))).toList();
        return new DiaryListDto(result);
    }

    public DiaryListDto FindDiariesByText(User currentUser, String text) {
        List<Diary> list = diaryRepo.findAllByText(text);
        List<Diary> result = list.stream().filter((diary)->diary.getUser().getLogin().equals(currentUser.getLogin()) || diary.getContributors().stream().anyMatch((u)->u.getLogin().equals(currentUser.getLogin()))).toList();
        return new DiaryListDto(result);
    }

    public void EditContentDiary(User currentUser,DiaryEditContentDto body) {
        Diary diary = diaryRepo.findById(body.getDiary_id()).orElseThrow(()->new CustomException(ErrorCode.NOT_FOUND,"Diary not found!"));
        UserDiaryRelationCheck(currentUser, diary);
        diary.setContent(body.getNew_content());
        diaryRepo.save(diary);
    }

    public void Invite(User currentUser, InvitationDto body) {
        Diary diary = diaryRepo.findById(body.getDiary_id()).orElseThrow(()->new CustomException(ErrorCode.NOT_FOUND,"Diary not found!"));
        UserDiaryRelationCheck(currentUser, diary);
        User contributor = userRepo.findByLogin(body.getLogin()).orElseThrow(()->new UserNotFoundException("Contributor does not exist!"));
        diary.getContributors().add(contributor);
        diaryRepo.save(diary);
    }

    public void Delete(User currentUser, Integer diaryId) {
        Diary diary = diaryRepo.findById(diaryId).orElseThrow(()->new CustomException(ErrorCode.NOT_FOUND,"Diary not found!"));
        UserDiaryRelationCheck(currentUser, diary);
        diaryRepo.delete(diary);
    }

    public void UpdateTags(User currentUser, DiaryTagsUpdateDto body) {
        Diary diary = diaryRepo.findById(body.getDiary_id()).orElseThrow(()->new CustomException(ErrorCode.NOT_FOUND,"Diary not found!"));
        UserDiaryRelationCheck(currentUser, diary);
        Set<String> tags = new HashSet<>(body.getTags());
        diary.setTags(tags);
        diaryRepo.save(diary);
    }

    public void Archive(User currentUser, ArchiveDto body) {
        Diary diary = diaryRepo.findById(body.getDiary_id()).orElseThrow(()->new CustomException(ErrorCode.NOT_FOUND,"Diary not found!"));
        UserDiaryRelationCheck(currentUser, diary);
        diary.setArchived_until(body.getArchive_to());
        diaryRepo.save(diary);
    }

    public void UnArchive(User currentUser, Integer diaryId) {
        Diary diary = diaryRepo.findById(diaryId).orElseThrow(()->new CustomException(ErrorCode.NOT_FOUND,"Diary not found!"));
        UserDiaryRelationCheck(currentUser, diary);
        diary.setArchived_until(null);
        diaryRepo.save(diary);
    }

}
