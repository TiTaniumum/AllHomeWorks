package com.MySecretDiary.MySecretDiary.service.security;

import com.MySecretDiary.MySecretDiary.dto.AuthDto;
import com.MySecretDiary.MySecretDiary.dto.LoginRequestDto;
import com.MySecretDiary.MySecretDiary.dto.SignRequestDto;
import com.MySecretDiary.MySecretDiary.enums.ErrorCode;
import com.MySecretDiary.MySecretDiary.enums.security.CustomRole;
import com.MySecretDiary.MySecretDiary.exception.CustomException;
import com.MySecretDiary.MySecretDiary.exception.UserNotFoundException;
import com.MySecretDiary.MySecretDiary.model.security.AuthLog;
import com.MySecretDiary.MySecretDiary.model.security.CustomUserDetails;
import com.MySecretDiary.MySecretDiary.model.security.User;
import com.MySecretDiary.MySecretDiary.repository.security.AuthLogRepo;
import com.MySecretDiary.MySecretDiary.repository.security.UserRepo;
import com.MySecretDiary.MySecretDiary.util.security.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final UserRepo userRepo;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authenticationManager;
    private final UserInfoService userInfoService;
    private final JwtService jwtService;
    private final AuthLogRepo authLogRepo;

    public void RegisterUser(SignRequestDto signRequestDto) {
        if(userRepo.findByLogin(signRequestDto.getUsername()).isPresent()){
            throw new CustomException(ErrorCode.ALREADY_EXISTS, "Username already taken!");
        }
        Set<CustomRole> roles = new HashSet<>();
        roles.add(CustomRole.USER);

        User user = User.builder()
                .login(signRequestDto.getUsername())
                .password(encoder.encode(signRequestDto.getPassword()))
                .roles(roles)
                .build();

        userRepo.save(user);
    }

    public AuthDto AuthUser(LoginRequestDto loginRequestDto, HttpServletRequest httpServletRequest){
        User user = userRepo.findByLogin(loginRequestDto.getUsername()).orElseThrow(()-> new UserNotFoundException("Please register first"));
        CustomUserDetails userDetails = (CustomUserDetails)userInfoService.loadUserByUsername(loginRequestDto.getUsername());
        AuthLog authLog = new AuthLog(null,userDetails.getID(), LocalDateTime.now(), httpServletRequest.getRemoteAddr(), false);
        List<AuthLog> authLogList = authLogRepo.last3AttemptsByUserID(userDetails.getID(), httpServletRequest.getRemoteAddr());

        AuthAttempt(user, authLog, authLogList, loginRequestDto);

        authLog.setIs_successfull(true);
        String jwtToken = jwtService.generateToken(userDetails);
        authLogRepo.save(authLog);

        return new AuthDto(jwtToken, loginRequestDto.getUsername());
    }

    private void AuthAttempt(User user, AuthLog authLog, List<AuthLog> authLogList, LoginRequestDto loginRequestDto){
        if(authLogList.size() == 3 && authLogList.stream().noneMatch(AuthLog::getIs_successfull) && Math.abs(Duration.between(authLogList.get(0).getAuth_date(), LocalDateTime.now()).toMinutes()) < 5){
            authLogRepo.save(authLog);
            throw new CustomException(ErrorCode.TOO_MANY_ATTEMPTS ,"Too meny attempts try 5 minutes later");
        }

        if(!encoder.matches(loginRequestDto.getPassword(), user.getPassword())){
            authLogRepo.save(authLog);
            throw new CustomException(ErrorCode.VALIDATION_ERROR ,"Wrong password.");
        }

        try {
            Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequestDto.getUsername(), loginRequestDto.getPassword()));
        }catch(Exception ex){
            authLogRepo.save(authLog);
            throw ex;
        }
    }
}
