package com.MySecretDiary.MySecretDiary.service.security;

import com.MySecretDiary.MySecretDiary.exception.UserNotFoundException;
import com.MySecretDiary.MySecretDiary.model.security.CustomUserDetails;
import com.MySecretDiary.MySecretDiary.model.security.User;
import com.MySecretDiary.MySecretDiary.repository.security.UserRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserInfoService implements UserDetailsService {

    private final UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepo.findByLogin(username).orElseThrow( () -> new UserNotFoundException("User do not exist"));
        return new CustomUserDetails(user);
    }
}

