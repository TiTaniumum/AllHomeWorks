package com.MySecretDiary.MySecretDiary.service;

import com.MySecretDiary.MySecretDiary.exception.UserNotFoundException;
import com.MySecretDiary.MySecretDiary.model.security.User;
import com.MySecretDiary.MySecretDiary.repository.security.UserRepo;
import com.MySecretDiary.MySecretDiary.util.security.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {
    private final JwtService _jwtService;
    private final UserRepo _userRepo;
    public User getUserByToken(HttpServletRequest httpServletRequest){
        String authHeader = httpServletRequest.getHeader("Authorization");
        String token = "";
        String login = "";
        if(authHeader != null && authHeader.startsWith("Bearer ")){
            token = authHeader.substring(7);
            login = _jwtService.decodeUsername(token);
        }
        User currentUser = _userRepo.findByLogin(login).orElseThrow(() -> new UserNotFoundException("DiaryService::getUserByToken"));
        return currentUser;
    }
}
