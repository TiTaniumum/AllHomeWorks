﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using CommonTools;
using CommonTools.ConsoleShortCuts;

namespace csharp8
{
    public enum Language{
        English,
        Russian,
        Kazakh,
    }
    public class Dictionary
    {
        private static readonly List<string> En;
        private static readonly List<string> Ru;
        private static readonly List<string> Kz;

        private Language from;
        private Language to;
        static Dictionary()
        {
            En = new List<string>();
            Ru = new List<string>();
            Kz = new List<string>();
            En.Add("hello");
            En.Add("cat");
            En.Add("goodbye");
            En.Add("dog");
            En.Add("like");
            En.Add("i");
            En.Add("you");
            En.Add("she");
            En.Add("boy");
            En.Add("mistake");
            En.Add("bed");
            En.Add("they");
            En.Add("dad");
            En.Add("mom");
            En.Add("elephant");
            Ru.Add("привет");
            Ru.Add("кошка");
            Ru.Add("пока");
            Ru.Add("собака");
            Ru.Add("нравится");
            Ru.Add("я");
            Ru.Add("ты");
            Ru.Add("она");
            Ru.Add("мальчик");
            Ru.Add("ошибка");
            Ru.Add("кровать");
            Ru.Add("они");
            Ru.Add("папа");
            Ru.Add("мама");
            Ru.Add("слон");
            Kz.Add("салем");
            Kz.Add("мысык");
            Kz.Add("саубол");
            Kz.Add("ит");
            Kz.Add("унайды");
            Kz.Add("мен");
            Kz.Add("сен");
            Kz.Add("ол");
            Kz.Add("ул");
            Kz.Add("кате");
            Kz.Add("тусек");
            Kz.Add("олар");
            Kz.Add("аке");
            Kz.Add("ана");
            Kz.Add("пыл");
        }
        public Dictionary(Language from = Language.English, Language to = Language.Russian)
        {
            this.from=from;
            this.to=to;
        }
        
        private int Search(List<string> values, string text)
        {
            int index = -1;
            for (int i = 0; i < values.Count; i++)
            {
                if (text == values[i]) { index = i; break; }
            }
            return index;
        }

        public string Translate(string text)
        {
            int index = -1;
            switch (from)
            {
                case Language.English: index = Search(En, text); break;
                case Language.Russian: index = Search(Ru, text); break;
                case Language.Kazakh: index = Search(Kz, text); break;
            }
            if(index == -1) return "";
            switch (to)
            {
                case Language.English: return En[index];
                case Language.Russian: return Ru[index];
                case Language.Kazakh: return Kz[index];
            }
            return "";
        }
        private void AskUserProperties()
        {
            Console.Clear();
            C.OutLine("Select Language (from) 1-3 [En,Ru,Kz]");
            int from =0 , to=0;
            while(from<1 || from>3)
            {
                C.In(ref from);
            }
            C.OutLine("Select Language (to) 1-3 [En,Ru,Kz]");
            while(to<1 || to>3)
            {
                C.In(ref to);
            }
            this.from = (Language)(from-1);
            this.to = (Language)(to-1);
        }
        public void Start()
        {
            AskUserProperties();

            string text = string.Empty;
            Console.Clear();
            C.OutLine("Type in 'Exit' to exit.");
            C.OutLine($"Current translation: [{from} - {to}]");
            C.OutLine("Type in Word For Translation:");
            while (text!="Exit")
            {
                C.In(ref text);
                C.OutLine($"{text} - {Translate(text)}");
            }
        }
    }
}
