﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using CommonTools;
using CommonTools.ConsoleShortCuts;
using static System.Console;

namespace csharp8
{
    public enum Difficulty
    {
        Easy,
        Normal,
        Hard,
    }
    public class Sapper
    {
        private List<Point> mines;

        private int width;
        private int height;

        private bool[][] sections;

        private bool isGameOver;

        public Sapper(Difficulty difficulty = Difficulty.Easy)
        {
            isGameOver = false;
            InitMines(difficulty);
            sections = new bool[height][];
            for (int i = 0; i < height; i++)
            {
                sections[i] = new bool[width];
            }
        }

        private void InitMines(Difficulty difficulty)
        {
            Random random = new Random();
            mines = new List<Point>();
            int count = 0;
            switch (difficulty)
            {
                case Difficulty.Easy:
                    count = 5;
                    width = 5;
                    height = 5;
                    break;
                case Difficulty.Normal:
                count = 10;
                    width = 10;
                    height = 10;
                break;
                case Difficulty.Hard:
                count = 15;
                    width = 15;
                    height = 15;
                break;
            }
            for (int i = 0; i < count; i++)
            {
                Point temp = new Point(random.Next(width),random.Next(height));
                if(!isInside(temp)) mines.Add(temp);
            }
        }
        private bool isInside(Point p)
        {
            for (int i = 0;i < mines.Count;i++)
            {
                if(p == mines[i]) return true;
            }
            return false;
        }

        private int MinesAround(int x, int y)
        {
            int cnt = 0;
            cnt = isInside(new Point(x+1, y)) ? cnt+1 : cnt ;
            cnt = isInside(new Point(x+1, y+1)) ? cnt+1 : cnt ;
            cnt = isInside(new Point(x, y+1)) ? cnt+1 : cnt;
            cnt = isInside(new Point(x-1, y+1)) ? cnt+1 : cnt;
            cnt = isInside(new Point(x-1, y)) ? cnt+1 : cnt;
            cnt = isInside(new Point(x-1, y-1)) ? cnt+1 : cnt;
            cnt = isInside(new Point(x, y-1)) ? cnt+1 : cnt;
            cnt = isInside(new Point(x+1, y-1)) ? cnt+1 : cnt;
            return cnt;
        }

        private void Print()
        {
            Console.Clear();
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (sections[i][j])
                    {
                        if (isInside(new Point(j, i)))
                        {
                            Write("☻");
                        }
                        else
                            Write(MinesAround(j, i));   
                    }
                    else
                    {
                        Write('*');
                    }
                }
                WriteLine();
            }
            WriteLine();
        }

        private Point AskUserPoint()
        {
            int x=0,y=0;
            C.Out("type in x ");
            C.In(ref x);
            C.Out("type in y ");
            C.In(ref y);
            return new Point(x,y);
        }

        private void ActivateSection(Point p)
        {
            if (p.X<0|| p.X>=width || p.Y<0 || p.Y>=height) return;
            sections[p.Y][p.X] = true;
            if(isInside(p)) isGameOver = true;
        }

        public void Start()
        {
            while (!isGameOver)
            {
                Print();
                ActivateSection(AskUserPoint());
            }
            Print();
            WriteLine("you loose");
        }
    }
}
