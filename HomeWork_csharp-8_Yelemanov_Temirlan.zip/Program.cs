﻿

using System;


namespace csharp8
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            //Sapper sapper = new Sapper();
            //sapper.Start();
            Dictionary dictionary = new Dictionary();
            dictionary.Start();
        }
    }
}