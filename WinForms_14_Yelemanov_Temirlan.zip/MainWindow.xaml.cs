﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace winformsWPF14
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        double angle = 0;
        private void Viewport3D_MouseDown(object sender, MouseButtonEventArgs e)
        {
        }

        private void Viewport3D_MouseUp(object sender, MouseButtonEventArgs e)
        {
        }

        private void Viewport3D_MouseMove(object sender, MouseEventArgs e)
        {
            this.Title = e.GetPosition(this).ToString() + " " + rotate.Angle;
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                double dx = e.GetPosition(this).X;
                double dy = e.GetPosition(this).Y;
                double x = Width/2;
                double y = Height/2;
                rotate.Axis = new Vector3D(Height/2-dy, Width/2-dx, 0);
                rotate.Angle = Math.Sqrt(Math.Pow(x-dx, 2)+ Math.Pow(y-dy, 2))*-0.4;

                // добился такого эффекта методом тыка и проб
            }
        }

        private void Viewport3D_MouseWheel(object sender,
          MouseWheelEventArgs e)
        {
            Point3D pt = this.camera.Position;
            pt.Z += e.Delta * 0.01;
            this.camera.Position = pt;
            //angle += e.Delta *0.01;
            //rotate.Angle = angle;
        }
    }
}
