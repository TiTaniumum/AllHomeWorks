﻿#include <iostream>
#include <random>
#include <algorithm>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"

using namespace std;

int main()
{
  setlocale(LC_CTYPE, "Russian");
  srand(time(NULL));
  //problem1();
  //problem2();
  problem3(); // задача взятая из STEP > _Problems > _Problems.txt
  cout << "\nend!  . . . . . . . . \n";
}
