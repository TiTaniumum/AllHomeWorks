﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

//Пользователь вводит с клавиатуры четыре цифры. 
//Необходимо создать число, содержащее эти цифры. Например, если с клавиатуры введено 1, 5, 7, 8 тогда нужно 
//сформировать число 1578.

namespace csharp1
{
    public class Problem3
    {
        private int GetNumFromUser()
        {
            int num = 0;
            string temp = string.Empty;
            bool isSuccess = false;
            while (!isSuccess)
            {
                Console.WriteLine("type in number:");
                temp = Console.ReadLine();
                if(int.TryParse(temp, out num)) {
                    isSuccess = true;
                }
                else
                {
                    Console.WriteLine("Not a number, try again.");   
                }
            }
            return num;
        }
        private int GetUnitedNumber()
        {
            int unitedNumber = 0;
            string temp = string.Empty;
            Console.WriteLine("Type in 4 numbers");
            for (int i = 0;i < 4; i++)
            {
                Console.Write($"{i})");
                temp += GetNumFromUser().ToString();
            }
            if(int.TryParse(temp, out unitedNumber))
            {
                return unitedNumber;
            }
            else
            {
                throw new Exception("Error - Problem3:GetUniteNumber() out of int range!");
            }
        }
        public void Start() { 
            try {
                Console.WriteLine("Problem3:");
                Console.WriteLine("Result = " + GetUnitedNumber());
            }
            catch(Exception ex) { 
                Console.WriteLine(ex.Message);
                Start();
            }
        }
    }
}
