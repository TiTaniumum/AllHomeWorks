﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Пользователь вводит с клавиатуры два числа. Нужно 
//показать все четные числа в указанном диапазоне. Если 
//границы диапазона указаны неправильно требуется произвести нормализацию границ. Например, пользователь 
//ввел 20 и 11, требуется нормализация, после которой 
//начало диапазона станет равно 11, а конец 20.

namespace csharp1
{
    public class Problem7
    {
        private int min, max;
        public Problem7()
        {
            min = 0;
            max = 0;
        }
        private void Init() {
            Console.WriteLine("Type in min value: ");
            min = Problem4.GetIntNumFromUser();
            Console.WriteLine("Type in max value: ");
            max = Problem4.GetIntNumFromUser();
            if(min > max)
            {
                int temp = min;
                min = max;
                max = temp;
            }
        }
        public void PrintEvenNumsInRange()
        {
            if (min%2== 1) ++min;
            Console.WriteLine("Even Numbers Result:");
            for (int i = min; i < max; i+=2)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("End of Result.");
        }
        public void Start() {
            Console.WriteLine("Problem7:");
            Init();
            PrintEvenNumsInRange();
        }
    }
}
