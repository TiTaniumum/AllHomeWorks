﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

//Пользователь вводит с клавиатуры дату. Приложение должно отобразить название сезона и дня недели. 
//Например, если введено 22.12.2021, приложение должно 
//отобразить Winter Wednesday.

namespace csharp1
{
    enum Season
    {
        Winter,
        Spring,
        Summer,
        Autumn,
    }
    enum Week
    {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday,
    }
    public class Problem5
    {
        private int day, month, year;
        public Problem5() {
            day = 1;
            month = 1;
            year = 2000;
        }
        private void Init()
        {
            day = GetDay();
            month = GetMonth();
            year = GetYear();
        }
        static public bool IsOverlap(int num, int min, int max)
        {
            if (num < min || num > max)
            {
                Console.WriteLine($"Not In Range of {min} to {max}.");
                return false;
            }
            return true;
        }
        static public int GetNumFromUserInRangeOf(int min, int max)
        {
            int num = 0;
            do
            {
                num = Problem4.GetIntNumFromUser();

            } while (!IsOverlap(num, min, max));
            return num;
        }
        private int GetDay()
        {
            Console.WriteLine("Type in day:");
            int day = GetNumFromUserInRangeOf(1, 31);
            return day;
        }
        private int GetMonth()
        {
            Console.WriteLine("Type in Month");
            int month = GetNumFromUserInRangeOf(1, 12);
            return month;
        }
        private int GetYear()
        {
            Console.WriteLine("Type in Year");
            int year = GetNumFromUserInRangeOf(2000, 2023);
            return year;
        }
        public void Print()
        {
            Console.WriteLine();
            Console.WriteLine($"{day}.{month}.{year}");

            switch (month)
            {
                case 12:
                case 1:
                case 2: Console.Write(Season.Winter); break;
                case 3:
                case 4:
                case 5: Console.Write(Season.Spring); break;
                case 6:
                case 7:
                case 8: Console.Write(Season.Summer); break;
                case 9:
                case 10:
                case 11: Console.Write(Season.Autumn); break;
                default: Console.WriteLine("Something went wrong!"); break;
            }

            Console.WriteLine( " " + (Week)(day%7));
        }
        public void Start()
        {
            // я не стал углубляться в правильность выведения недели по дате 
            Console.WriteLine("Problem5:");
            Init();
            Print();
        }
    }
}
