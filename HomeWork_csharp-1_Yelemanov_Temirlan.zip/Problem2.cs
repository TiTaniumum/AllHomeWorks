﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Пользователь вводит с клавиатуры два числа. Первое 
//число — это значение, второе число процент, который 
//необходимо посчитать. Например, мы ввели с клавиатуры 
//90 и 10. Требуется вывести на экран 10 процентов от 90. 
//Результат: 9.

namespace csharp1
{
    public class Problem2
    {
        public static float GetFloatNumFromUser()
        {
            float num = 0f;
            bool isNumCorrect = false;
            string temp = string.Empty;
            while(!isNumCorrect) {
                Console.WriteLine("type in num:");
                temp = Console.ReadLine();
                if(float.TryParse(temp, out num)) {
                    isNumCorrect= true;
                }
                else
                {
                    Console.WriteLine("Not a number try again.");
                }
            }
            return num;
        }
        private float CalcProcentage(float num, float procentage)
        {
            float result = (num*procentage)/100f;
            return result;
        } 
        public void Start()
        {
            Console.WriteLine("Problem2: ");
            Console.WriteLine("Type in number then procentage:");
            Console.WriteLine("Result = " + CalcProcentage(GetFloatNumFromUser(), GetFloatNumFromUser()));
        } 
    }
}
