﻿using csharp1;
using System;

namespace HomeWork1
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            Problem1 problem1 = new Problem1();
            problem1.Start();
            Problem2 problem2 = new Problem2();
            problem2.Start();
            Problem3 problem3 = new Problem3();
            problem3.Start();
            Problem4 problem4 = new Problem4();
            problem4.Start();
            Problem5 problem5 = new Problem5();
            problem5.Start();
            Problem6 problem6 = new Problem6();
            problem6.Start();
            Problem7 problem7 = new Problem7();
            problem7.Start();
        }
    }
}