﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

//Пользователь вводит шестизначное число. После чего 
//пользователь вводит номера разрядов для обмена цифр. 
//Например, если пользователь ввёл один и шесть — это 
//значит, что надо обменять местами первую и шестую 
//цифры.
//Число 723895 должно превратиться в 523897.
//Если пользователь ввел не шестизначное число требуется вывести сообщение об ошибке

namespace csharp1
{
    public class Problem4
    {
        static public int GetIntNumFromUser()
        {
            int num = 0;
            string temp = string.Empty;
            bool isSuccess = false;
            while(!isSuccess)
            {
                Console.WriteLine("type in number:");
                temp = Console.ReadLine();
                if(int.TryParse(temp, out num))
                {
                    isSuccess = true;
                }
                else
                {
                    Console.WriteLine("Not a Number or out of int range, try again.");
                }
            }
            return num;
        }
        private bool IsInRange(int num, int idx)
        {          
            if (idx >0 && idx <= num.ToString().Length)
            {
                return true;
            }
            else {
                Console.WriteLine($"{idx} is not in range of 1 to {num.ToString().Length}");
                return false;
            }
        }
        private int SwapIntegersByIndex(int num, int first, int second)
        {
            if (first == second) return num;

            char[] tempArr = num.ToString().ToCharArray();
            char temp = tempArr[first];
            tempArr[first] = tempArr[second];
            tempArr[second] = temp;
            string tempStr = new string(tempArr);
            return num = Convert.ToInt32(tempStr);
        }
        public void Start()
        {
            Console.WriteLine("Problem4:");
            int Number = GetIntNumFromUser();
            int index1 = -1, index2 = -1;
            Console.WriteLine("Type in 2 indexes to swap integers in upper number:");
            do{
                Console.WriteLine("First index:");
                index1 = GetIntNumFromUser();
            } while (!IsInRange(Number, index1));

            do{
                Console.WriteLine("Second index:");
                index2 = GetIntNumFromUser();
            } while (!IsInRange(Number, index2));

            --index1;
            --index2;

            Number = SwapIntegersByIndex(Number, index1, index2);

            Console.WriteLine("Result = " + Number);
        }
    }
}
