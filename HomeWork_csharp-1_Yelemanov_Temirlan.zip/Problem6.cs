﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

//Пользователь вводит с клавиатуры показания температуры.
//В зависимости от выбора пользователя программа переводит температуру из Фаренгейта в Цельсий 
//или наоборот.

namespace csharp1
{
    enum TempretureType
    {
        Fahrenheit,
        Celsius,
    }
    public class Problem6
    {
        TempretureType tempretureType;
        float tempreture;

        private void Init()
        {
            AskUserTempretureType();
            AskUserTempreture();
        }
        private void AskUserTempretureType()
        {
            Console.WriteLine("Type in Tempreture type 0(Fahrenheit), 1(Celsius):");
            tempretureType = (TempretureType)Problem5.GetNumFromUserInRangeOf(0, 1);
        }
        private void AskUserTempreture()
        {
            Console.WriteLine("Type in Tempreture:");
            tempreture = Problem2.GetFloatNumFromUser();
        }
        private TempretureType AskUserTempretureTypeToShow()
        {
            Console.WriteLine("Type in  Tempreture type 0(Fahrenheit), 1(Celsius) to Show in:");
            TempretureType tempretureType = (TempretureType)Problem5.GetNumFromUserInRangeOf(0, 1);
            return tempretureType;
        }
        public void Print()
        {
            TempretureType tempretureTypeToShow = AskUserTempretureTypeToShow();
            if (tempretureTypeToShow == tempretureType)
            {
                Console.WriteLine(tempreture + " " +  tempretureType);
            }
            else if (tempretureType == TempretureType.Celsius)
            {
                Console.WriteLine((32f+(tempreture*1.8f)) + " " + tempretureTypeToShow);
            }
            else
            {
                Console.WriteLine(((tempreture-32f)*(5f/9f)) + " " + tempretureTypeToShow);
            }
        }
        public void Start()
        {
            Console.WriteLine("Problem6:");
            Init();
            Print();
        }
    }
}
