﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_9
{
    public interface IWorker { }
    public interface IManager { 
        public List<IWorker> workers { get; set; }
    }
    public abstract class Human{}
    public abstract class Employee : Human{}
    public class Scientist :Employee, IWorker{}
    public class Manager : Employee, IWorker, IManager{
        public List<IWorker> workers { get; set; }
    }
    public class Speciallist : Employee, IWorker{}
    public sealed class Tutor: Human, IWorker{}
    public abstract class Learner : Human{}
    public class ShoolChild : Learner{}
    public class Student : Learner{}
}
