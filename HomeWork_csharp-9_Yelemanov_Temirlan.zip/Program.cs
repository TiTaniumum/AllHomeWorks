﻿using csharp_9;
using System;


namespace csharp9
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            BattleSeaGame game = new BattleSeaGame();
            game.Start();
        }
        public static void Demo2()
        {
            LivingBeings<Monkey> living = new LivingBeings<Monkey>();
            living.Add(new Monkey());
        }
        public static void Demo1()
        {
            Manager manager = new Manager();
            manager.workers.Add(new Manager());
            manager.workers.Add(new Scientist());
            manager.workers.Add(new Speciallist());
            manager.workers.Add(new Tutor());
        }

    }
}