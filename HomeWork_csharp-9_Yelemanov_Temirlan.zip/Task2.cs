﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_9
{
    public class Person
    {
        public string Name { get; set; }
    }
    public class Monkey
    {
        public string Name { get; set; }
    }

    class LivingBeings<T> {
        List<T> items;

        public LivingBeings()
        {
            items = new List<T>();
        }
        public void Add(T item) { 
            items.Add(item);
        }
    }
}
