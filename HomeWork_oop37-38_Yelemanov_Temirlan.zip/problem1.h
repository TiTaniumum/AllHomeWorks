#pragma once
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
#define RAND(min, max) min+ rand()%(max - (min)+1)
struct LC { LC() { srand(time(NULL)); } ~LC() { cout << "\nEND . . . . . . . . . . .\n"; cin.get(); } }_;

//������� 1
//������� ����������� ������� ����� "������������ ��������" � ����������� ������ "����������", "���������", "�������".
//���������� ����� � ��������� ��������� ���������� � ������ ������ ������������ ���������.

class Transport {
protected:
  double speed_km_h;
  double costPerHour;
public: 
  Transport() : speed_km_h(), costPerHour() {}
  Transport(double Speed, double CostPerHour) : speed_km_h(Speed), costPerHour(CostPerHour) {}
  virtual double CalcTime_hByDistanceAndSpeed(double distnace_m) = 0;
  virtual double CalcCostByDistance(double distance_m) = 0;
  virtual void PrintByDistance(double distance_m) = 0;
  virtual void Print() {
    cout << "Speed: " << speed_km_h << "km/h | Cost per hour: " << costPerHour  << "\n";
  }
  virtual ~Transport() {};
};

class Auto : virtual public Transport {
protected:
  //double time;
  //double cost;
public:
  Auto() {}
  Auto(double Speed, double CostPerHour) : Transport(Speed, CostPerHour) {}
  Auto(bool isRandom) : Transport() {
    speed_km_h = RAND(40, 70);
    costPerHour = RAND(10000, 50000);
  }
  virtual double CalcTime_hByDistanceAndSpeed(double distance_m)override {
    return (distance_m/1000) / speed_km_h;
  }
  virtual double CalcCostByDistance(double distance_m) override{
    return CalcTime_hByDistanceAndSpeed(distance_m) * costPerHour;
  }
  virtual void PrintByDistance(double distance_m) override{
    cout << "Auto: drive on " << distance_m << "m will cost " << CalcCostByDistance(distance_m) << "tg and will take " << CalcTime_hByDistanceAndSpeed(distance_m) * 60 << " minutes";
  }
  virtual ~Auto() {}
};

class Bycicle : public virtual Transport {
public:
  Bycicle() {}
  Bycicle(double Speed, double CostPerHour) : Transport(Speed, CostPerHour) {}
  Bycicle(bool isRandom) : Transport() {
    speed_km_h = RAND(10, 20);
    costPerHour = RAND(2500, 5000);
  }
  virtual double CalcTime_hByDistanceAndSpeed(double distance_m)override {
    return (distance_m / 1000) / speed_km_h;
  }
  virtual double CalcCostByDistance(double distance_m) override {
    return CalcTime_hByDistanceAndSpeed(distance_m) * costPerHour;
  }
  virtual void PrintByDistance(double distance_m) override {
    cout << "Bycicle: drive on " << distance_m << "m will cost " << CalcCostByDistance(distance_m) << "tg and will take " << CalcTime_hByDistanceAndSpeed(distance_m) * 60 << " minutes";
  }
  virtual ~Bycicle() {}
};

class Train:public virtual Transport {
public:
  Train() {}
  Train(double Speed, double CostPerHour) : Transport(Speed, CostPerHour) {}
  Train(bool isRandom) : Transport() {
    speed_km_h = RAND(60, 100);
    costPerHour = RAND(3000, 7000);
  }
  virtual double CalcTime_hByDistanceAndSpeed(double distance_m)override {
    return (distance_m / 1000) / speed_km_h;
  }
  virtual double CalcCostByDistance(double distance_m) override {
    return CalcTime_hByDistanceAndSpeed(distance_m) * costPerHour;
  }
  virtual void PrintByDistance(double distance_m) override {
    cout << "Train: drive on " << distance_m << "m will cost " << CalcCostByDistance(distance_m) << "tg and will take " << CalcTime_hByDistanceAndSpeed(distance_m) * 60 << " minutes";
  }
  virtual ~Train() {}
};

void problem1() {
  for (size_t i = 0; i < 3; i++)
  {
    Transport* temp = new Auto(true);
    temp->Print();
    temp->PrintByDistance(RAND(3000, RAND_MAX));
    cin.get();
    delete temp;
  }
  cout << endl;
  for (size_t i = 0; i < 3; i++)
  {
    Transport* temp = new Bycicle(true);
    temp->Print();
    temp->PrintByDistance(RAND(3000, RAND_MAX));
    cin.get();
    delete temp;
  }
  cout << endl;
  for (size_t i = 0; i < 3; i++)
  {
    Transport* temp = new Train(true);
    temp->Print();
    temp->PrintByDistance(RAND(3000, RAND_MAX));
    cin.get();
    delete temp;
  }
}