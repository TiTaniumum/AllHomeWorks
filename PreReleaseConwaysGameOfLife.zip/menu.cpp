#include <iostream>
#include <string>
#include "win10.h"
using namespace std;

bool getSettingBool(int a);
void changeSettingBool(int a);
int selectionMove(int& select, int length);

int menu(string* m, int length, int row, int col, int select = 0) {
  SetConsoleSize(210, 50);
  system("cls");
  SetPos(5, 45);
  SetColor(7, 0);
  cout << "CONWAY'S GAME OF LIFE!";
  while (true) {
    SetColor(0, 1);
    for (size_t i = 0; i < length; i++)
    {
      SetPos(row + i, col);
      if (select == i) {
        SetColor(0, 5);
        cout << "[" << m[i] << "]";
        SetColor(0, 1);
      }
      else {
        cout << " " << m[i] << " ";
      }
    }
    switch (selectionMove(select, length)) {
    case 0: break;
    case -1:
    case 1:
      system("cls");
      return select;
    }
  }
}

void settings(string* m, int length, int row, int col) {
  int select = 0;
  system("cls");
  while (true) {
    SetPos(5, 45);
    SetColor(7, 0);
    cout << "Press ESC to go Back";
    SetPos(6, 45);
    cout << "Press ENTER to change setting";
    SetColor(0, 1);
    for (size_t i = 0; i < length; i++)
    {
      SetPos(row + i, col);
      if (select == i) {
        SetColor(0, 5);
        cout << "[" << m[i] << "]";
        SetColor(0, 1);
        cout << " = " << boolalpha << getSettingBool(i);
      }
      else {
        cout << " " << m[i] << " ";
        cout << " = " << boolalpha << getSettingBool(i);
      }
    }
    switch (selectionMove(select, length)) {
    case 0:break;
    case 1:
      system("cls");
      changeSettingBool(select);
      break;
    case -1:
      system("cls");
      return;
    }
  }
}

bool loadMenu(string* m, int length, int row, int col) {
  int select = 0;
  system("cls");
  while (true) {
    SetPos(5, 45);
    SetColor(7, 0);
    cout << "Press ESC to go Back";
    SetPos(6, 45);
    cout << "Press ENTER to load Template";
    SetColor(0, 1);
    for (size_t i = 0; i < length; i++)
    {
      SetPos(row + i, col);
      if (select == i) {
        SetColor(0, 5);
        cout << "[" << m[i] << "]";
        SetColor(0, 1);
      }
      else {
        cout << " " << m[i] << " ";
      }
    }
    switch (selectionMove(select, length)) {
    case 0:break;
    case 1:
      system("cls");
      loadTemplate(select);
      return true;
    case -1:
      system("cls");
      return false;
    }
  }
}

int selectionMove(int& select, int length) {
  int key = _getch();
  switch (key) {
  case _KEY::UP:
    select = (select == 0) ? length - 1 : select - 1;
    return 0;
    break;
  case _KEY::DOWN:
    select = (select == length - 1) ? 0 : select + 1;
    return 0;
    break;
  case _KEY::ENTER:
    return 1;
    break;
  case _KEY::ESC:
    select = -1;
    return -1;
    break;
  }
}