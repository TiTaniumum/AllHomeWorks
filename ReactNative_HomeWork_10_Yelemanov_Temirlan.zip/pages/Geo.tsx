import { useState, useEffect } from "react";
import { Text, View, Button, StyleSheet } from "react-native";
import * as Location from "expo-location";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";

export enum WeatherType {
  standard = "standard",
  metric = "metric",
  imperial = "imperial",
}

export interface WeatherData {
  main: {
    temp: number;
  };
  weather: {
    main: string;
    description: string;
  }[];
}

export interface WeatherLocation {
  name: string;
  local_names: any;
  lat: number;
  lon: number;
  country: string;
  state: string;
}

export async function fetchWeatherLocation<Type>(
  lat: any,
  lon: any,
  weatherType: WeatherType = WeatherType.metric
): Promise<Awaited<Type | null>> {
  try {
    const limit = 1;
    const api = "cddeb6aba3195facd31fcdde86d70713";
    const url = `http://api.openweathermap.org/geo/1.0/reverse?lat=${lat}&lon=${lon}&limit=${limit}&appid=${api}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("404");
    }
    const data = await response.json();
    console.info(data);
    return data;
  } catch (ex) {
    console.error("Ошибка при загрузки API: ", ex);
  }
  return null;
}

export async function fetchWeather<Type>(
  city: string,
  weatherType: WeatherType = WeatherType.metric
): Promise<Awaited<Type | null>> {
  try {
    const api = "cddeb6aba3195facd31fcdde86d70713";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${api}&units=${weatherType}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("404");
    }
    const data = await response.json();
    console.info(data);
    return data;
  } catch (ex) {
    console.error("Ошибка при загрузки API: ", ex);
  }
  return null;
}

function getColorByWeather(weather: string) {
  let value = weather.toLowerCase();
  switch (value) {
    case "clear":
      return "blue";
    case "sunny":
      return "yellow";
    case "rain":
    case "thunder":
    case 'thunderstorm':
      return "gray";
    case "cloudy":
      return "#d1d1d1";
    case "snow":
      return "white";
    default:
      return "white";
  }
}

export default function Geo() {
  const [location, setLocation] = useState<null | Location.LocationObject>(
    null
  );
  const [error, setError] = useState<null | string>(null);
  const [address, setAddress] = useState<null | string>(null);
  const [weatherlocation, setWeatherLocation] =
    useState<WeatherLocation | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);

  async function updateStory() {
    const storyJSON = await AsyncStorage.getItem("story");
    if (storyJSON) {
      const story: Location.LocationObject[] = JSON.parse(storyJSON);
      if (location) story.push(location);
      await AsyncStorage.setItem("story", JSON.stringify(story));
    } else {
      await AsyncStorage.setItem("story", "[]");
    }
  }

  async function getLocation() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setError(null);
    setAddress(null);
    setWeatherLocation(null);
    setWeather(null);
    let { status } = await Location.requestForegroundPermissionsAsync();

    if (status !== "granted") {
      setError("Нет разрешения");
    }

    let locObj = await Location.getCurrentPositionAsync();
    setLocation(locObj);
    const { latitude, longitude } = locObj.coords;
    //getAddress(latitude, longitude);
    const data = await fetchWeatherLocation<WeatherLocation[]>(
      latitude,
      longitude
    );
    if (data) {
      setWeatherLocation(data[0]);
      const weatherData = await fetchWeather<WeatherData>(data[0].name);
      setWeather(weatherData);
    }
    updateStory();
  }

  // Я убрал подписку на Google API. Они выстовили мне счет.
  async function getAddress(latitude: any, longtitude: any) {
    const key = "AIzaSyAq-x15J3aema2sETqvyFKh8tRXZAjIs5M";
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longtitude}&key=${key}`;
    const response = await fetch(url);
    const data = await response.json();
    if (data.results.length > 0) {
      const address = data.results[0].formatted_address;
      setAddress(address);
    } else {
      setError("не понял..");
    }
  }
  useEffect(() => {
    getLocation();
  }, []);

  return (
    <View style={[styles.container, {backgroundColor: weather ? getColorByWeather(weather.weather[0].main) : 'white'}]}>
      {error ? (
        <Text>{error}</Text>
      ) : (
        <>
          <Text> Долгота: {location?.coords.longitude} </Text>
          <Text> Широта: {location?.coords.latitude} </Text>
          <Text> Высота: {location?.coords.altitude} </Text>
          {/* <Text> Адресс: {address} </Text> */}
          {weatherlocation ? (
            <View>
              <Text>{weatherlocation.name} </Text>
            </View>
          ) : (
            <Text>Загрузка данных</Text>
          )}
          {weather ? (
            <View>
              <Text>{weather.main.temp} °C</Text>
              <Text>{weather.weather[0].main}</Text>
            </View>
          ) : (
            <Text>Загрузка данных</Text>
          )}
        </>
      )}
      <Button title="Где я?" onPress={getLocation} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
