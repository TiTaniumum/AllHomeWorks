import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { View,Text, FlatList, StyleSheet} from "react-native";
import * as Location from "expo-location";

export default function LocationStory({navigation}: any){
    const [story, setStory] = useState<Location.LocationObject[] | null>(null)

    useEffect(()=>{
        async function getStory() {
            const storyJSON = await AsyncStorage.getItem('story');
            if(storyJSON){
                setStory(JSON.parse(storyJSON));
            }
        }
        getStory();
    });

    return (
        <View style={styles.container}>
            <FlatList data={story} renderItem={({item})=>(<View style={styles.item}>
                <Text>latitude: {item.coords.latitude}</Text>
                <Text>longtitude: {item.coords.longitude}</Text>
                <Text>altitude: {item.coords.altitude}</Text>
                <Text>Time: {(new Date(item.timestamp)).toLocaleTimeString()} {(new Date(item.timestamp)).toLocaleDateString()}</Text>
            </View>)}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    item:{
        padding: 10
    }
  });