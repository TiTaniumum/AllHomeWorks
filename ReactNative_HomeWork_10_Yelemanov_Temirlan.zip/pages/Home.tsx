import { Button, View, StyleSheet } from "react-native";


export default function Home({navigation}: any){
    return(
        <View style={styles.container}>
            <Button title="Compass" onPress={()=>{navigation.navigate("Compass")}}/>
            <Button title="Geo" onPress={()=>{navigation.navigate("Geo")}}/>
            <Button title="LocationStory" onPress={()=>{navigation.navigate("LocationStory")}}/>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });