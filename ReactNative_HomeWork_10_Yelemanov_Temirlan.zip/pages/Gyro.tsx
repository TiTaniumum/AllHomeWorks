import * as React from 'react';
import { Text, View, StyleSheet }from "react-native";
import { Gyroscope } from 'expo-sensors';
import { useEffect, useState } from 'react';

export default function Gyro(){
    const [gyroData, setGyroData] = useState({
        x:0,
        y:0,
        z:0,
    });

    useEffect(()=>{
        const coord = Gyroscope.addListener(result =>{
            setGyroData(result);
        });
        return ()=>{coord.remove()};
    },[]);

    return (
        <View style={styles.container}>
            <View style={[{position:'absolute', bottom: 350 + gyroData.x*20, left: 150 + gyroData.y*20, width: 100, height: 100, backgroundColor:'red', alignItems: 'center', justifyContent: 'center'}]}>
            <Text>x: {gyroData.x.toFixed(2)}</Text>
            <Text>y: {gyroData.y.toFixed(2)}</Text>
            <Text>z: {gyroData.z.toFixed(2)}</Text>

            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });