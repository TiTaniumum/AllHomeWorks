import * as React from 'react';
import { Text, View, StyleSheet }from "react-native";
import { useEffect, useState } from 'react';
import { Magnetometer, MagnetometerMeasurement } from 'expo-sensors';


export default function Compass(){
    const[compassData,setCompassData] = useState<MagnetometerMeasurement>();
    useEffect(()=>{
        const coordinates = Magnetometer.addListener(result=>{
            setCompassData(result);
        })
        return ()=>coordinates.remove();
    },[]);

    const getDirection = ()=>{
        if(compassData){
            let{x,y,z} = compassData;
            let angle = Math.atan2(y,x) * (180/ Math.PI);
            if(angle< 0){
                angle = 360+ angle;
            }
            return Math.round(angle);
        }
        return 0;
    }

    function nesw(degree:number){
        if(degree >= 45 && degree < 135)
            return 'N';
        if(degree >= 135 && degree < 225)
            return 'E';
        if(degree >= 225 && degree < 315)
            return 'S';
        return 'W';
    }

    return(
        <View style={styles.container} >
            <Text>{getDirection()}</Text>
            <Text>{nesw(getDirection())}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignItems: "center",
      justifyContent: "center",
    },
  });
  