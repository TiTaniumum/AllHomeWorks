import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

import Gyro from './pages/Gyro';
import Geo from './pages/Geo';
import Compass from './pages/Compass';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './pages/Home';
import LocationStory from './pages/LocationStory';

const RootStack = createNativeStackNavigator();

export default function App() {

  return (
    <NavigationContainer>
      <RootStack.Navigator>
        <RootStack.Group>
          <RootStack.Screen
            name="Home"
            component={Home}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen
            name="Geo"
            component={Geo}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen
            name="Compass"
            component={Compass}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen
            name="LocationStory"
            component={LocationStory}
            options={({ navigation }) => ({})}
          />
        </RootStack.Group>
      </RootStack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
