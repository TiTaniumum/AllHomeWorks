#include "problem1.h"
#include "queue.h"
#include "problem2.h"
int main() {
  problem2();
}