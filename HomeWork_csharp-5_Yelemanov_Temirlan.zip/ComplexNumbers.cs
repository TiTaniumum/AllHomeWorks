﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

//Реализовать класс для хранения комплексного числа. Выполнить в нем перегрузку всех необходимых 
//операторов для успешной компиляции следующего 
//фрагмента кода:
// Complex z = new Complex(1, 1);
//Complex z1;
//z1 = z - (z * z * z - 1) / (3 * z * z);
//Console.WriteLine("z1 = {0}", z1);
//Краткая справка по комплексным числам 
//(из Википедии):
//• Любое комплексное число может быть представлено 
//как формальная сумма x + iy, где x и y — вещественные 
//51
//Домашнее задание
//числа, i — мнимая единица, то есть число, удовлетворяющее уравнению i^2 = − 1

namespace csharp5
{
    public class ComplexN
    {
        public double m_real { get; }
        public double m_imaginary { get; }

        public ComplexN(double real, double imaginary) {
            m_real = real;
            m_imaginary = imaginary;
        }

        public static ComplexN operator -(ComplexN value)  /* Unary negation of a complex number */
        {
            return new ComplexN(-value.m_real, -value.m_imaginary);
        }

        public static ComplexN operator +(ComplexN left, ComplexN right)
        {
            return new ComplexN(left.m_real + right.m_real, left.m_imaginary + right.m_imaginary);
        }

        public static ComplexN operator +(ComplexN left, double right)
        {
            return new ComplexN(left.m_real + right, left.m_imaginary);
        }

        public static ComplexN operator +(double left, ComplexN right)
        {
            return new ComplexN(left + right.m_real, right.m_imaginary);
        }

        public static ComplexN operator -(ComplexN left, ComplexN right)
        {
            return new ComplexN(left.m_real - right.m_real, left.m_imaginary - right.m_imaginary);
        }

        public static ComplexN operator -(ComplexN left, double right)
        {
            return new ComplexN(left.m_real - right, left.m_imaginary);
        }

        public static ComplexN operator -(double left, ComplexN right)
        {
            return new ComplexN(left - right.m_real, -right.m_imaginary);
        }

        public static ComplexN operator *(ComplexN left, ComplexN right)
        {
            // Multiplication:  (a + bi)(c + di) = (ac -bd) + (bc + ad)i
            double result_realpart = (left.m_real * right.m_real) - (left.m_imaginary * right.m_imaginary);
            double result_imaginarypart = (left.m_imaginary * right.m_real) + (left.m_real * right.m_imaginary);
            return new ComplexN(result_realpart, result_imaginarypart);
        }

        public static ComplexN operator *(ComplexN left, double right)
        {
            if (!double.IsFinite(left.m_real))
            {
                if (!double.IsFinite(left.m_imaginary))
                {
                    return new ComplexN(double.NaN, double.NaN);
                }

                return new ComplexN(left.m_real * right, double.NaN);
            }

            if (!double.IsFinite(left.m_imaginary))
            {
                return new ComplexN(double.NaN, left.m_imaginary * right);
            }

            return new ComplexN(left.m_real * right, left.m_imaginary * right);
        }

        public static ComplexN operator *(double left, ComplexN right)
        {
            if (!double.IsFinite(right.m_real))
            {
                if (!double.IsFinite(right.m_imaginary))
                {
                    return new ComplexN(double.NaN, double.NaN);
                }

                return new ComplexN(left * right.m_real, double.NaN);
            }

            if (!double.IsFinite(right.m_imaginary))
            {
                return new ComplexN(double.NaN, left * right.m_imaginary);
            }

            return new ComplexN(left * right.m_real, left * right.m_imaginary);
        }

        public static ComplexN operator /(ComplexN left, ComplexN right)
        {
            // Division : Smith's formula.
            double a = left.m_real;
            double b = left.m_imaginary;
            double c = right.m_real;
            double d = right.m_imaginary;

            // Computing c * c + d * d will overflow even in cases where the actual result of the division does not overflow.
            if (Math.Abs(d) < Math.Abs(c))
            {
                double doc = d / c;
                return new ComplexN((a + b * doc) / (c + d * doc), (b - a * doc) / (c + d * doc));
            }
            else
            {
                double cod = c / d;
                return new ComplexN((b + a * cod) / (d + c * cod), (-a + b * cod) / (d + c * cod));
            }
        }

        public static ComplexN operator /(ComplexN left, double right)
        {
            // IEEE prohibit optimizations which are value changing
            // so we make sure that behaviour for the simplified version exactly match
            // full version.
            if (right == 0)
            {
                return new ComplexN(double.NaN, double.NaN);
            }

            if (!double.IsFinite(left.m_real))
            {
                if (!double.IsFinite(left.m_imaginary))
                {
                    return new ComplexN(double.NaN, double.NaN);
                }

                return new ComplexN(left.m_real / right, double.NaN);
            }

            if (!double.IsFinite(left.m_imaginary))
            {
                return new ComplexN(double.NaN, left.m_imaginary / right);
            }

            // Here the actual optimized version of code.
            return new ComplexN(left.m_real / right, left.m_imaginary / right);
        }

        public static ComplexN operator /(double left, ComplexN right)
        {
            // Division : Smith's formula.
            double a = left;
            double c = right.m_real;
            double d = right.m_imaginary;

            // Computing c * c + d * d will overflow even in cases where the actual result of the division does not overflow.
            if (Math.Abs(d) < Math.Abs(c))
            {
                double doc = d / c;
                return new ComplexN(a / (c + d * doc), (-a * doc) / (c + d * doc));
            }
            else
            {
                double cod = c / d;
                return new ComplexN(a * cod / (d + c * cod), -a / (d + c * cod));
            }
        }
        public override string ToString() => $"({m_real}, {m_imaginary})";
    }
}
