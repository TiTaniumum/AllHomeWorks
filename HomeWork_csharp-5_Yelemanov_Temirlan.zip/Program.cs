﻿using System;
using System.Numerics;

namespace csharp5
{
    public class MainClass
    {

        public static void Main(string[] args)
        {
            //FirstProblem();   
            //SecondProblem();
            ThirdProblem();
        }
        public static void FirstProblem()
        {
            LinearEquasion first = new LinearEquasion(1, 1);
            LinearEquasion second = new LinearEquasion(2, 2);
            first.Equasion(second);
        }
        public static void SecondProblem()
        {
            ComplexN z = new ComplexN(1, 1);
            ComplexN z1;
            z1 = z - (z * z * z - 1) / (3 * z * z);
            Console.WriteLine("z1 = {0}", z1);
        }
        public static void ThirdProblem()
        {
            Fraction f = new Fraction(3, 4);
            int a = 10;
            Fraction f1 = f * a;
            Fraction f2 = a * f;
            double d = 1.5;
            Fraction f3 = f + d;
            Console.WriteLine(f.Result);
            Console.WriteLine(f1.Result);
            Console.WriteLine(f2.Result);
            Console.WriteLine(f3.Result);
        }
    }
}