﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

//1.Разработать собственный структурный тип данных 
//для хранения целочисленных коэффициентов A и B 
//линейного уравнения A×X + B×Y = 0. в классе реализовать статический метод Parse(), которые принимает 
//строку со значениями коэффициентов, разделенных 
//запятой или пробелом.
//2. Разработать метод для решения системы 2 линейных 
//уравнений:
//A1×X + B1×Y = 0
//A2×X + B2×Y = 0
//Метод с помощью выходных параметров должен 
//возвращать найденное решение или ошибку, если 
//решения не существует.

namespace csharp5
{
    public class LinearEquasion
    {
        public float A { get; set; }
        public float B { get; set; }
        public LinearEquasion(float a, float b)
        {
            A=a;
            B=b;
        }
        public static LinearEquasion Parse(string s) {
            LinearEquasion temp; 
            int a = int.Parse(s);
            int b = int.Parse(s);
            temp = new LinearEquasion(a, b);
            return temp;
        }
        public void Equasion(LinearEquasion second)
        {
            float x = 0/(second.A + second.B*-(A/B));
            float y = (-(A*x))/B;
            Console.WriteLine("Решение всегда будет ранво 0!");
            Console.WriteLine($"X = {x}, Y = {y}");
        }
    }
}
