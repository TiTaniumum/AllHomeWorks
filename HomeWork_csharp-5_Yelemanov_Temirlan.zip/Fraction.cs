﻿using csharp5;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

//Разработать класс Fraction, представляющий простую 
//дробь. в классе предусмотреть два поля: числитель
//и знаменатель дроби. Выполнить перегрузку следующих операторов: +,-,*,/,==,!=,<,>, true и false.
//Арифметические действия и сравнение выполняется 
//в соответствии с правилами работы с дробями. Оператор true возвращает true если дробь правильная 
//(числитель меньше знаменателя), оператор false
//возвращает true если дробь неправильная (числитель 
//больше знаменателя).
//Выполнить перегрузку операторов, необходимых для 
//успешной компиляции следующего фрагмента кода:
//Fraction f = new Fraction(3, 4);
//int a = 10;
//Fraction f1 = f * a;
//Fraction f2 = a * f;
//double d = 1.5;
//Fraction f3 = f + d;

namespace csharp5
{
    public class Fraction
    {
        private int numerator;
        private int denominator;
        public double Result { get { return (double)numerator/(double)denominator; } }
        public Fraction(int numerator, int denominator)
        {
            this.numerator=numerator;
            this.denominator=denominator;
        }

        public static Fraction operator +(Fraction left, Fraction right)
        {
            if (left.denominator!=right.denominator)
            {
                Fraction temp1 = new Fraction(left.numerator*right.denominator, left.denominator*right.denominator);
                Fraction temp2 = new Fraction(right.numerator*left.denominator, right.denominator*left.denominator);
                return new Fraction(temp1.numerator+ temp2.numerator, temp1.denominator);
            }
            return new Fraction(left.numerator+right.denominator, left.denominator);
        }
        public static Fraction operator +(int left, Fraction right)
        {
            if (right.denominator == 1)
            {
                return new Fraction(left+ right.numerator, right.denominator);
            }
            return new Fraction(left*right.denominator + right.numerator, right.denominator);
        }

        public static Fraction operator +(Fraction left, int right)
        {
            if (left.denominator == 1)
            {
                return new Fraction(right+ left.numerator, left.denominator);
            }
            return new Fraction(right*left.denominator + left.numerator, left.denominator);
        }

        public static Fraction operator +(Fraction left, double right)
        {
            Fraction temp = Fraction.Parse(right, 5);
            return left+temp;
        }
        public static Fraction operator +(double left, Fraction right)
        {
            Fraction temp = Fraction.Parse(left, 5);
            return temp+right;
        }
        public static Fraction operator -(Fraction left, Fraction right) {
            if (left.denominator!=right.denominator)
            {
                Fraction temp1 = new Fraction(left.numerator*right.denominator, left.denominator*right.denominator);
                Fraction temp2 = new Fraction(right.numerator*left.denominator, right.denominator*left.denominator);
                return new Fraction(temp1.numerator- temp2.numerator, temp1.denominator);
            }
            return new Fraction(left.numerator - right.denominator, left.denominator);
        }
        public static Fraction operator -(int left, Fraction right)
        {
            if (right.denominator == 1)
            {
                return new Fraction(left-right.numerator, right.denominator);
            }
            return new Fraction(left*right.denominator-right.numerator, right.denominator);
        }
        public static Fraction operator -(Fraction left, int right)
        {
            if (left.denominator == 1)
            {
                return new Fraction(left.numerator-right, left.denominator);
            }
            return new Fraction(left.numerator-right*left.denominator, left.denominator);
        }
        public static Fraction operator -(Fraction left,double right)
        {
            Fraction temp = Fraction.Parse(right, 5);
            return left-temp;
        }
        public static Fraction operator -(double left,Fraction right)
        {
            Fraction temp = Fraction.Parse(left, 5);
            return temp - right;
        }

        public static Fraction operator *(Fraction left, Fraction right)
        {
            return new Fraction(left.numerator*right.numerator, left.denominator*right.denominator);
        }
        public static Fraction operator *(int left, Fraction right)
        {
            return new Fraction(left*right.numerator, right.denominator);
        }
        public static Fraction operator*(Fraction left, int right){
            return new Fraction(left.numerator*right, left.denominator);
        }
        public static Fraction operator/(Fraction left, Fraction right)
        {
            return new Fraction(left.numerator* right.denominator, left.denominator*right.numerator);
        }
        public static Fraction operator/(int left, Fraction right)
        {
            return new Fraction(left*right.denominator, right.numerator);
        }
        public static Fraction operator/(Fraction left, int right)
        {
            return new Fraction(left.numerator,left.denominator*right);
        }

        public static bool operator==(Fraction left, Fraction right)
        {
            return left.Result == right.Result;
        }
        public static bool operator!=(Fraction left, Fraction right)
        {
            return left.Result != right.Result;
        }
        public static bool operator <(Fraction left, Fraction right)
        {
            return left.Result < right.Result;
        }
        public static bool operator >(Fraction left, Fraction right)
        {
            return left.Result > right.Result;
        }
        public static bool operator true(Fraction value)
        {
            return value.numerator < value.denominator;
        }
        public static bool operator false(Fraction value)
        {
            return value.numerator >value.denominator;
        }

        public static Fraction Parse(double value, int presicion)
        {
            int denumerator = 1;
            for (int i = 0; i < presicion; i++)
            {
                denumerator*=10;
            }
            return new Fraction((int)(value*denumerator), denumerator);
        }
    }
}
