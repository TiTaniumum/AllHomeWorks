import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class Pizza extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html; charset=UTF-8");
        req.getRequestDispatcher("/pizza.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html; charset=UTF-8");
        String addr = req.getParameter("address");
        if(addr.indexOf("Zheltoksan") == -1){ // FUCKING ENCODING BUG!!!!!!!!!!!!!!!!!!!!!!!!!!!!! IT DOESN'T ACCEPT CIRILLIC CHARS
            req.setAttribute("isOk", false);
            req.setAttribute("address", addr);
            req.getRequestDispatcher("/ans.jsp").forward(req,resp);
        }else{
            req.setAttribute("isOk", true);
            req.setAttribute("address", addr);
            req.getRequestDispatcher("/ans.jsp").forward(req, resp);
        }
    }
}
