import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class MainClass {
    public static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        //Demo1();
        //Demo2();
        //Demo3();
        //Demo4();
        Demo5();
    }
    public static void Demo1(){
        System.out.println("Type in file name to compare");
        String filename1 = scanner.nextLine();
        System.out.println("Type in file to compare with");
        String filename2 = scanner.nextLine();
        try(Reader reader1 = new FileReader(filename1);
            BufferedReader buffer1 = new BufferedReader(reader1);
            Reader reader2 = new FileReader(filename2);
            BufferedReader buffer2 = new BufferedReader(reader2); ) {
            String line1, line2;
            line1 =buffer1.readLine();
            line2 = buffer2.readLine();
            while(line1 != null && line2 != null){
                if(!line1.equals(line2)){
                    System.out.println(line1);
                }
                line1 = buffer1.readLine();
                line2 = buffer2.readLine();
            }
            if(line1 != null){
                System.out.println(filename1 + " is longer than " + filename2);
            }
            if(line2 != null){
                System.out.println(filename2 + " is longer than " + filename1 );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void Demo2(){
        String filename = scanner.nextLine();
        try(Reader reader = new FileReader(filename);
            BufferedReader buffer = new BufferedReader(reader)){
            String line;
            int maxlength;
            String longestLine;
            line = buffer.readLine();
            maxlength = line.length();
            longestLine = line;
            while(line != null){
                if(line.length() > maxlength){
                    longestLine = line;
                    maxlength = line.length();
                }
                line = buffer.readLine();
            }
            System.out.println("Max length line [" + maxlength +"]: " + longestLine);
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public static void Demo3(){
        String filename = "arrs.txt";
        List<Integer[]> list = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(filename))){
            String line;
            while((line = br.readLine()) != null){
                list.add(StringToIntArr(line));
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }

        for(Integer[] arrItem: list){
            List<Integer> tmp = Arrays.asList(arrItem);
            int max = Collections.max(tmp);
            int sum = Arrays.stream(arrItem).mapToInt(Integer::intValue).sum();
            System.out.println(tmp.toString());
            System.out.println("max: " + max);
            System.out.println("sum: " + sum);
        }
    }

    public static void Demo4(){
        String filename = "demo4.txt";
        List<Integer> list = List.of(1,2,3,4,5,6,7,8,9,10);
        try(BufferedWriter br = new BufferedWriter(new FileWriter(filename))){
            br.write(list.toString());
            br.newLine();
            br.write(list.stream().filter(n->n%2 == 0).toList().toString());
            br.newLine();
            br.write(list.stream().filter(n->n%2 == 1).toList().toString());
            br.newLine();
            br.write(list.reversed().toString());
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public static void Demo5(){
        List<Personal> personal = List.of(
            new Personal(1, "Ralph"),
            new Personal(2, "Gro"),
            new Personal(3, "Hella")
        );
        Corporation corporation = new Corporation(personal);

        try(BufferedWriter bw = new BufferedWriter(new FileWriter("corporation.txt"))){
            bw.write(corporation.toString());
        }catch (Exception e) { e.printStackTrace(); }

    }

    public static Integer[] StringToIntArr(String line){
        String[] arr = line.split(" ");
        Integer[] result = new Integer[arr.length];
        for(int i = 0; i< arr.length; i++){
            result[i] = Integer.parseInt(arr[i]);
        }
        return result;
    }
}
