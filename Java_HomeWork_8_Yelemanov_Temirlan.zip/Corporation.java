import java.util.List;

public class Corporation {
    private List<Personal> personal;

    public Corporation(List<Personal> personal) {
        this.personal = personal;
    }
    public List<Personal> getPersonal() {
        return personal;
    }
    public void setPersonal(List<Personal> personal) {
        this.personal = personal;
    }
    @Override
    public String toString() {
        return "Corporation [personal=" + personal + "]";
    }
    
}
