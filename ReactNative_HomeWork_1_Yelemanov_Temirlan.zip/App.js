import { StatusBar } from 'expo-status-bar';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { TextInput } from 'react-native';
import { Button, Image } from 'react-native';
import { useState, useEffect} from 'react';

export default function App() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [result, setResult] = useState((<></>));

  const func = () => {
    setLogin('');
    setPassword('');
    setPhone('');
    setEmail('');
    getResult();
    
  }
  function getResult(){
    setResult((
      <View style={styles.card}>
        <Text>Register INFO:</Text>
        <Text>Login: {login}</Text>
        <Text>Phone: {phone}</Text>
        <Text>Email: {email}</Text>
      </View>
  ));
  }

  const Spacer = ({ size }) => <View style={{ height: size }} />;

  return (
    <ScrollView style={styles.body}>
      <View style={styles.header}>
        <Image source={require("./assets/logo.png")} style={styles.logo}/>
        <Text style={styles.text}>unamicon</Text>
      </View>
      <View style={styles.container}>
        <View style={styles.width}>
          <Text>Username:</Text>
          <TextInput placeholder="Example: Allan" placeholderTextColor='gray' style={styles.input} onChangeText={(login) => setLogin(login)} value={login}></TextInput>
        </View>
        <View style={styles.width}>
          <Text>Phone number:</Text>
          <TextInput placeholder="87776665544" placeholderTextColor='gray' style={styles.input} onChangeText={(phone) => setPhone(phone)} value={phone}/>
        </View>
        <View style={styles.width}>
          <Text>Email</Text>
          <TextInput placeholder="Allan@gmail.com" placeholderTextColor='gray' style={styles.input} onChangeText={email=>setEmail(email)} value={email}/>
        </View>
        <Button title="Sugn up" onPress={func} />
        <StatusBar style="auto" />
      </View>
      <Spacer size={20}></Spacer>
      {result}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  body: {
    flex: 1,
    height: '100%',
    width: '100%',
    padding: '5%',
    paddingTop: '10%'
  },
  container: {
    flex: 1,
    width: '100%',
    maxHeight: 400,
    minHeight: 400,
    flexDirection: 'column',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
    padding: '5%',
    borderWidth: 2,
    borderRadius: 20,
  },
  card: {
    flex: 1,
    width: '100%',
    maxHeight: 200,
    minHeight: 200,
    flexDirection: 'column',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
    padding: '5%',
    borderWidth: 2,
    borderRadius: 20,
  },
  input: {
    width: '100%',
    borderColor: 'black',
    borderRadius: 10,
    padding: 5,
    borderWidth: 1
  },
  header: {
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    gap: 10,
    width: '100%',
    maxHeight: 300,
    fontFamily: 'pixel_pirate',
  },
  width:{
    width: '100%'
  },
  logo:{
    height: 100,
    width: 100,
    resizeMode:'cover'
  },
  text:{
    color: 'rgba(110, 15, 36, 0.8)',
    fontFamily: 'Geostar-Regular',
    fontSize: 30
  }
});