﻿using System;
using System.Threading;
using System.Threading.Tasks;

//Домашнее задание
//Тема: Потоки

//Пополнительное (не обязательное) задание в файле "DZ_SP_3.pdf"

namespace Sys2
{
    internal class MainClass
    {
        public static void Main(string[] args)
        {
            Demo1 demo1 = new Demo1();
            demo1.Run();
        }
    }
}