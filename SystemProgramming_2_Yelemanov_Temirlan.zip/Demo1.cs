﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Обязательные задания

//1) Создайте консольное или оконное приложение, которое позволяет пользователю запустить несколько потоков.
//Один поток генерирует целые числа, другой дробные числа, третий символы и т.д.

//2) Добавьте механизм синхронизации между потоками, что бы вывод информации на экране не был смешанным.
//Т.е. чтобы потоки по очереди выводили информацию на экран.

namespace Sys2
{
    public class Demo1
    {
        public Random random = new Random();
        public Demo1()
        {
        }
        public void WriteNumber()
        {
            Console.WriteLine(random.Next(0, 10000));
        }
        public void WriteSymbol()
        {
            Console.WriteLine((char)random.Next('a', 'z'));
        }

        public void WriteDoubleNumber()
        {
            int multiplyer = 10;
            int length = random.Next(0, 10);
            for (int i = 0; i < length; i++)
            {
                multiplyer*=10;
            }
            Console.WriteLine(random.NextDouble()*multiplyer);
        }
        public void Run(int count = 5)
        {
            Thread thread1; 
            Thread thread2; 
            Thread thread3; 
            for (int i = 0; i < count; i++)
            {
                thread1 = new Thread(WriteNumber);
                thread2 = new Thread(WriteDoubleNumber);
                thread3 = new Thread(WriteSymbol);
                thread1.Start();
                thread1.Join();
                thread2.Start();
                thread2.Join();
                thread3.Start();
                thread3.Join();
                Console.WriteLine("--------------------------");
            }
        }
    }
}
