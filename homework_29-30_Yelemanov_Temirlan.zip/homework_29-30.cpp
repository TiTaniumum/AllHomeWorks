﻿#include <iostream>
#include <algorithm>
#include <iomanip>
#include <random>
#include <chrono>
#include <stdlib.h>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
#include "problem7.h"
using namespace std;


int main()
{
  srand(time(NULL));
  //problem1();
  //problem2();
  //problem3();
  //problem4();
  //дополнительные
  //problem5();
  //problem6();
  problem7();
  cout << "\nend!\n";
}