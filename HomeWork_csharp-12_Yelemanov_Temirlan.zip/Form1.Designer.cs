﻿namespace csharp12Forms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox1=new ComboBox();
            listBox1=new ListBox();
            textBox1=new TextBox();
            listBox2=new ListBox();
            label1=new Label();
            comboBox2=new ComboBox();
            label2=new Label();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled=true;
            comboBox1.Items.AddRange(new object[] { "C:\\", "D:\\" });
            comboBox1.Location=new Point(12, 65);
            comboBox1.Name="comboBox1";
            comboBox1.Size=new Size(314, 28);
            comboBox1.TabIndex=0;
            comboBox1.SelectedIndexChanged+=comboBox1_SelectedIndexChanged;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled=true;
            listBox1.ItemHeight=20;
            listBox1.Location=new Point(12, 102);
            listBox1.Name="listBox1";
            listBox1.Size=new Size(314, 364);
            listBox1.TabIndex=1;
            listBox1.SelectedIndexChanged+=listBox1_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Location=new Point(344, 65);
            textBox1.Name="textBox1";
            textBox1.Size=new Size(444, 27);
            textBox1.TabIndex=2;
            textBox1.TextChanged+=textBox1_TextChanged;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled=true;
            listBox2.ItemHeight=20;
            listBox2.Location=new Point(344, 102);
            listBox2.Name="listBox2";
            listBox2.Size=new Size(444, 364);
            listBox2.TabIndex=3;
            listBox2.SelectedIndexChanged+=listBox2_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize=true;
            label1.Location=new Point(12, 31);
            label1.Name="label1";
            label1.Size=new Size(101, 20);
            label1.TabIndex=4;
            label1.Text="Выбор Диска";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled=true;
            comboBox2.Items.AddRange(new object[] { "A-Z", "Z-A" });
            comboBox2.Location=new Point(344, 31);
            comboBox2.Name="comboBox2";
            comboBox2.Size=new Size(444, 28);
            comboBox2.TabIndex=5;
            comboBox2.SelectedIndexChanged+=comboBox2_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize=true;
            label2.Location=new Point(344, 8);
            label2.Name="label2";
            label2.Size=new Size(92, 20);
            label2.TabIndex=6;
            label2.Text="Сортировка";
            // 
            // Form1
            // 
            AutoScaleDimensions=new SizeF(8F, 20F);
            AutoScaleMode=AutoScaleMode.Font;
            ClientSize=new Size(803, 478);
            Controls.Add(label2);
            Controls.Add(comboBox2);
            Controls.Add(label1);
            Controls.Add(listBox2);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Controls.Add(comboBox1);
            Name="Form1";
            Text="Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private ListBox listBox1;
        private TextBox textBox1;
        private ListBox listBox2;
        private Label label1;
        private ComboBox comboBox2;
        private Label label2;
    }
}