#pragma once
#include <iostream>
#include <string>
#include <algorithm>
#include <random>
using namespace std;
#define RAND(min,max) min+rand()%(max-min+1)
struct LC { LC() { srand(time(NULL)); } ~LC() { cout << "\n END . . . . . . . . . . \n"; cin.get(); } }_;

//������� 1
//� ����� �������� ����� "�������" (�� ����������� ��������� �������),
//�������� � ���������� ����������� �����������, �������� �����������.
//��� �� � ������ "�������" �� �������� ����������� ����������.
//����������������� ������ � ������� � ������� main().


string GenerateString(int min = 3, int max = 15) {
  string str("");
  int length(RAND(min, max));
  str += RAND('A', 'Z');
  for (size_t i(0); i < length - 1; i++)
  {
    str += RAND('a', 'z');
  }
  return str;
}

class Product {
  string name;
  string producer;
  string description;
  int cost;
  int count;
public:
  Product(string Name = "", string Producer = "", string Description = "", int Cost = 0, int Count = 0)
    : name(Name), producer(Producer), description(Description), cost(Cost), count(Count) {}
  Product(bool isRandom) :Product() {
    if (isRandom) {
      name = GenerateString();
      producer = GenerateString();
      description = GenerateString();
      cost = rand();
      count = rand();
    }
  }
  Product(const Product& p) :name(p.name), producer(p.producer), description(p.description), cost(p.cost), count(p.count) {}
  Product& operator = (const Product& p) {
    name = p.name;
    producer = p.producer;
    description = p.description;
    cost = p.cost;
    count = p.count;
    return *this;
  }
  Product& operator = (Product&& p) {
    name = p.name;
    producer = p.producer;
    description = p.description;
    cost = p.cost;
    count = p.count;
    return *this;
  }
  ~Product() {}
  string getName()const { return name; }
  string getProducer()const { return producer; }
  string getDescription()const { return description; }
  int getCost()const { return cost; }
  int getCount()const { return count; }
  void setName(string str) { name = str; }
  void setProducer(string str) { producer = str; }
  void setDescription(string str) { description = str; }
  void setCost(int num) { cost = num; }
  void setCount(int num) { count = num; }
  void print() {
    cout << "product name: " << getName() << " | producer: " << getProducer() << " | Description: " << getDescription();
    cout << " | cost: " << getCost() << " | count: " << getCount() << "\n";
  }
  void input() {
    string str;
    cout << "type in product name: ";
    getline(cin, str);
    setName(str);
    cout << "type in producer: ";
    getline(cin, str);
    setProducer(str);
    cout << "type in description: ";
    getline(cin, str);
    setDescription(str);
    cout << "type in cost: ";
    int num;
    (cin >> num).ignore();
    setCost(num);
    cout << "type in count: ";
    (cin >> num).ignore();
    setCount(num);
  }
};

class Shop {
  string name;
  int length;
  Product* arr;
public:
  Shop(string Name = "", int Length = 0) :name(Name), length(Length), arr(new Product[length]) {}
  Shop(bool isRandom) :Shop() {
    if (isRandom) {
      delete[]arr;
      name = GenerateString();
      length = RAND(1, 10);
      arr = new Product[length];
      for (size_t i = 0; i < length; i++)
      {
        arr[i] = Product(true);
      }
    }
  }
  Shop(const Shop& sh):name(sh.name),length(sh.length), arr(new Product[length]) {
    for (size_t i = 0; i < length; i++)
    {
      arr[i] = sh.arr[i];
    }
  }
  Shop& operator = (const Shop& sh) {
    delete[]arr;
    name = sh.name;
    length = sh.length;
    arr = new Product[length];
    for (size_t i = 0; i < length; i++)
    {
      arr[i] = sh.arr[i];
    }
    return *this;
  }
  ~Shop() { delete[]arr; }
  string getName()const { return name; }
  int getLength()const { return length; }
  void setName(string str) { name = str; }
  void setLength(int num) {
    Product* temp = new Product[num];
    int newLength((num > length) ? length : num);
    for (size_t i(0); i < newLength; i++)
    {
      temp[i] = arr[i];
    }
    delete[]arr;
    arr = temp;
    length = num;
  }
  void print() {
    cout << "shop name: " << getName() << "\n";
    for (size_t i = 0; i < length; i++)
    {
      arr[i].print();
    }
  }
  void printByCost(int min, int max) {
    cout << "products that has cost in range from " << min << " to " << max << ":\n";
    for (size_t i = 0; i < length; i++)
    {
      if (arr[i].getCost() >= min && arr[i].getCost() <= max)arr[i].print();
    }
  }
  void printByCostInput() {
    cout << "type in min cost: ";
    int min;
    (cin >> min).ignore();
    cout << "type in max cost: ";
    int max;
    (cin >> max).ignore();
    printByCost(min, max);
  }
  void searchByName(string str) {
    cout << "product that has name " << str << ":\n";
    for (size_t i = 0; i < length; i++)
    {
      if (arr[i].getName() == str)arr[i].print();
    }
  }
  void searchByProducer(string str) {
    cout << "product's producer name " << str << ":\n";
    for (size_t i = 0; i < length; i++)
    {
      if (arr[i].getProducer() == str)arr[i].print();
    }
  }
  void sortByName() {
    sort(arr, arr + length, [](Product p1, Product p2)
      {return (p1.getName() < p2.getName() ? true : false); });
  }
  void sortByProducer() {
    sort(arr, arr + length, [](Product p1, Product p2)
      {return (p1.getProducer() < p2.getProducer() ? true : false); });
  }
  void sortByCost() {
    sort(arr, arr + length, [](Product p1, Product p2)
      {return (p1.getCost() < p2.getCost() ? true : false); });
  }
  void editProductName(int index, const string& str) {
    if (index >= length || index < 0)return;
    arr[index].setName(str);
  }
};

void problem1() {
  Shop sh(true);
  cout << "sh:\n";
  sh.print();
  Shop sh1(sh);
  cout << "sh1:\n";
  sh1.print();
  Shop sh2 = sh1;
  cout << "sh2:\n";
  sh2.print();
}