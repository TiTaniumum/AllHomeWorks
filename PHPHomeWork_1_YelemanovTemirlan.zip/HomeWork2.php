<?php
    $X = isset($_POST["X"]) ? @$_POST["X"] :null;
    $Y = isset($_POST["Y"]) ? @$_POST["Y"] :null;
    $qorterResult = null;
    if($X != null&& $Y != null){
        $qorter = ($X <=> 0) . ($Y <=> 0);
        switch($qorter){
            case "11": $qorterResult = "I";  break;
            case "-11":$qorterResult = "II"; break;
            case "-1-1":$qorterResult = "III"; break;
            case "1-1":$qorterResult= "IV"; break;
            case "10": $qorterResult = "Y Axis is 0";break;
            case "-10":$qorterResult = "Y Axis is 0"; break;
            case "01": $qorterResult = "X Axis is 0";break;
            case "0-1":$qorterResult = "X Axis is 0"; break;
            case "00": $qorterResult = "X and Y Axises are 0"; break;
        }
    }

    $val1 = isset($_POST["value1"]) ? @$_POST["value1"] : null;
    $operation = isset($_POST["operation"]) ? @$_POST["operation"] : null;
    $val2 = isset($_POST["value2"]) ? @$_POST["value2"] : null;
    $calculationResult = null;
    if($val1 != null && $val2 != null){
        switch($operation){
            case "+": $calculationResult = $val1 + $val2; break;
            case "-": $calculationResult = $val1 - $val2; break;
            case "/":
                if($val2 == 0)$calculationResult = "Division by zero";
                else $calculationResult = $val1 / $val2; break;
            case "*": $calculationResult = $val1 * $val2; break;
            default: break;
        }
        $calculationResult = (string)$calculationResult;
    }

    $age = isset($_POST["age"]) ? (int)@$_POST["age"] : null;
    $ageResult = null;
    if($age != null){
        if($age < 0) $ageResult = "You are not born yet";
        else if($age>=0 && $age<=12) $ageResult = "You are a baby";
        else if($age>12 && $age<=18) $ageResult = "You are a teenager";
        else if($age>18 && $age<=60) $ageResult = "You are an adult";
        else if($age>60 && $age<=90) $ageResult = "You are an pensioner";
        else if($age>90 && $age<=110) $ageResult = "You are a really old person";
        else if($age>110 && $age<=150) $ageResult = "You are a very rich person"; 
        else if($age>150 && $age<=400) $ageResult = "You are an elf";
        else if($age>400 && $age<=1000) $ageResult = "Are you an Alien?";
        else if($age>1000 && $age<=10000) $ageResult = "You are a godlike creature";
        else if($age>10000 && $age<=1000000000) $ageResult = "You are celestial object";
        else $ageResult = "You are a god";
    }

    $val3 = isset($_POST["numWith3Digits"]) ? @$_POST["numWith3Digits"] : null;
    $areAllDigitsEqual = null;
    if($val3 != null){
        if(strlen($val3) >3 || strlen($val3) < 3) $areAllDigitsEqual = "Too many or not enough digits in your num";
        else if($val3[0] == $val3[1] && $val3[1] == $val3[2]){
            $areAllDigitsEqual = "All digits in your number are equal";
        }else{
            $areAllDigitsEqual = "Not all of the digits are equal";
        }
    }
    //usd => kzt = 467.05
    //usd => eur = 0.93
    //usd => UAH = 35.92
    $KZT = 467.05;
    $EUR = 0.93;
    $UAH = 35.92;
    $usd = isset($_POST["usd"]) ? @$_POST["usd"] : null;
    $currency = isset($_POST["currency"]) ? $_POST["currency"] : null;
    $currencyResult = null;
    if($usd != null){
        switch($currency){
            case "KZT": $currencyResult = $usd * $KZT; break;
            case "EUR": $currencyResult = $usd * $EUR; break;
            case "UAH": $currencyResult = $usd * $UAH; break;
            default: break;
        }
    }
    
    $question1 = isset($_POST["question1"]) ? @$_POST["question1"] : null;
    $question2 = isset($_POST["question2"]) ? @$_POST["question2"] : null;
    $question3 = isset($_POST["question3"]) ? @$_POST["question3"] : null;
    $question4 = isset($_POST["question4"]) ? @$_POST["question4"] : null;
    $QuestionResult = ($question1 != null ? ($question1 == 3 ? 2: 0) : 0) + 
                       ($question2 != null ? ($question2 == 1 ? 2: 0) : 0) +
                       ($question3 != null ? ($question3 == 4 ? 2: 0) : 0) +
                       ($question4 != null ? ($question4 == 2 ? 2: 0) : 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomeWork2</title>
</head>
<body>
    <form action="HomeWork2.php" method="post">
        <div>
            Input (X,Y) coords:
            <input type="number" name="X">
            <input type="number" name="Y">
            <button type="submit">Check</button>
            <br>
            <?php if($qorterResult!=null)echo $qorterResult;?>
        </div>
        <hr>
        <div>
            Calculator:
            <input type="number" name="value1">
            <select name="operation" id="">
                <option value="+">+</option>
                <option value="-">-</option>
                <option value="/">/</option>
                <option value="*">*</option>
            </select>
            <input type="number" name="value2">
            <button type="submit">Check</button>
            Reusult = <?php if($calculationResult!= null) echo $calculationResult?>
        </div>
        <hr>
        <div>
            Type in how old are you:
            <input type="number" name="age">
            <button type="submit">Check</button>
            <br>
            <?php if($ageResult!= null) echo $ageResult;?>
        </div>
        <hr>
        <div>
            Type in number 3 digits long:
            <input type="number" name="numWith3Digits">
            <button type="submit">Check</button>
            <?php if($areAllDigitsEqual != null) echo $areAllDigitsEqual;?>
        </div>
        <hr>
        <div>
            USD:
            <input type="number" name="usd">
            <select name="currency" id="">
                <option value="EUR">EUR</option>
                <option value="UAH">UAH</option>
                <option value="KZT">KZT</option>
            </select>
            <button type="submit">Check</button>
            Result = <?php if($currencyResult != null) echo $currencyResult;?>
        </div>
        <hr>
        <div>
        Question 1: How many hours there are in a day? <br>
        1. 12 <br>
        2. 24 <br>
        3. 23:56 <br>
        4. 23:55 <br>
        <input type="number" name="question1"><br>
        Question 2: Ulfric Stromcloack is a Jarl of? <br>
        1. Windhelm<br>
        2. Markarth<br>
        3. Riverwood<br>
        4. Rorickstead<br>
        <input type="number" name="question2"><br>
        Question 3: What type of magic is forbidden in a DragonAge series?<br>
        1.Necromancy<br>
        2.All magic<br>
        3.Dark magic<br>
        4.Blood magic<br>
        <input type="number" name="question3"><br>
        Question 4: Loop back ip is?<br>
        1. 0.0.0.0<br>
        2. 127.0.0.1<br>
        3. 192.168.1.1<br>
        4. 192.168.1.0<br>
        <input type="number" name="question4"><br>
        <button type="submit">Check</button>
        <br>
        Result = <?=$QuestionResult?>
        </div>
    </form>
</body>
</html>