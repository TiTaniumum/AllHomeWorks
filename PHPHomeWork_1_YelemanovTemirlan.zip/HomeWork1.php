<?php
$VarA = isset($_POST["VarA"]) ? (int)@$_POST["VarA"] : 0;
$VarB = isset($_POST["VarB"]) ? (int)@$_POST["VarB"] : 0;
$VarC = isset($_POST["VarC"]) ? (int)@$_POST["VarC"] : 0;
$D = $VarB * $VarB - 4 * $VarA * $VarC;

if ($VarA == 0 && $VarB != 0) $EquationResult = "X = " . (-$VarC / $VarB);
else if ($VarA == 0 && $VarB == 0) $EquationResult = "$VarC = $VarC";
else {
    switch ($D <=> 0) {
        case 1:
            $EquationResult = "X1: " . ((-$VarB + sqrt($D)) / (2 * $VarA)) . " X2: " . (-$VarB - sqrt($D)) / (2 * $VarA);
            break;
        case 0:
            $EquationResult = "X1: " . (-$VarB / (2 * $VarA));
            break;
        case -1:
            $EquationResult = "No Roots";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="HomeWork1.php" method="post">
        <div>
            Input values of quadratic equation:
            <input type="number" name="VarA">
            <input type="number" name="VarB">
            <input type="number" name="VarC">
            <button type="submit">Check</button>
            <h3>Discriminant: <?= $D ?></h3>
            <h3>Equation result: <?= $EquationResult ?></h3>
        </div>
        <a href="phpInfo.php">Get PHP Version INFO</a>
        <hr>
        <div>
            Input any number:
            <input type="number" name="number1">
            <input type="number" name="number2">
            <input type="number" name="number3">
            <button type="submit">Check</button>
            <h3>sum of sqr numbers = <?= pow((int)@$_POST["number1"], 2) + pow((int)@$_POST["number2"], 2) + pow((int)@$_POST["number3"], 2) ?></h3>
        </div>
        <hr>
        <div>
            Дано два числа: 197 и 454. Найдите сумму 40% от первого
            числа и 84% от второго числа.
            Result = <?= (197 * 0.4 + 454 * 0.84) ?>
        </div>
        <hr>
        <div>
            Дана входная строка со словами «Hello World». Измените
            порядок слов в обратном порядке.
            Result =
            <?php
            $string = "Hello World";
            echo strrev($string);
            ?>
        </div>
        <hr>
        <div> Создайте переменную и присвойте в качестве значения
            любую строку. Выведите на экран количество символов в этой
            строке.
            <br>
            "Hello World" length =
            <?php
            $str = "Hello Wolrd";
            echo strlen($str);
            ?>
        </div>
        <hr>
        <div>
            Current date = <?= $date1 = getdate()["mday"] . "-" . getdate()["mon"] . "-" . getdate()["year"];?>
            <br>
            Days to the next month = <?php
            $nextMonth = getdate()["mon"]+1;
            if($nextMonth>12) $nextMonth = 1;
            $date2 = 1 . "-" . $nextMonth . "-" . getdate()["year"];
            echo date_diff(date_create($date1), date_create($date2))->format('%R%a');
            ?>
        </div>
    </form>
</body>

</html>