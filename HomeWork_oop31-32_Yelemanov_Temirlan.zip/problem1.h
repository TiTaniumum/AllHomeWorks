#pragma once
#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
#include <iterator>
using namespace std;
#define RAND(min,max) min+rand()%(max-(min)+1)
struct LC { LC() { srand(time(NULL)); }~LC() { cout << "\nEND . . . . . . . .\n"; cin.get(); } }_;

//������� 1.
//������� ������� ����� ��������� �������� � ����������� ������ �������, ������, ��������.
//� ������� ������������ ���������� ��� ������� ��������� � ��� ��������������.

string generateStr(int length) {
  string temp;
  temp += RAND('A', 'Z');
  for (size_t i = 0; i < length - 1; i++)
  {
    temp += RAND('a', 'z');
  }return temp;
}

class HomePet {
  string name;
  int age;
public:
  HomePet(bool isRandom = false) :name(), age() {
    if (isRandom) {
      name = generateStr(RAND(3,15));
      age = RAND(0, 20);
    }
  }
  void setName(const string& Name) {name = Name;}
  void setAge(const int& Age) {age = Age;}
  string getName()const { return name; }
  int getAge()const { return age; }
  friend ostream& operator<<(ostream& os, const HomePet& obj) {
    return os << obj.name << ":" << obj.age;
  }
};

class Dog : public HomePet {
  bool isThereDogHouse;
  string breed;
public:
  Dog(bool isRandom = false) :HomePet(isRandom), isThereDogHouse(), breed() {
    if (isRandom) {
      isThereDogHouse = rand() % 2;
      breed = generateStr(RAND(5, 10));
    }
  }
  bool getIsThereDogHouse()const { return isThereDogHouse; }
  string getBreed()const { return breed; }
  void setIsThereDogHouse(const bool& isDogHouse) {isThereDogHouse = isDogHouse;}
  void setBreed(const string& Breed) { breed = Breed; }
  friend ostream& operator<<(ostream& os, const Dog& obj) {
    return os << (HomePet&)obj << " | " << "Dog House(" << boolalpha << obj.isThereDogHouse << "), Breed: " << obj.breed << "\n";
  }
};

class Cat : public HomePet {
  int lifeCount;
  bool isReactionToCatnip;
public:
  Cat(bool isRandom = false) :HomePet(isRandom), lifeCount(), isReactionToCatnip() {
    if (isRandom) {
      lifeCount = RAND(1, 9);
      isReactionToCatnip = rand() % 2;
    }
  }
  bool getIsReactionToCatnip()const { return isReactionToCatnip; }
  int getLifeCount()const { return lifeCount; }
  void setIsReactionToCatnip(const bool& isReaction) { isReactionToCatnip = isReaction; }
  void setLifeCount(const int& LifeCount) { lifeCount = abs(LifeCount)%10; }
  friend ostream& operator<<(ostream& os, const Cat& obj) {
    return os << (HomePet&)obj << " | " << "Reaction To Catnip(" << boolalpha << obj.isReactionToCatnip << "), Life Count: " << obj.lifeCount << "\n";
  }
  Cat& operator--() {
    cout << "life count reduced\n";
    if (lifeCount) --lifeCount;
    return *this;
  }
  Cat operator--(int) {
    Cat temp(*this);
    if (lifeCount) --lifeCount;
    return temp;
  }
};

class Parrot : public HomePet {
  bool isAbleToSpeak;
  int wordCount;
public:
  Parrot(bool isRandom = false) :HomePet(isRandom), isAbleToSpeak(), wordCount() {
    if (isRandom) {
      isAbleToSpeak = rand() % 2;
      if (isAbleToSpeak) {
        wordCount = RAND(0, 100);
      }
    }
  }
  bool getIsAbleToSpeak()const { return isAbleToSpeak;}
  int getWordCount()const { return wordCount; }
  void setAbilityToSpeak(const bool& isAble) {
    if (isAble) isAbleToSpeak = isAble;
    else {
      isAbleToSpeak = isAble;
      wordCount = 0;
    }
  }
  void setWordCount(const int& count) {
    if (isAbleToSpeak) wordCount = count;
    else return;
  }
  friend ostream& operator<<(ostream& os, const Parrot&obj) {
    return os << (HomePet&)obj << " | " << "Is able to speak(" << boolalpha << obj.isAbleToSpeak << "), word count that it can speak: " << obj.wordCount << "\n";
  }
};

void problem1() {
  Dog dogee(true);
  cout << dogee;
  Cat cittie(true);
  cout << cittie--;
  cout << cittie;
  Parrot jack(true);
  cout << jack;
  jack.setAbilityToSpeak(false);
  cout << jack;
}