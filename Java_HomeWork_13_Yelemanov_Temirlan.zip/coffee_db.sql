use coffee;
-- drinks, deserts, emploees 
-- coffeBranch
-- positions
-- blacklist

drop database if exists coffee;
create database coffee;
use coffee;

create table drinks (
	id int primary key auto_increment,
    name varchar(50),
    price decimal(6,2),
    branch_id int 
);
create table deserts(
	id int primary key auto_increment,
    name varchar(50),
    price decimal(6,2),
    branch_id int
);
create table employees(
	id int primary key auto_increment,
    full_name varchar(100),
    branch_id int,
    position_id int,
    foreign key(branch_id) references branches(id),
    foreign key(position_id) references positions(id)
);
 create table branches(
	id int primary key auto_increment,
    name varchar(30),
    address varchar(40)
);
create table employee_list(
	id int primary key auto_increment,
    branch_id int,
    employee_id int,
    start_date datetime,
    end_date datetime
);
create table positions(
	id int primary key auto_increment,
    name varchar(20)
);
create table black_list(
	id int primary key auto_increment,
    employee_id int,
    foreign key(employee_id) references employees(id)
);
create table archive(
	id int primary key auto_increment,
	table_name varchar(20),
    deleted_content varchar(10000)
);
create table orders(
	id int primary key auto_increment,
    branch_id int,
	customer_info nvarchar(100),
    emploee_id int
);
create table order_details(
	id int primary key auto_increment,
    order_id int,
    drink_id int,
    drink_count int,
    desert_id int,
    desert_count int
);


create view branches_info as
select 
b.id as branch_id,
b.name as branch_name,
(select group_concat(name separator ', ') from drinks where branch_id = b.id) as drinks,
(select group_concat(name separator ', ') from deserts where branch_id = b.id) as deserts,
(select group_concat('['+e.fullname+': '+ p.name+']' separator ', ') from employees e join positions p on p.id = e.position_id) as employees
from branches b;


Delimiter //
create procedure popular_drink()
begin
	SELECT d.id, d.name
    from order_details od
    inner join drinks d on d.id = od.drink_id
    group by d.id, d.name
    order by count(*) desc
    limit 1 ;
end //
Delimiter ;

Delimiter //
create procedure popular_desert()
begin
	SELECT d.id, d.name
    from order_details od
    inner join deserts d on d.id = od.desert_id
    group by d.id, d.name
    order by count(*) desc
    limit 1 ;
end //
Delimiter ;

Delimiter //
create procedure top_3_popular_drinks()
begin
	SELECT d.id, d.name
    from order_details od
    inner join drinks d on d.id = od.drink_id
    group by d.id, d.name
    order by count(*) desc
    limit 3;
end //
Delimiter ;

Delimiter //
create procedure top_3_popular_deserts() 
begin
	SELECT d.id, d.name
    from order_details od
    inner join drinks d on d.id = od.drink_id
    group by d.id, d.name
    order by count(*) desc
    limit 1 ;
end //
Delimiter ;

delimiter //
create procedure nomad_emploee()
begin
	select e.id, e.full_name
    from employee_list el
    inner join employees e on e.id = el.employee_id
    group by e.id, e.full_name, el.branch_id
    having count(*) = (select count(*) from branches);
end //
delimiter ;

delimiter //
create procedure isInBlackList(employee_id_to_check int, out result boolean)
begin
	set result = exists(select id from blackList where employee_id = employee_id_to_check limit 1);
end //
delimiter ;

delimiter //
create trigger before_insert_employee_list
before insert on employee_list
for each row
begin
	set @isInBlackList = 0;
    call isInBlackList(new.emplyee_id, @isInBlackList);
	if  @isInBlackList = 1 then
		SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Employee is in black list! Could not be accepted!';
    end if;
end //
delimiter ;
