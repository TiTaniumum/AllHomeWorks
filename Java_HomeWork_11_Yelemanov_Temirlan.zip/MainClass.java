import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainClass {
    public static Random random = new Random();

    public static void main(String[] args) {
        //Demo1();
        Demo2();
        //продолжать не стал так как задания однотипные.
    }

    public static void Demo1() {
        List<Integer> list = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            list.add(random.nextInt(1000));
            if (random.nextInt(2) == 1)
                list.set(i, -list.get(i));
        }
        System.out.println(list);
        System.out.println("positive count = " + list.stream().filter(n -> n >= 0).toList().size());
        System.out.println("negative count = " + list.stream().filter(n -> n < 0).toList().size());
        System.out.println("2 digit num count = " + list.stream().filter(n -> Math.abs(n) >= 10 && Math.abs(n) < 100).toList().size());
        System.out.println("mirror numbers count = " + list.stream().filter(MainClass::isMirrored).toList().size());
    }

    public static void Demo2(){
        List<Product> products = List.of(
            new Product("Bread", Category.BREAD),
            new Product("Moyo", Category.MILK),
            new Product("Snickers", Category.CANDY),
            new Product("Cheetas", Category.OTHER),
            new Product("Domik v derevne", Category.MILK),
            new Product("Cheetas", Category.OTHER)
        );
        System.out.println(1+")");
        products.stream().forEach(System.out::println);
        System.out.println(2+")");
        System.out.println(products.stream().filter(product->product.getName().length()<5).toList());
        System.out.println(3+")");
        System.out.println(products.stream().filter(product->product.name.equals("Cheetas")).toList().size());
        System.out.println(4+")");
        System.out.println(products.stream().filter(product->product.name.toCharArray()[0]=='C').toList().size());
        System.out.println(5+")");
        System.out.println(products.stream().filter(product->product.category == Category.MILK).toList());
    }

    public static boolean isMirrored(int n) {
        String[] arr = ("" + Math.abs(n)).split("");
        for (int i = 0; i < arr.length / 2; i++) {
            if (!arr[i].equals(arr[arr.length - 1 - i]))
                return false;
        }
        return true;
    }
}

class Product {
    public String name;
    public Category category;
    public Product(String name, Category category) {
        this.name = name;
        this.category = category;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Category getCategory() {
        return category;
    }
    public void setCategory(Category category) {
        this.category = category;
    }
    @Override
    public String toString() {
        return "Product [name=" + name + ", category=" + category + "]";
    }
}

enum Category{
    MILK,
    BREAD,
    CANDY,
    OTHER
}