import React, { createContext, useState, useContext, ReactNode } from "react";
import { BankAccount } from "./interfaces";

export const mocks: BankAccount[] = [
  {
    phone: "87776665544",
    fullname: "Mock Mockovski",
    balance: 200000.0,
    password: "admin",
  },
  {
    phone: "87776664444",
    fullname: "Test Testovski",
    balance: 100000.0,
    password: "admin",
  },
];

type GlobalContext = {
  currentClient: BankAccount;
  clients: BankAccount[];
  isLoggedIn: boolean;
  qrCodeScan: string;
  Transaction: (phoneFrom: string, amount: number, phoneTo: string) => boolean;
  getClientByPhone: (phone: string)=>BankAccount | null;
  setIsLoggedIn: (value: boolean)=>void;
  setQrCodeScan: (value: string) =>void;
};

const Context = createContext<GlobalContext>({} as GlobalContext);

export function ContextProvider({ children }: { children: ReactNode }) {
  const [currentClient, setCurrentClient] = useState<BankAccount>(mocks[0]);
  const [clients, setClients] = useState<BankAccount[]>(mocks);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [qrCodeScan, setQrCodeScan] = useState("");

  function Transaction(phoneFrom: string, amount: number, phoneTo: string) {
    let clientFrom = clients.find((item) => 
      item.phone == phoneFrom
    );
    let clientTo = clients.find((item) => 
      item.phone == phoneTo
    );
    console.log(phoneFrom, phoneTo);
    console.log(clientFrom, clientTo);
    if (!clientFrom || !clientTo || clientFrom.balance < amount) return false;
    clientFrom.balance -= amount;
    clientTo.balance += amount;
    return true;
  }

  function getClientByPhone(phone:string){
    let client = clients.find((item) => 
      item.phone == phone
    );
    if(client) return client;
    return null;
  }

  return (
    <Context.Provider value={{ currentClient ,clients, isLoggedIn,qrCodeScan, Transaction,getClientByPhone, setIsLoggedIn, setQrCodeScan }}>
      {children}
    </Context.Provider>
  );
}

export function useGlobalContext() {
  const context = useContext(Context);
  if (context === undefined) {
    throw new Error("useFinances должен использовать FinanceProvider");
  }
  return context;
}
