import { useContext, useEffect, useState } from "react";
import { View, TextInput, Button, Alert,Text } from "react-native";
import { useGlobalContext } from "../ContextProvider";
import { useFocusEffect } from "@react-navigation/native";
import { BankAccount } from "../interfaces";

export default function Transactions({ navigation }: any) {
  const { currentClient, qrCodeScan, Transaction, getClientByPhone, setQrCodeScan } =
    useGlobalContext();
  const [phone, setPhone] = useState(qrCodeScan);
  const [amount, setAmount] = useState("");
  const [clientTo, setClientTo] = useState<BankAccount | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  function SendMoney() {
    if(!isAuthenticated){
      navigation.navigate('Auth', {setIsAuthenticated});
      return;
    }
    const numberAmount = parseFloat(amount);
    if (isNaN(numberAmount)) {
      Alert.alert("ERROR", "Incorrect amount input");
      return;
    }
    const isSuccess = Transaction(currentClient.phone, numberAmount, phone);
    if (isSuccess) {
      Alert.alert("Success", "Transaction has passed");
      handlePhoneInput("");
      setAmount("");
      setQrCodeScan("");
    } else {
      Alert.alert("Failed", "Transaction hasn't passed");
    }
  }
  function handlePhoneInput(value:string){
    setClientTo(getClientByPhone(value));
    setPhone(value);
  }
  async function toHome() {
    navigation.navigate("Home");
  }
  function scanQR() {
    navigation.navigate("Scan", { handlePhoneInput });
  }
  useEffect(()=>{
    handlePhoneInput(phone);
  })

  return (
    <View>
      <Text>Подсказка для разработчика: 87776664444</Text>
      <TextInput
        placeholder="type in any phone number"
        value={phone}
        onChangeText={handlePhoneInput}
      />
      <Button title="Scan QR" onPress={scanQR} />
      {clientTo && (
        <View>
          <Text>Name: {clientTo.fullname}</Text>
          <TextInput
            placeholder="type in amount of money you want to send"
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
          />
          <Button title="send mony" onPress={SendMoney} />
        </View>
      )}
    </View>
  );
}
