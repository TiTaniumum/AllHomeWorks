import { StyleSheet, Text, View, Button, Appearance } from "react-native";
import { BarCodeScanner } from "expo-barcode-scanner";
import { SafeAreaView } from "react-native-safe-area-context";
import { useEffect, useState } from "react";
import { useGlobalContext } from "../ContextProvider";

var colorScheme = Appearance.getColorScheme();

export default function Scan({navigation, route}: any) {
  const [hasPermission, setHasPermission] = useState(false);
  const [scanned, setScanned] = useState(false);
  const [qrCode, setQrCode] = useState(null);
  const {handlePhoneInput} = route.params;

  useEffect(() => {
    async function getPermission() {
      const { status } = await BarCodeScanner.getPermissionsAsync();
      setHasPermission(status === "granted");
    }
    getPermission();
  }, []);

  function handleBarCode({ data }: any) {
    setScanned(true);
    setQrCode(data);
    handlePhoneInput(data);
    navigation.goBack();
  }

  if (hasPermission) {
    return (
      <SafeAreaView style={styles.qrCodeContainer}>
        <Text style={styles.qrCodeText}>
          Необходимо разрешение к камере
        </Text>
        <Text style={styles.qrCodeText}>
          Разрешение: {hasPermission+''}
        </Text>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container}>
      <BarCodeScanner
        onBarCodeScanned={scanned ? undefined : handleBarCode}
        style={StyleSheet.absoluteFillObject}
      />
      {scanned && (
        <SafeAreaView style={styles.qrCodeContainer}>
          <Text style={styles.qrCodeText}>
            QR-Код: {qrCode}
            {/*i18n.t('code')*/}
          </Text>
          <Button
            title="Сканировать еще раз"
            onPress={() => {
              setScanned(false);
            }}
          />
        </SafeAreaView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colorScheme === "dark" ? "black" : "white",
  },
  qrCodeText: {
    fontSize: 16,
    color: colorScheme === "dark" ? "white" : "black",
  },
  qrCodeContainer: {
    position: "absolute",
    bottom: 20,
    left: 20,
    right: 20,
    padding: 10,
    borderRadius: 10,
    backgroundColor: colorScheme === "dark" ? "black" : "white",
  },
});
