import { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet } from "react-native";
import { useGlobalContext } from "../ContextProvider";

export default function Login({ navigation }: any) {
  const { currentClient, setIsLoggedIn } = useGlobalContext();

  const [phone, setPhone] = useState(currentClient.phone);
  const [password, setPassword] = useState(currentClient.password);

  function handleLogin() {
    if (phone === currentClient.phone && password == currentClient.password) {
      setIsLoggedIn(true);
      navigation.goBack();
    }
  }

  return (
    <View style={styles.container}>
      <Text>Login Page</Text>
      <Text>Phone number:</Text>
      <TextInput style={styles.input} value={phone} onChangeText={setPhone} />
      <Text>Password</Text>
      <TextInput style={styles.input} value={password} onChangeText={setPassword} />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  input:{
    padding: 5, 
    borderColor: 'black',
    borderWidth: 1,
    borderRadius: 10,
  }
});
