import * as React from "react";
import { useState, useEffect } from "react";
import { Text, View, Alert } from "react-native";
import * as LocalAuth from "expo-local-authentication";

export default function Auth({ navigation, route }: any) {
  const [authenticated, setAuthenticated] = useState(false);
  const {setIsAuthenticated} = route.params;
  async function hangleBiometricAuth() {
    const hasHardware = await LocalAuth.hasHardwareAsync();
    const biometricsSupported =
      await LocalAuth.supportedAuthenticationTypesAsync();
    if (!hasHardware || biometricsSupported.length === 0) {
      Alert.alert("Ошибка", "Ваше устройство не поддерживает биометрию");
      navigation.goBack();
      return;
    }
    const isEnrolled = await LocalAuth.isEnrolledAsync();
    if (!isEnrolled) {
      Alert.alert("Ошибка", "Биометрия не настроена");
      navigation.goBack();
      return;
    }
    const result = await LocalAuth.authenticateAsync({
      promptMessage: "Authenticate",
      // fallbackLabel: 'Use Passcode'
    });
    if (result.success) {
      setAuthenticated(true);
      setIsAuthenticated(true);
      Alert.alert("Успех", "Вы авторизовались");
      navigation.goBack();
    } else {
      Alert.alert("Внимание!","Попытка авторизации не успешна");
      navigation.goBack();
    }
  }
  useEffect(() => {
    hangleBiometricAuth();
  }, []);
  return (
    <View>
      {authenticated ? (
        <Text>Добро Пожаловать</Text>
      ) : (
        <Text>Ожидание авторизации...</Text>
      )}
    </View>
  );
}
