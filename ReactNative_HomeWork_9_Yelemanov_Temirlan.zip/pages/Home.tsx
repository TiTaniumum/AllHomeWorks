import { View, Button, Text, StyleSheet } from "react-native";
import * as Haptics from "expo-haptics";
import { BankAccount } from "../interfaces";
import { useGlobalContext } from "../ContextProvider";
import { useEffect, useState } from "react";
import { useFocusEffect } from "@react-navigation/native";

export default function Home({ navigation }: any) {
  const [balance,setBalance] = useState("");
  const { currentClient, isLoggedIn } = useGlobalContext();
//   async function handlePress() {
//     Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
//     navigation.navigate("Auth");
//   }

  useFocusEffect(()=>{
    setBalance(currentClient.balance+"");
    if(!isLoggedIn){
      navigation.navigate('Login');
    }
  });

  async function toTransactions() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    navigation.navigate("Transactions");
  }
  return (
    <View style={styles.container}>
      <Text>fullname: {currentClient.fullname}</Text>
      <Text>phone: {currentClient.phone}</Text>
      <Text>balance: {currentClient.balance}</Text>
      <Button title='Transactions' onPress={toTransactions}/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
