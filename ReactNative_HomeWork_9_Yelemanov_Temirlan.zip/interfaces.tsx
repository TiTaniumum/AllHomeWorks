export interface BankAccount {
  phone: string;
  fullname: string;
  balance: number;
  password: string;
}

export interface Clients {
  clients: BankAccount[];
}