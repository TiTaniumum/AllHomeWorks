import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button } from "react-native";

import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import Home from "./pages/Home";
import Auth from "./pages/Auth";
import { ContextProvider } from "./ContextProvider";
import Transactions from "./pages/Transactions";
import Login from "./pages/Login";
import Scan from "./pages/Scan";

const RootStack = createNativeStackNavigator();

export default function App() {
  return (
  <ContextProvider>
    <NavigationContainer>
      <RootStack.Navigator>
        <RootStack.Group>
          <RootStack.Screen
            name="Home"
            component={Home}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen
            name="Login"
            component={Login}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen
            name="Transactions"
            component={Transactions}
            options={({ navigation }) => ({})}
          />
        </RootStack.Group>
        <RootStack.Group screenOptions={{ presentation: "modal" }}>
          <RootStack.Screen
            name="Auth"
            component={Auth}
            options={({ navigation }) => ({})}
          />
          <RootStack.Screen 
            name="Scan"
            component={Scan}
            options={({navigation}) =>({})}/>
        </RootStack.Group>
      </RootStack.Navigator>
    </NavigationContainer>
  </ContextProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
