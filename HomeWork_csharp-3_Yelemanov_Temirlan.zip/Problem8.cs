﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp3
{
    public class Student
    {
        public readonly string FIO;
        public  string Group { get; protected set; }
        public  int Age { get;protected set; }
        public int[][] Marks { get; set; }
        public Student()
        {
            Marks = new int[3][];
            for (int i = 0; i < Marks.Length; i++)
            {
                Marks[i] = new int[10];
            }
        }
        public Student(string fio, string Group, int Age, int[][] Marks)
        {
            this.FIO = fio;
            this.Group = Group;
            this.Age = Age;
            this.Marks = Marks;
        }
        public static Student GetRandomStudent()
        {
            Random random = new Random();
            string fio = string.Empty;
            string group = string.Empty;
            fio += (char)random.Next('A', 'Z');
            group += (char)random.Next('A', 'Z');
            for (int i = 0; i < 10; i++)
            {
                fio += (char)random.Next('a', 'z');
                group += (char)random.Next('a', 'z');
            }
            int age = random.Next(5,17);
            int[][] Marks = new int[3][];
            for (int i = 0; i < Marks.Length; i++)
            {
                Marks[i] = new int[10];
                for (int j = 0; j < Marks[i].Length; j++)
                {
                    Marks[i][j] = random.Next(1, 12);
                }
            }
            return new Student(fio,group, age,Marks);
        }
        public int AverageMark(int index)
        {
            if (index < 0 || index > 3) return -1;
            int sum = 0;
            for (int i = 0; i < Marks[index].Length; i++)
            {
                sum+= Marks[index][i];
            }
            return sum/Marks[index].Length;
        }

        public override string ToString()
        {
            return $"FIO: {FIO}. Group: {Group}. Age: {Age}. Marks: {AverageMark(0)}, {AverageMark(1)}, {AverageMark(2)}";
        }
    }
}
