﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Earth
{
    public class BaseCountry
    {
        public int PeopleCount { get; protected set; }

        public static bool operator >(BaseCountry left, BaseCountry right)
        {
            return left.PeopleCount > right.PeopleCount;
        }
        public static bool operator <(BaseCountry left, BaseCountry right)
        {
            return left.PeopleCount < right.PeopleCount;
        }
    }
}
namespace Kazakhstan
{
    public class Astana: Earth.BaseCountry{public Astana() { PeopleCount = 1002000;}}
}
namespace England
{
    public class London : Earth.BaseCountry{public London() {PeopleCount = 8982000;}}
}
namespace America
{
    public class Washington: Earth.BaseCountry { public Washington() { PeopleCount = 712816; } }
}