﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp3
{
    public class Base7Wonders
    {
        public string Name { get; protected set; }
        public Base7Wonders() {
            Name= string.Empty;
        }
        public Base7Wonders(string name)
        {
            Name= name;
        }
    }
    public class HeopsPiramid : Base7Wonders
    {
        public HeopsPiramid() : base("Heops Piramid") { }
    }
    public class SemiramidGardens : Base7Wonders {
        public SemiramidGardens() : base("Semiramid Gardens") { }
    }
    public class ZewsStatue : Base7Wonders
    {
        public ZewsStatue():base("Zews Statue") { }
    }
    public class ArtemidsTemple : Base7Wonders
    {
        public ArtemidsTemple() : base("Artemids Temple") { }
    }
    public class Galikarnas: Base7Wonders
    {
        public Galikarnas() : base("Galikarnas") { }
    }
    public class ColossRodoss: Base7Wonders
    {
        public ColossRodoss():base("Coloss Rodoss") { }
    }
    public class AlexandrsLighthouse : Base7Wonders
    {
        public AlexandrsLighthouse() : base("Alexandrs Lighthouse") { }
    }
}
