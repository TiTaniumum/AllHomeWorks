﻿using System;
using System.Security.Cryptography.X509Certificates;
using America;
using csharp3;
using Earth;
using England;
using Kazakhstan;

namespace HomeWork3
{
    public class MainClass
    {
        public static void ProblemReview1_7()
        {
            Client client = new Client(1, "Yelemanov T.T.", "MilkyWay.SunSystem.Earth.Asia.Kazakhstan", "+77777777777", 2, 5000, ClientType.Vip);
            List<RequestItem> items = new List<RequestItem>();
            Article product1 = new Article(1, "GamingPC", 400000, ArticleType.Road);
            Article product2 = new Article(2, "GamingMouse", 30000, ArticleType.Road);
            items.Add(new RequestItem(product1, 1));
            items.Add(new RequestItem(product2, 1));
            Request request = new Request(1, client, "1.12.2017", items, PayType.OnlineTransfer);
            Console.WriteLine(request.ToString());
        }

        public static void ProblemReview8()
        {
            Student student = Student.GetRandomStudent();
            Console.WriteLine(student);
        }
        public static void ProblemReview9()
        {
            Base7Wonders wonder = new ColossRodoss();
            Console.WriteLine(wonder.Name);
        }

        public static void ProblemReview10()
        {
            List<BaseCountry> CountryList = new List<BaseCountry>();
            CountryList.Add(new Astana());
            CountryList.Add(new London());
            CountryList.Add(new Washington());
            foreach (BaseCountry country in CountryList)
            {
               Console.WriteLine("Country population: " + country+"(" +country.PeopleCount +")");
            }
            for (int i = 0, j = CountryList.Count-1; i < CountryList.Count; j =  i++)
            {
                Console.Write(CountryList[i] + " > " + CountryList[j] + " = ");
                Console.WriteLine(CountryList[i] > CountryList[j]);
            }
        }
        public static void Main(string[]Args) {
            ProblemReview1_7();
            Console.WriteLine();
            ProblemReview8();
            Console.WriteLine();
            ProblemReview9();
            Console.WriteLine();
            ProblemReview10();
        }
    }
}