﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace csharp3
{
    public struct Article
    {
        public int id;
        public string title;
        public int cost;
        public ArticleType type;

        public Article(int id, string title, int cost, ArticleType articleType)
        {
            this.id = id;
            this.title = title;
            this.cost = cost;
            this.type = articleType;
        }
    }
    public struct Client
    {
        public int id;
        public string FIO;
        public string adress;
        public string telephoneNumber;
        public int ordersCount;
        public int sumTotal;
        public ClientType type;

        public Client(int id, string FIO, string adress, string telephoneNumber, int ordersCount,int sumTotal, ClientType type)
        {
            this.id = id;
            this.FIO = FIO;
            this.adress = adress;
            this.telephoneNumber = telephoneNumber;
            this.ordersCount = ordersCount;
            this.sumTotal = sumTotal;
            this.type = type;
        }
    }
    public struct RequestItem
    {
        public Article product;
        public int productCnt;
        public RequestItem(Article product,int productCnt)
        {
            this.product = product;
            this.productCnt = productCnt;
        }
    }
    public struct Request
    {
        public int id;
        public Client client;
        public string dateTime;
        public List<RequestItem> requestItemList;
        public int OrderSum
        {
            get
            {
                int sum = 0;
                foreach (var item in requestItemList) {
                    sum = item.product.cost * item.productCnt;
                }
                return sum;
            }
        }
        public PayType payType;

        public Request(int id, Client client , string dateTime,List<RequestItem> requestItemList, PayType payType)
        {
            this.id = id;
            this.client = client;
            this.dateTime = dateTime;
            this.requestItemList = requestItemList;
            this.payType = payType;
        }

        public override string ToString()
        {
            return $"id:{id}. client = ({client.id},{client.ordersCount},{client.adress},{client.FIO},{client.type}).\n " +
                $"dateTime:{dateTime}. Request items: {requestItemList}. PayType: {payType}";
        }
    }
    public enum ArticleType
    {
        Sea, 
        Road,
        Air,
        RailRoad,
    }
    public enum ClientType
    {
        Common, 
        Vip,
        Goverment,
        TOO,
        OOO,
        IndividualEnterpreneur,
    }
    public enum PayType
    {
        Cash,
        CreditCard,
        QR,
        OnlineTransfer,
        Check,
    }
}
