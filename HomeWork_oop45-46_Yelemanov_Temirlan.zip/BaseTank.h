﻿#pragma once
#include <iostream>
#include <string>
#include "Image.h"
#include "Pole.h"
#include "BaseBullet.h"
using namespace std;

enum GunType {
  light,medium,heavy
};

// класс базового танчика
class BaseTank {
private:
protected:
  // x,y, hight, width, direct, image[4][3][3]
  // xOld, yOld - старые координаты танка
  Image  Img;       // изображение танчика
  int    Life;      // жизни в %
  double Speed;     // скорость [0 .. 1.0]
  GunType gun;   // тип оружия
  bool   IsShoot;   // Если танчик решил выстрелить
  int    RandStep;  // для ботов - кол-во шагов по прямой
public:
  BaseTank();
  BaseTank(const Image& Img);
  BaseTank(const char img[MAX_DIRECT][TANK_HEIGHT][TANK_WIDTH + 1]);
  //
  virtual void SetImg(const Image& Img);
  virtual void SetImg(const char
    img[MAX_DIRECT][TANK_HEIGHT][TANK_WIDTH + 1]);
  //
  virtual bool IsAlive() const { return Life > 0; }
  virtual void Move(Pole& pole);  // общий метод перемещения
  virtual bool IsMove(Pole& pole);  // может ли объект переместиться
  virtual void OneStep(Pole& pole); // один шаг объекта
  virtual void Draw(Pole& pole) { // прорисовка на поле
    pole.DrawImg(Img);
  }
  virtual BaseBullet* Shoot(Pole& pole) {
    if (!IsShoot) return nullptr;
    Direction bulletDirction = Img.GetDir();
    Coord bulletPos = Img.GetPos();
    switch (bulletDirction)
    {
    case Up:bulletPos.x += 1, bulletPos.y -= 1;
      break;
    case Right:bulletPos.x += 3, bulletPos.y += 1;
      break;
    case Down:bulletPos.x += 1, bulletPos.y += 3;
      break;
    case Left:bulletPos.x -= 1, bulletPos.y += 1;
    }

    BaseBullet* temp;
    switch (gun)
    {
    case light: temp = new LightBullet(bulletPos, bulletDirction);
      break;
    case medium: temp = new MediumBullet(bulletPos, bulletDirction);
      break;
    case heavy: temp = new HeavyBullet(bulletPos, bulletDirction);
      break;
    default:
      temp = new LightBullet(bulletPos, bulletDirction);
      break;
    }
    IsShoot = false;
    return temp;
  }// выстрел

  bool isIntersect(Coord bulletCoord){
    if (((bulletCoord.x >= Img.GetPos().x) && (bulletCoord.x < Img.GetPos().x + Img.GetSize().cx)) && ((bulletCoord.y >= Img.GetPos().y) && (bulletCoord.y < Img.GetPos().y + Img.GetSize().cx))) return true;
    return false;
  }

  void TakeDamage(int damage) {Life -= damage;}

  GunType GetGunType()const { return gun; }

  // чисто виртуальный деструктор
  virtual ~BaseTank() = 0;
};
// Обязательная реализация деструктора!
inline BaseTank::~BaseTank() {}

class TankLight : virtual public BaseTank
{
public:
  TankLight():BaseTank(){
    Init();
  }
  void Init() {
    Img.SetPos(35, 35);
    Life = 1;
    gun = light;
    Speed = 3;
  }
};

class TankMedium : virtual public BaseTank
{
public:
  TankMedium() :BaseTank() {
    Init();
  }
  void Init() {
    Img.SetPos(40, 1);
    Life = 2;
    gun = medium;
    Speed = 2;
  }
};

class TankHeavy : virtual public BaseTank
{
public:
  TankHeavy() :BaseTank() {
    Init();
  }
  void Init() {
    Img.SetPos(1, 40);
    Life = 3;
    gun = heavy;
    Speed = 1;
  }
};

//char PlayerTankImage[MAX_DIRECT][TANK_HEIGHT][TANK_WIDTH + 1] =
//{
//  { // Direct = 0 - up
//    " | ", //+'\0'
//    "###",
//    "#O#",
//  },
//  { // Direct = 1 - right
//    "## ",
//    "O#-",
//    "## ",
//  },
//  { // Direct = 2 - down
//    "#O#",
//    "###",
//    " | ",
//  },
//  { // Direct = 3 - left
//    " ##", //+ '\0'
//    "-#O",
//    " ##",
//  },
//};

//Image PlayerImage(PlayerTankImage);

class PlayerTank : virtual public BaseTank {
public:
  PlayerTank() : BaseTank() {
    Init();
  }
  void Init() {
    SetPos(1, 1);
    Life = 5;
    gun = light;
    Speed = 2;
  }
  void Move(Pole&pole) {
    bool isMove = true;
    switch (_getch())
    {
    case _KEY::DOWN: Img.SetDir(Down);  break;
    case _KEY::UP: Img.SetDir(Up);      break;
    case _KEY::LEFT: Img.SetDir(Left);  break;
    case _KEY::RIGHT: Img.SetDir(Right);break;
    case _KEY::SPACE: IsShoot = true; isMove = false; break;
    default:
      isMove = false;
      break;
    }
    if (isMove) {
      OneStep(pole);
    }
    
  }
};