#pragma once
#include "Win10.h"
#include "BaseTank.h"


class BaseBullet
{
protected:
  Coord pos;
  Direction dir;
  int damage;
  bool isAlive;
public:
  BaseBullet():damage(), isAlive(), dir() {}
  BaseBullet(Coord pos, Direction dir) :pos(pos), dir(dir), damage(), isAlive(true){}
  
  int virtual GetDamage()const {
    return damage;
  }

  void virtual Draw(Pole& pole) {
    if ((pos.x < 0) || (pos.y < 0) || (pos.x >= pole.GetSize().cx) || (pos.y >= pole.GetSize().cy)) {
      isAlive = false;
      return;
    }
    pole[pos.y][pos.x] = 'o';
  }
  bool virtual Move(Pole&pole) {
    if((pos.y>=0) && (pos.x >=0) && (pos.x <pole.GetSize().cx) && (pos.y <pole.GetSize().cy)) 
      pole[pos.y][pos.x] = ' ';
    switch (dir)
    {
    case Up: pos.y -= 1;
      break;
    case Right:pos.x += 1;
      break;
    case Down:pos.y += 1;
      break;
    case Left:pos.x -= 1;
      break;
    }
    if ((pos.x <0) || (pos.y <0) || (pos.x>= pole.GetSize().cx) || (pos.y >= pole.GetSize().cy)) {
      isAlive = false;
      return false;
    }
    if (pole[pos.y][pos.x] != ' ') {
      isAlive = false;
      return false;
    }
    return true;
  }
  bool virtual IsAlive()const { return isAlive; }
  Coord getPos()const { return pos; }
  virtual ~BaseBullet() = 0;
};
inline BaseBullet::~BaseBullet() {}

class LightBullet : public virtual BaseBullet {
public:
  LightBullet(Coord pos, Direction dir):BaseBullet(pos,dir){
    damage = 1;
  }
  ~LightBullet() {}
};

class MediumBullet :public virtual BaseBullet {
public:
  MediumBullet(Coord pos, Direction dir) :BaseBullet(pos, dir) {
    damage = 2;
  }
};

class HeavyBullet : public virtual BaseBullet {
public:
  HeavyBullet(Coord pos, Direction dir) :BaseBullet(pos, dir) {
    damage = 3;
  }
};