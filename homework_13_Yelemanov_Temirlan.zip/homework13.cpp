﻿#include <iostream>
#include <iomanip>
#include <algorithm>
#include <stdlib.h>
#include <random>
#include "problem.h"
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
using namespace std;

int main()
{
  setlocale(LC_CTYPE, "Russian");
  srand(time(NULL));
  //problem();    // усложненная задача
  //problem1();   // усложненный метод выборки сортировки. Советаю посмотреть.
  //problem1_1(); // проверка моего метода
  //problem1_2(); // бабл сорт
  //problem1_3(); // обчный метод выборки 
  //problem2();   // операция сложения 50-и знаычных чисел
  //problem2_1(); // операция вычитания 50-и значных чисел
  //problem3();   // та самая задача которую вы просили показать!!!!!!!
  cout << "\nend! . ..  ..  . . . . . . . .\n";
}
