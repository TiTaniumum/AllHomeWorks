package Lesson4;

import java.util.Arrays;

public class MainClass {
    public static void main(String[] args){
        PrintChar2D(getSpiral(6));
    }
    public static void PrintChar2D(char[][] arr){
        for(int i = 0; i<arr.length; i++){
            String str = "";
            for(int j = 0; j < arr[i].length; j++){
                str+=arr[i][j];
                str+=" ";
            }
            Print(str);
        }
    }
    public static char[][] getSpiral(int size){
        int lengthy, lengthx;
        lengthy = size*3 + 1;
        lengthx = size*3 + 1;
        char[][] result = new char[lengthy][lengthx];
        int pointx = lengthx/2;
        int pointy = lengthy/2;
        for(char[] arr: result){
            Arrays.fill(arr,' ');
        }

        
        int cnt = 2;
        int length = 2;
        int dir = 0;
        result[pointy][pointx] = 'x';
        boolean isFinish = false;
        while(!isFinish){
            Print("cycle");
            if(cnt == 0){
                cnt = 2;
                length+=2;
            }
            for(int i = 0; i< length; i++){
                switch (dir) {
                    case 0: pointx++; break;
                    case 1: pointy++; break;  
                    case 2: pointx--; break;
                    case 3: pointy--; break;
                    default: isFinish = true; break;
                }
                if(isOutOfBounds(result,pointx,pointy)){
                    Print("out of bounds");
                    isFinish = true;
                    break;
                }
                result[pointy][pointx] = 'x';
            }
            if(++dir == 4) dir = 0;
            cnt--;
        }

        return result;
    }

    public static boolean isOutOfBounds(char[][] arr,int x, int y){
        if(x <0 || y<0) return true;
        if(y>=arr.length || x>=arr[0].length) return true;
        return false;
    }
    public static void Print(String str){
        System.out.println(str);
    }
    
}