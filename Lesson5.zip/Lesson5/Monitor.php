<?php 
    class Monitor extends Product{
        public $diagonal;
        public $frequency;
        public $ports;
        public function __construct($diagonal, $frequency, $ports, $name, $price, $description,$brand){
            $this->diagonal = $diagonal;
            $this->frequency = $frequency;
            $this->ports = $ports;
            parent::__construct($name, $price, $description,$brand);
        }
        public function getProduct(){
            return print_r($this);
        }
    }
?>