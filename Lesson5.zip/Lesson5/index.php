<?php 
    require_once("Product.php");
    require_once("Phone.php");
    require_once("Monitor.php");
    require_once("Cart.php");
    require_once("Session.php");
    $products = [];
    $monitor1 = new Monitor(19, 4000, 2, "Minic", 150, "Not Good Monitor", "HP");
    $monitor2 = new Monitor(4, 200,1,"Legion", 140, "Good Monitor","Lenovo");  
    $phone1 = new Phone("snap draogn 5",4,2,64, "Windows", "nokia", 400, "some phone", "nokia");
    $phone2 = new Phone("snap dragon 4",3,4,32, "Ios", "Iphone 5", 200, "dark black", "Iphone");
    $phone3 = new Phone("snap dragon 10", 6, 4, 168, "Bios", "Nedophone", 123, "kill it", "Ohio");
    $products[] = $monitor1;
    $products[] = $monitor2;
    $products[] = $phone1;
    $products[] = $phone2;
    $products[] = $phone3;
    foreach($products as $product){
        echo $product->getProduct()."<br>";
    }
    $session = new Session();
    if(isset($_POST["time"])){
        $session->DateTime = new DateTime($_POST["time"]);
    }
    $cart = [];
    $product = null;
    if(isset($_POST["data"])){
        $cart = json_decode($_POST["data"]);
    }
    else{
        $cart = [];
    }
    if(isset($_POST["product"])){
        $product = json_decode($_POST["product"]);
    }
    if($product!= null){
        $cart[] = $product;
        echo $_POST["product"];
    }

    $session->productList = $cart;

    if($session->isSessionLive(new DateTime("now"))){}
    else{
        $cart = [];
        $session->productList = $cart;
        $session->DateTime = new DateTime("now");
    }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <hr>
    <form action="index.php" method="post">
        <div>
            Iphone 5
            
            <input type="hidden" value="<?=htmlspecialchars(json_encode($phone1));?>" name="product">
            <input type="hidden" value="<?=htmlspecialchars(json_encode($cart));?>" name="data">
            <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
            <button type="submit">Add</button>
        </div>
    </form>
    <form action="index.php" method="post">
        <div>
            Iphone 8
            <input type="hidden" value="<?=htmlspecialchars(json_encode($phone2));?>" name="product">
            <input type="hidden" value="<?=htmlspecialchars(json_encode($cart));?>" name="data">
            <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
            <button type="submit">Add</button>
        </div>
    </form>
    <form action="index.php" method="post">
        <div>
            Samsung s8
            <input type="hidden" value="<?=htmlspecialchars(json_encode($phone3));?>" name="product">
            <input type="hidden" value="<?=htmlspecialchars(json_encode($cart));?>" name="data">
            <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
            <button type="submit">Add</button>
        </div>
    </form>
    <form action="index.php" method="post">
        <div>
            HP Monitor
            <input type="hidden" value="<?=htmlspecialchars(json_encode($monitor1));?>" name="product">
            <input type="hidden" value="<?=htmlspecialchars(json_encode($cart));?>" name="data">
            <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
            <button type="submit">Add</button>
        </div>
    </form>
    <form action="index.php" method="post">
        <div>
            Lenovo Legion
            <input type="hidden" value="<?=htmlspecialchars(json_encode($monitor2));?>" name="product">
            <input type="hidden" value="<?=htmlspecialchars(json_encode($cart));?>" name="data">
            <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
            <button type="submit">Add</button>
        </div>
    </form>
    <form action="index.php" method="post">
        <input type="hidden" value="[]" name="data">
        <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
        <button type="submit">clear cart</button>
    </form>
    <form action="cartPage.php" method="post">
        <input type="hidden" value="<?=htmlspecialchars(json_encode($cart));?>" name="data">
        <input type="hidden" value="<?=$session->DateTime->format("Y-m-d H:i:s");?>" name="time">
        <button type="submit">Go to Cart</button>
    </form>
    <hr>
    <?=json_encode($product)?>
    <hr>
    <?=json_encode($cart);?>
    <hr>
    <?="Session Time: ".$session->DateTime->format("Y-m-d H:i:s")?>
</body>
</html>