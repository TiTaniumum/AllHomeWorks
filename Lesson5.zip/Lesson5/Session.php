<?php 
class Session extends Cart{
    public $sessionId;
    public $productList; // Product
    public DateTime $DateTime;
    public function __construct(){
        $this->sessionId = random_int(0,1000);
        $this->productList = [];
        $this->DateTime = new DateTime("now");
    }
    public function GetCart(){
        return $this->productList;
    }
    public function AddToCart(Product $product){
        $this->productList[] = $product;
    }
    public function isSessionLive(DateTime $dateTime){
        if (date_diff($this->DateTime, $dateTime)->format('%i') > 5)return false;
        return true;
    }
}
?>