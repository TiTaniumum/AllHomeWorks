<?php 
    abstract class Animal{
        public string $name;
        public int $age;
        public function __construct(string $name, int $age) {
            $this->name = $name;
            $this->age = $age;
        }
        public function getAge(){
            return $this->age;
        }
        public function getName(){
            return $this->name;
        }
        public function setName(string $name){
            $this->name = $name;
        }
        public function setAge(int $age){    
            $this->age = $age;
        }
    }

    class Cat extends Animal{
        public string $breed;
        public function __construct(string $name, int $age, string $breed) {  
            $this->breed = $breed;
            parent::__construct($name, $age);
        }
        public function getAge(){
            return $this->age * 7;
        }
    }

    class Dog extends Animal{
        public function getAge(){
            return $this->age *11;
        }
    }
    
    interface iFigure{
        public function Print();
    }
    interface iGeometry{
        public function Exists();
    }
    class Circle implements iFigure, iGeometry{
        public function Print(){

        }
        public function Exists(){

        }
    }
    class Rectangle implements iFigure, iGeometry{
        public function Print(){

        }
        public function Exists(){

        }
    }
?>