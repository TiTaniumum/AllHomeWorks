<?php 
class Phone extends Product{
    public $cpu;
    public $memory;
    public $countSim;
    public $hdd;
    public $os;
    public function __construct($cpu, $memory, $countSim, $hdd, $os, $name, $price, $description, $brand){
        $this->cpu = $cpu;
        $this->memory = $memory;
        $this->countSim = $countSim;
        $this->hdd = $hdd;
        $this->os = $os;
        parent::__construct($name, $price, $description, $brand);
    }
    public function getProduct()
    {
        return print_r($this);
    }
}
?>