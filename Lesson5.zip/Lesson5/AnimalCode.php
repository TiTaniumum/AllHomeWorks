<?php
include("Animal.php");
$animals = [];

$animals[] = new Cat("Кристи", 2, "сфинкс");
$animals[] = new Cat("Бонни", 4, "Сиамская");
$animals[] = new Dog("Адам", 6);
foreach ($animals as $animal) {
    if($animal instanceof Animal){
        echo $animal->getAge() . "<br>";
    }
}
$figures = [];
$figures[] = new Circle;
$figures[] = new Rectangle;

foreach($figures as $figure){
    if($figure instanceof iFigure){
        echo "iFigure";
    }
}
?>