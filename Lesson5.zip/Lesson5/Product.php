<?php
class Product{
    public $name;
    public $price;
    public $description;
    public $brand;
    public function __construct($name, $price, $description, $brand){
        $this->name = $name;
        $this->price = $price;
        $this->description = $description;
        $this->brand = $brand;
    }
    protected function getProduct(){
        return $this;
    }
}
?>