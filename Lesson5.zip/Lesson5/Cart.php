<?php 
    abstract class Cart{
        abstract function GetCart();
        abstract function AddToCart(Product $product);
    }
?>