﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

//Домашнее задание
//Тема: Semaphore


//Задание 1

//Создайте приложение, имитирующее работу стола казино в течение дня.
//За столом одновременно могут сидеть пять человек (пять потоков).
//Каждый из них имеет фиксированную сумму денег.
//Каждый игрок может поставить определенную сумму на число (сумма и число выбираются случайно).
//Если шарик рулетки попал на число игрока его сумма удваивается, если ставка не сыграла игрок теряет всю поставленную сумму.
//Если у игрока закончились деньги, он освобождает стол и на его место садится новый игрок (новый поток).
//Общее количество потенциальных игроков за день выбирается случайно, но должно находиться в диапазоне от 20 до 100.
//День заканчивается, когда все потенциальные игроки побывают за столом и сыграют хотя бы один раунд.

//Итогом дня является файл отчета по всем игрока следующего формата:
//Игрок1[начальная сумма][конечная сумма]
//Игрок2[начальная сумма][конечная сумма]
//Игрок3[начальная сумма][конечная сумма]

namespace Sys6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ThreadPool.SetMaxThreads(maxThreadCnt, maxThreadCnt);
            ThreadPool.SetMinThreads(maxThreadCnt, maxThreadCnt);
            table1 = new Table(textBox1, label1);
            table2 = new Table(textBox2, label2);
            table3 = new Table(textBox3, label3);
            table4 = new Table(textBox4, label4);
            table5 = new Table(textBox5, label5);
        }
        static private int maxThreadCnt = 20;
        static private int minThreadCnt = 5;
        public Semaphore semaphore = new Semaphore(minThreadCnt, minThreadCnt);
        public string playersInfo = string.Empty;
        private Table table1;
        private Table table2;
        private Table table3;
        private Table table4;
        private Table table5;
        public EventWaitHandle rollDice = new ManualResetEvent(false);
        public int DiceResult = 0;
        private long EarnedMoney = 0;
        object tablesLocker = new object();
        private void button1_Click(object sender, EventArgs e)
        {
            EarnedMoney = 0;
            playersInfo = string.Empty;
            button1.Enabled = false;
            for (int i = 0; i < maxThreadCnt; i++)
            {
                ThreadPool.QueueUserWorkItem(ThreadProc);
            }
            Thread diceRoller = new Thread(DiceRoller);
            diceRoller.IsBackground = true;
            diceRoller.Start();
        }
        //метод для потока где делается прокрутка числа
        public void DiceRoller(object parameter)
        {
            while (!AreAllTablesFree())
            {
                DiceResult = Player.random.Next(0, 10);
                labelDiceResult.Invoke((Action)delegate { labelDiceResult.Text = DiceResult.ToString(); });
                rollDice.Set();
                Thread.Sleep((int)numericUpDown1.Value*1000);
            }
            button1.Invoke((Action)delegate { button1.Enabled = true; });
            playersInfo+="Casino earned money: " + EarnedMoney;
            WriteInfoToFile();
            Process.Start("notepad.exe", "playersInfo.txt");
            labelDiceResult.Invoke((Action)delegate { labelDiceResult.Text = "Игра Закончена"; });
        }
        //метод игроков
        public void ThreadProc(object parameter)
        {
            semaphore.WaitOne();
            Table table;
            lock (tablesLocker)
            {
                table = GetFreeTable();
            }
            Player player = new Player(table, Thread.CurrentThread);
            while (player.СделатьСтавку())
            {
                rollDice.WaitOne();
                EarningLoosingMoney(player.bid, player.isWin(DiceResult));
                rollDice.Reset();
            }
            lock (playersInfo)
            {
                playersInfo += player.QuitGame();
            }
            semaphore.Release();
        }
        //зароботок казино
        public void EarningLoosingMoney(int playerbid, bool isWin)
        {
            if (isWin)
            {
                Interlocked.Add(ref EarnedMoney, -playerbid*3);
                return;
            }
            Interlocked.Add(ref EarnedMoney, playerbid);
        }
        public Table GetFreeTable()
        {
            if (table1.isFree) return table1.BookTable();
            if (table2.isFree) return table2.BookTable();
            if (table3.isFree) return table3.BookTable();
            if (table4.isFree) return table4.BookTable();
            if (table5.isFree) return table5.BookTable();
            return null;
        }
        public bool AreAllTablesFree()
        {
            if (table1.isFree && table2.isFree && table3.isFree && table4.isFree && table5.isFree) return true;
            return false;
        }
        public void WriteInfoToFile()
        {
            File.WriteAllText("playersInfo.txt", playersInfo);
        }
    }
    //класс столика
    public class Table
    {
        public TextBox tb;
        public Label l;
        public bool isFree;
        public Table(TextBox tb, Label l)
        {
            this.tb = tb;
            this.l = l;
            isFree = true;
        }
        public Table BookTable()
        {
            isFree = false;
            return this;
        }
    }
    public class Player
    {
        public static Random random;
        private int budget;
        //ставка
        public int bid { get; set; }
        private int goal;
        //предел до которого игрок будет играть
        private int lowerBoundery;
        private Table table;
        private string playerId;
        //ставка на число
        private int diceResult = -1;
        private int bidCount = 0;
        public bool isContinue { get { return budget>lowerBoundery && budget<goal; } }
        static Player()
        {
            random = new Random();
        }
        public Player(Table table, Thread th)
        {
            budget = random.Next(10000, 100000);
            bid = 0;
            goal = random.Next(budget+1000, budget*5);
            lowerBoundery = random.Next(0, 4)==0 ? random.Next(-10000, budget/2) : 0;
            this.table=table;
            playerId = th.ManagedThreadId.ToString();
            //table.l.Invoke((Action)delegate { table.l.Text = "Player: " + playerId; });
            UpdateInfo();
        }
        public bool СделатьСтавку()
        {
            if (isContinue)
            {
                bid = random.Next(1000, 5000+random.Next(0,Math.Abs(budget)));
                diceResult = random.Next(0, 10);
                bidCount++;
            }
            return isContinue;
        }
        public void UpdateInfo()
        {
            table.l.Invoke((Action)delegate { table.l.Text = "Player: " + playerId; });
            table.tb.Invoke((Action)delegate
            {
                table.tb.Text = $"Ставка на: {diceResult}\r\nДеньги игрока: {budget}\r\nСтавка: {bid}\r\nЦель: {goal}\r\nПредел: {lowerBoundery}";
            });
        }
        public bool isWin(int result)
        {
            UpdateInfo();
            if (result == diceResult) return Win();
            return Loose();
        }
        private bool Loose()
        {
            budget -= bid;
            //bid = 0;
            table.tb.Invoke((Action)delegate { table.tb.BackColor = Color.Red; });
            return false;
        }
        private bool Win()
        {
            budget += bid*3;
            //bid = 0;
            table.tb.Invoke((Action)delegate { table.tb.BackColor = Color.Green; });
            return true;
        }
        public string QuitGame()
        {
            table.l.Invoke((Action)delegate { table.l.Text ="Free Table"; });
            table.tb.Invoke((Action)delegate { table.tb.BackColor = Color.White; table.tb.Text = string.Empty; });
            table.isFree = true;
            return $"Номер игрока: {playerId,10}; Деньги игрока: {budget,10}; Колличество ставок: {bidCount,10}; Цель: {goal,10}; Предел: {lowerBoundery,10}; Итог: {(budget>=goal?"Выйграл":"Проиграл")}\r\n";
        }
    }
}
