<?php
//echo "<code><pre>";
require_once("ProductController.php");
$categories = ProductController::GetAllCategories();
$products = [];
if (isset($_POST["categoryClicked"]))
    $products = ProductController::GetProductsByCategoryName($_POST["categoryClicked"]);
ProductController::LoadProduct();
ProductController::LoadCategory();
//echo "</pre></code>";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <form action="index.php" method=post>
        <div class=dataManipulation>
            <div class=addData>
                <input type="text" placeholder="product name" name="productName">
                <input type="text" placeholder="product price" name="productPrice">
                <select name="categoryName" id="categoryName">
                    <?php foreach($categories as $category):?>
                        <option value="<?=$category->id?>"><?=$category->name?></option>
                    <?php endforeach;?>
                </select>
                <button type=submit name=buttonClick value=addProduct>Add Product</button>
            </div>
            <div class=addData>
                <input type="text" placeholder="Category name" name="newCategoryName">
                <button type=submit name=buttonClick value=addCategory>Add Category</button>
            </div>
        </div>
    </form>
    <hr>
    <form action="index.php" method=post>
        <ul>
            <?php foreach ($categories as $category): ?>
                <li>
                    <button
                        class="CategoryButton <?php if (isset($_POST["categoryClicked"]) && $_POST["categoryClicked"] == $category->name): ?>blue<?php endif; ?>"
                        type=submit name=categoryClicked value=<?= $category->name ?>>
                        <?= $category->name ?>
                    </button>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php if (isset($_POST["categoryClicked"])): ?>
            <ol>
                <?php foreach ($products as $product): ?>
                    <li>
                        <?= $product->ToString(); ?>
                    </li>
                <?php endforeach; ?>
                </ol>
        <?php endif; ?>
    </form>
</body>

</html>