<?php 
class Product{
    public int $id;
    public string $name;
    public int $price;
    public int $id_category;
    public function __construct($id, $name, $price, $id_category){
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->id_category = $id_category;
    }
    public function ToString(){
        return "Product:: id->".$this->id.", name->".$this->name.", price->".$this->price.", id_category->".$this->id_category;
    }
}
?>