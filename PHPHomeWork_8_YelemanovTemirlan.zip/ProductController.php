<?php
define("HOST", "localhost");
define("DATABASE", "shop2");
define("CHARSET", "utf8");
define("USER", "root");
define("PASSWORD", "");
require_once("Product.php");
require_once("Category.php"); 
class ProductController{
    public static $pdo;
    public static function GetAllCategories(){
        $categories = [];
        $sql = "SELECT * FROM category;";
        $querry = ProductController::$pdo->prepare($sql);
        $querry->execute();
        if($querry->rowCount() > 0){
            while($row = $querry->fetch(PDO::FETCH_OBJ)){
                $categories[] = new Category($row->id, $row->name);
            }
        }
        return $categories;
    }
    public static function GetProductsByCategoryName(string $categoryName){
        $products = [];
        $sql = "SELECT p.id, p.name,p.price, p.id_category as id_category FROM product AS p JOIN category AS c on p.id_category = c.id WHERE c.name = :categoryName";
        $querry = ProductController::$pdo->prepare($sql);
        $array = [];
        $array["categoryName"] = $categoryName;
        $querry->execute($array);
        if($querry->rowCount() > 0){
            while($row = $querry->fetch(PDO::FETCH_OBJ)){
                $products[] = new Product($row->id, $row->name, $row->price, $row->id_category);
            }
        }
        return $products;
    }
    public static function LoadProduct(){
        if(!isset($_POST["buttonClick"]) ||  
           $_POST["buttonClick"] != "addProduct" ||
           !isset($_POST["productName"]) ||
           !isset($_POST["productPrice"]) || 
           !isset($_POST["categoryName"])) return;
        $sql = "INSERT INTO product(name, price, id_category) VALUES (:name,:price,:id_category);";
        $querry = ProductController::$pdo->prepare($sql);
        $array = [];
        $array["name"] = $_POST["productName"];
        $array["price"] = $_POST["productPrice"];
        $array["id_category"] = $_POST["categoryName"];
        $querry->execute($array);
    }
    public static function LoadCategory(){
        if(!isset($_POST["buttonClick"]) || 
           $_POST["buttonClick"] != "addCategory" ||
           !isset($_POST["newCategoryName"])) return;
        $sql = "INSERT INTO category(name) VALUES (:name);";
        $querry = ProductController::$pdo->prepare($sql);  
        $array = [];
        $array["name"] = $_POST["newCategoryName"];
        $querry->execute($array);
    }
}
ProductController::$pdo = new PDO("mysql:host=".HOST.";dbname=".DATABASE.";charset=".CHARSET,USER,PASSWORD);
?>