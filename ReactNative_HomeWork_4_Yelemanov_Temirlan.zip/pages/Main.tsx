import { Button } from "@rneui/themed";
import { View, Text, Pressable, StyleSheet } from "react-native";
import uuid from 'react-native-uuid';

interface Profile{
    id: string | number[],
    fullname: string,
    email: string,
    phone: string,
    address: string
}

var profile: Profile = {
    id: uuid.v4(),
    fullname: 'Mishutkin Krugov',
    email: 'Mishanya@gmail.com',
    phone: '12223334455',
    address: 'On the flip side of the moon'
}

export default function Main(){
    return (
        <View style={styles.container}>
                <Text>Profile</Text>
            <View style={styles.profile}>
                <Text>Full name: {profile.fullname}</Text>
                <Text>Email: {profile.email}</Text>
                <Text>Phone: {profile.phone}</Text>
                <Text>Address: {profile.address}</Text>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 20
    },
    profile:{
        padding: '5%',
        borderColor: "rgba(82, 211, 255, 1)",
        borderWidth: 2,
        borderRadius: 10,
        gap: 10
    },
    button:{
        borderColor: "rgba(82, 211, 255, 1)",
        borderWidth: 2,
        borderRadius: 10,
        padding: '5%'
    }
});