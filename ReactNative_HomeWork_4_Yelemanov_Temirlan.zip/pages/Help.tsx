import { View, Text, StyleSheet } from "react-native";

const primaryColor = 'rgba(82, 211, 255, 1)';

export default function Help(){
    return (
        <View style={styles.container}>
            <Text>This Page is Information page:</Text>
            <Text style={styles.hint}>Press 'Bank Account' button to see your Cards</Text>
            <Text style={styles.hint}>Press 'Put' or 'Take' button to interract with your card in 'Bank Account' page</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        alignItems: 'center',
        gap: 20
    },
    hint: {
        width: '100%',
        padding: 5,
        borderColor: primaryColor,
        borderWidth: 2,
        borderRadius: 10,
        alignItems: 'center',
        textAlign: 'center'
    }
});