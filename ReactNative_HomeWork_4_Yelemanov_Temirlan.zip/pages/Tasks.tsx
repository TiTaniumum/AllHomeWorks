import React, { useState } from 'react';
import { Dimensions, FlatList, Pressable, SafeAreaView, StyleSheet, TextInput, View, Text } from 'react-native';
import uuid from 'react-native-uuid';


import {Task, TaskItem} from '../components/Task'

var tasksMock: Task[] = [
    {
        id: uuid.v4(),
        title: 'Сходить в магаз',
        status: false,
        due: new Date(2024, 6, 25),
        comment: null
    }
];

export function Tasks(){
    const [tasks, setTasks] = useState<Task[]>([]);
    return (
        <SafeAreaView>
            <FlatList
                data={tasks}
                keyExtractor={(item)=>item.id.toString()}
                renderItem={({item})=><TaskItem task={item}/>}/>
        </SafeAreaView>
    );
};


export function TaskAdder(){
    const [text, setText] = useState("");   

    return (
        <View style={{height: '100%', width:'100%', alignItems:'center', justifyContent:'center', gap:20}}>
            <TextInput style={{width: '80%', borderWidth: 1, borderColor: 'gray', borderRadius: 10, padding: 3}} value={text} onChangeText={(text)=>setText(text)}/>
            <Pressable style={{width: '80%', borderWidth: 1, borderColor: 'gray', borderRadius: 10, backgroundColor:'rgba(124, 214, 169, 0.8)', alignItems:'center', justifyContent: 'center'}} >
                <Text>Add Task</Text>
            </Pressable>
        </View>
    );
};