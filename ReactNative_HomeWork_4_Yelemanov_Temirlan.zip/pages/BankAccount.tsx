import { useState } from "react";
import {
  FlatList,
  SafeAreaView,
  Text,
  View,
  StyleSheet,
  ScrollView,
} from "react-native";
import { AccountItem, Account } from "../components/Account";
import uuid from "react-native-uuid";

var accounts: Account[] = [
  {
    id: uuid.v4(),
    name: "3405-2384-2938-3759",
    amount: 150000,
  },
  {
    id: uuid.v4(),
    name: "3875-4498-3471-2385",
    amount: 23048,
  },
];

export default function BankAccount() {
  return (
    <SafeAreaView>
      <FlatList
        style={{padding:10}}
        data={accounts}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => <AccountItem account={item} />}
        ItemSeparatorComponent={()=><View style={{height:20}}></View>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({});
