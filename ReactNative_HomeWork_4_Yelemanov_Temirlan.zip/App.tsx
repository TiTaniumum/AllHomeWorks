import * as React from "react";
import { StatusBar } from "expo-status-bar";
import {
  ScrollView,
  StyleSheet,
  Animated,
  Text,
  View,
  FlatList,
  SafeAreaView,
  TextInput,
  Pressable,
} from "react-native";
import { Button, CheckBox, Input, SearchBar } from "@rneui/themed";
import { useEffect, useRef, useState } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { NavigationContainer } from "@react-navigation/native";
import FontAwesome from '@expo/vector-icons/FontAwesome';
import EvilIcons from '@expo/vector-icons/EvilIcons';
import { Tasks, TaskAdder} from "./pages/Tasks";
import Settings from "./pages/Settings";
import BankAccount from "./pages/BankAccount";
import Help from "./pages/Help";
import Main from "./pages/Main";

const RootStack = createNativeStackNavigator();

export default function App() {

  return (
    <NavigationContainer>
      <RootStack.Navigator>
        <RootStack.Group>
          <RootStack.Screen
            name="Main"
            component={Main}
            options={({ navigation }) => ({
              // headerLargeTitle: true,
              // headerTitle: ()=><TextInput/>,
              headerLeft: () => (
                <Pressable style={({pressed})=>[{backgroundColor: pressed ? 'rgba(193, 239, 255, 1)' : 'white'},styles.navButtons,]} onPress={()=>{navigation.navigate("BankAccount")}}>
                  <Text>Bank Account</Text>
                  <EvilIcons name="credit-card" size={24} color="rgba(82, 211, 255, 1)"/>
                </Pressable>
              ),
              headerRight: ()=>(
                <Pressable style={({pressed})=>[{backgroundColor: pressed ? 'rgba(193, 239, 255, 1)' : 'white'},styles.navButtons,]} onPress={()=>{navigation.navigate("Help")}}>
                  <EvilIcons name="question" size={24} color="rgba(82, 211, 255, 1)"/>
                  <Text>Help</Text>
                </Pressable>
              )
            })}
          />
          <RootStack.Screen
            name="Settings"
            component={Settings}
            options={() => ({
              headerLargeTitle: true,
            })}
          />

          <RootStack.Screen
            name="BankAccount"
            component={BankAccount}
          />
        </RootStack.Group>
        <RootStack.Group screenOptions={{ presentation: "modal" }}>
          <RootStack.Screen
            name="Help"
            component={Help}
            options={() => ({
              headerLargeTitle: true,
            })}
          />
        </RootStack.Group>
      </RootStack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  navButtons:{
    flexDirection: 'row',
    borderColor: "rgba(82, 211, 255, 1)",
    borderWidth: 2,
    borderRadius: 10,
    padding: 5
  }
});
