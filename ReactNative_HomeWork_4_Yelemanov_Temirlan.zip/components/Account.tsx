import React, { useState } from "react";
import { View, Text, StyleSheet, Pressable, TextInput, Alert } from "react-native";
import EvilIcons from '@expo/vector-icons/EvilIcons';

const primaryColor = 'rgba(82, 211, 255, 1)';

export interface Account {
  id: string | number[];
  name: string;
  amount: number;
}

export function AccountItem({ account }: { account: Account }) {
  // const [amount, setAmount] = useState(account.amount);

  const [amount, setAmount] = useState("");

  const putAmount = function () {
    let v = Number.parseInt(amount);
    account.amount += v;
    setAmount("");
    alert("You have put: " + v);
  };

  const takeAmount = function () {
    let v = Number.parseInt(amount);
    if (v > account.amount) {
      alert("Summ you want to take is too big!");
      return;
    }
    account.amount -= v;
    setAmount("");
    alert("You have taken: " + v);
  };

  return (
    <View style={styles.container}>
      <Text>Card: {account.name}</Text>
      <Text>Amount: {account.amount}</Text>
      <TextInput
        placeholderTextColor="gray"
        placeholder="Type amount you want to put or take"
        keyboardType="numeric"
        maxLength={10}
        onChangeText={setAmount}
        value={amount}
        style={styles.input}
      />
      <View style={styles.buttons}>
        <Pressable style={styles.button} onPress={putAmount}>
          <Text>Put</Text>
          <EvilIcons name="arrow-down" size={24} color={primaryColor}/>
        </Pressable>
        <Pressable style={styles.button} onPress={takeAmount}>
          <Text>Take</Text>
          <EvilIcons name="arrow-up" size={24} color={primaryColor}/>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    width: "100%",
    maxHeight: 200,
    borderWidth: 2,
    borderColor: primaryColor,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10
  },
  buttons: {
    width: '100%',
    flexDirection: 'row',
    justifyContent:'space-around'
  },
  button: {
    flexDirection: 'row',
    borderColor: primaryColor,
    borderWidth: 2,
    borderRadius: 10,
    padding: 5
  },
  input:{
    padding:5,
    borderColor: primaryColor,
    borderWidth: 2,
    borderRadius: 10,
  }
});
