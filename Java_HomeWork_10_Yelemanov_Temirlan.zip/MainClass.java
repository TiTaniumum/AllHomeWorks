import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainClass {
    public static Random random = new Random();

    public static void main(String[] args) {
        //Demo1();
        //Demo2();
        Demo4();
    }

    public static void Demo1() {
        int[] numbers = new int[100];

        Result result = new Result();

        Thread thread1 = new Thread(() -> {
            for (int i = 0; i < numbers.length; i++) {
                numbers[i] = random.nextInt(1000);
            }
        });

        Thread thread2 = new Thread(() -> {
            int sum = 0;
            for (int i = 0; i < numbers.length; i++) {
                sum += numbers[i];
            }
            result.sum = sum;
        });

        Thread thread3 = new Thread(() -> {
            int sum = 0;
            for (int i = 0; i < numbers.length; i++) {
                sum += numbers[i];
            }
            result.avg = sum / numbers.length;
        });

        try {
            thread1.start();
            thread1.join();
            thread2.start();
            thread3.start();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Sum = " + result.sum);
        System.out.println("AVG = " + result.avg);
    }

    public static void Demo2(){
        String filename = "numbers.txt";
        String primesFilename = "primes.txt";
        String factorialsFilename = "factorials.txt";

        Thread thread1 = new Thread(()->{
            try (Writer writer = new FileWriter(filename); 
                 BufferedWriter bufferedWriter = new BufferedWriter(writer)) {

                for(int i = 0; i < 100; i++){
                    Integer n = random.nextInt(100);
                    bufferedWriter.write(n.toString());
                    bufferedWriter.newLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        Thread thread2 = new Thread(()->{
            try (Reader reader = new FileReader(filename);
                 Writer writer = new FileWriter(primesFilename);
                 BufferedReader br = new BufferedReader(reader);
                 BufferedWriter bw = new BufferedWriter(writer);) {
                
                String line = "";
                while((line = br.readLine()) != null){
                    Integer n = Integer.parseInt(line);
                    if(isPrime(n)){
                        bw.write(n.toString());
                        bw.newLine();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        Thread thread3 = new Thread(()->{
            try (Reader reader = new FileReader(filename);
                 Writer writer = new FileWriter(factorialsFilename);
                 BufferedReader br = new BufferedReader(reader);
                 BufferedWriter bw = new BufferedWriter(writer);) {

                String line = "";
                while((line = br.readLine()) != null){
                    Integer n = Integer.parseInt(line);
                    Long f = factorial(n);
                    bw.write(f.toString());
                    bw.newLine();
                }   
            } catch (Exception e) {
                
            }
        });

        try {
            thread1.start();
            thread1.join();
            thread2.start();
            thread3.start();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println("All Done!");
    }

    public static void Demo3(){
        // Нужно было скопировать все из первой дерриктории в новую указанную. В задании не затрагиваются потоки
    }

    public static void Demo4(){
        String badWordsFileName = "badwords.txt";
        String dir = "TextFiles/";
        String resultFileName = "result.txt";
        String withoutBadWordsFileName = "withoutBadWords.txt";
        List<String> badwords = new ArrayList<>();           

        Thread thread1 = new Thread(()->{

            File directory = new File(dir);

            File[] fileList = directory.listFiles();

            try(Reader reader = new FileReader(badWordsFileName);
                BufferedReader br = new BufferedReader(reader);){
                String line = "";
                while((line = br.readLine()) != null){
                    badwords.add(line);
                }

            }catch (Exception e) {
                e.printStackTrace();
            }

            for(File file: fileList){
                try (BufferedReader br = new BufferedReader(new FileReader(dir + file.getName()));
                     BufferedWriter bw = new BufferedWriter(new FileWriter(resultFileName,true));) {
                    boolean contains = false;
                    String line = "";
                    while((line = br.readLine()) != null){
                        if(badwords.stream().anyMatch(line.toLowerCase()::contains)){
                            contains = true;
                            break;
                        }
                    }
                    if(contains){
                        BufferedReader newbr = new BufferedReader(new FileReader(dir+file.getName()));
                        while((line = newbr.readLine()) != null){
                            bw.write(line);
                            bw.newLine();
                        }
                        newbr.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        Thread thread2 = new Thread(()->{
            try(BufferedReader br = new BufferedReader(new FileReader(resultFileName));
                BufferedWriter bw = new BufferedWriter(new FileWriter(withoutBadWordsFileName))){

                String line = "";
                while((line = br.readLine()) != null){
                    for(String word : badwords){
                        int idx = -1;
                        if((idx = line.toLowerCase().indexOf(word)) != -1){
                            line = splice(line, idx, word.length(), "[badword]");
                            System.out.println(line);
                        }
                    }
                    bw.write(line);
                    bw.newLine();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }); 

        try {
            thread1.start();
            thread1.join();
            thread2.start();
            thread2.join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("All Doone!");
    }

    public static String splice(String original, int start, int length, String toAdd){
        if (start < 0) start = 0;
        if (start > original.length()) start = original.length();
        if (length < 0) length = 0;
        int end = Math.min(start + length, original.length());
        String result = original.substring(0, start) + toAdd + original.substring(end);
        return result;
    }

    public static boolean isPrime(int number) {
        if (number <= 1) return false; 
        if (number <= 3) return true;  
        if (number % 2 == 0 || number % 3 == 0) return false;
        for (int i = 5; i * i <= number; i += 6) {
            if (number % i == 0 || number % (i + 2) == 0) return false;
        }
        return true;
    }

    public static long factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("Number must be non-negative.");
        long result = 1;
        for (int i = 1; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}

class Result {
    public int sum = 0;
    public int avg = 0;
}