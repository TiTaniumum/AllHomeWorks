package servlet_classes;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Task2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/task2.jsp").forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int n1 = Integer.parseInt(request.getParameter("num1"));
        int n2 = Integer.parseInt(request.getParameter("num2"));
        int n3 = Integer.parseInt(request.getParameter("num3"));

        String operation = request.getParameter("operation");

        Integer result = null;
        switch (operation){
            case "max":
                result = Math.max(Math.max(n1, n2),n3);
                break;
            case "min":
                result = Math.min(Math.min(n1,n2),n3);
                break;
            case "avg":
                result = (n1+n2+n3)/3;
                break;
        }
        request.setAttribute("result", result);

        request.getRequestDispatcher("/task2.jsp").forward(request, response);
    }
}
