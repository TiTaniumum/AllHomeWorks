package servlet_classes;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Task5 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/task5.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int n1 = Integer.parseInt(req.getParameter("num1"));
        int n2 = Integer.parseInt(req.getParameter("num2"));

        String operation = req.getParameter("operation") == null ? "" : req.getParameter("operation");
        Float result = null;

        switch (operation){
            case "+": result = (float)n1 + n2; break;
            case "-": result = (float)n1 - n2; break;
            case "*": result = (float)n1 * n2; break;
            case "/": result = (float)n1 / n2; break;
            case "^": result = (float)Math.pow(n1, n2); break;
        }

        req.setAttribute("result", result);

        req.getRequestDispatcher("/task5.jsp").forward(req, resp);
    }
}
