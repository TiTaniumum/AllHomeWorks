﻿
#include <iostream>
#include <iomanip>
#include "problem_1.h"
#include "problem_2.h"
#include "problem_3.h"
#include "problem_4.h"
#include "problem_5.h"
#include "problem_6.h"
#include "problem_7.h"
#include "problem_8.h"
#include "problem_9.h"
#include "problem_10.h"
#include "problem_11.h"
#include "problem_12.h"
#include "problem_13.h"
#include "problem_14.h"
#include "problem_15.h"
#include "problem_16.h"
#include "problem_17.h"
#include "problem_18.h"

using namespace std;

int main()
{
  setlocale(LC_CTYPE, "Russian");
  
  //choice();

  //problem_1();
  //problem_2();
  //problem_3();
  //problem_4();
  //problem_5();
  problem_6(); //задача с усложнением
  //problem_7();
  //problem_8();
  problem_9(); //настоятельно рекомендую взглянуть на эту задачу
  //problem_10();
  //problem_11();
  problem_12();
  //problem_13();
  problem_14(); //эта задача показалась мне крайне интересной
  //problem_14_1();
  //problem_15();
  problem_16(); //непонятная задача
  //problem_17();
  //problem_18();
  //problem_18_1();

  cout << "end . . . \n";
}

//функция выбора проблем
void choice() {
  int a;
  cout << "введите номер проблемы: \n1.Площадь, периметр прямоугольника\n2.Определение нужной скорости до аэропорта\n3.Стоймость телефонного разговора\n4.Площадь, периметр окружности\n5.Возведение чисел в степень\n6.вычисление байтов и наоборот\n7.cумма чисел, произведение, среднее арифметическое\n8.вычисление времени оставшегося работнику на работе\n";
  cout << "9.перевод секунд в настоящее время и в оставшееся до полуночи\n\n";
  //лень было дописывать описание всем зачам..
  //теперь я понял что это не практично, хотя бы в нынишних задачах.

  cin >> a;

  switch (a) {
  case 1:
    problem_1();
    break;
  case 2:
    problem_2();
    break;
  case 3:
    problem_3();
    break;
  case 4:
    problem_4();
    break;
  case 5:
    problem_5();
    break;
  case 6:
    problem_6();
    break;
  case 7:
    problem_7();
    break;
  case 8:
    problem_8();
    break;
  case 9:
    problem_9();
    break;
  case 10:
    problem_10();
    break;
  case 11:
    problem_11();
    break;
  case 12:
    problem_12();
    break;
  case 13:
    problem_13();
    break;
  case 14:
    problem_14();
    problem_14_1();
    break;
  case 15:
    problem_15();
    break;
  case 16:
    problem_16();
    break;
  case 17:
    problem_17();
    break;
  case 18:
    problem_18();
    problem_18_1();
    break;
  default:
    cout << "такого номера проблемы не существует.\n";
  }
}
