<?php 
define("HOST", "localhost");
define("DATABASE", "classicmodels");
define("CHARSET", "utf8");
define("USER", "root");
define("PASSWORD", "");
if(isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["formSubmit"])){
    if($_POST["formSubmit"] == "1"){
        $salt =  randstr(40);
        $sql = "CALL add_user(?,?,?,?)";
        $params = array($salt,$_POST["email"],$_POST["password"], $_POST["customerId"]);
        $pdo = new PDO("mysql:host=".HOST.";dbname=".DATABASE.";charset=".CHARSET,USER,PASSWORD);
        $query = $pdo->prepare($sql);
        $query->execute($params);
        $userid = $pdo->lastInsertId();
    }
    else if($_POST["formSubmit"] == "2"){
        $sql = "select customerId from users where _hash(salt, ?) = password and email = ?";
        $params = array($_POST["password"],$_POST["email"]);
        $pdo = new PDO("mysql:host=".HOST.";dbname=".DATABASE.";charset=".CHARSET,USER,PASSWORD);
        $query = $pdo->prepare($sql);
        $query->execute($params);
        echo $_POST["password"];
        if($query->rowCount() > 0){
            echo "Success!";
        }else {
            echo "Not Success...";
        }
    }
}
else{
    include("addUser.html");
    include("authUser.html");
}

function randstr($length = 32){
    $charset = "0123456789abcdef";
    $str = "";
    for($i = 0; $i< $length; $i++){
        $str .= $charset[random_int(0,strlen($charset)-1)];
    }
    return $str;
}
?>