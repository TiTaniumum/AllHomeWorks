
delimiter //
CREATE FUNCTION _hash (salt varchar(64), value varchar(64))
returns varchar(40)
begin
return SHA1(concat(salt, MD5(value)));
end//
delimiter ;

drop trigger if exists hash_password;
delimiter //
create trigger hash_password 
before insert on users
for each row
begin
	SET NEW.password = _hash(NEW.salt, NEW.password);
end//
delimiter ;

drop trigger if exists update_hash_password;
delimiter //
create trigger update_hash_password 
before update on users
for each row
begin
	SET NEW.password = _hash(NEW.salt, NEW.password);
    SET NEW.salt = OLD.salt;
end//
delimiter ;

drop procedure if exists log;
delimiter //
create procedure log (in param_user_id int, in param_action_id int)
begin 
insert into logs(user_id, action_id) values
(param_user_id, param_action_id);
end//
delimiter ;

select * from logs;
call log(4,2);

drop procedure if exists add_user;
delimiter //
create procedure add_user (in _salt varchar(128),in _email varchar(64),in _password varchar(64),in _customerId int)
begin 
insert into users(salt, email,password,customerId) values
(_salt, _email,_password, _customerId);
call log((select max(id) from users), 2);
end//
delimiter ;