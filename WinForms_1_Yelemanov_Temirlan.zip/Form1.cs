﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winformsHW1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnShowResume_Click(object sender, EventArgs e)
        {
            List<string> resume = new List<string>();
            resume.Add("FullName: Elemanov Temirlan.");
            resume.Add("Age: 23");
            resume.Add("Profession: Programist");
            resume.Add("Experience: Sushi maker, general worker, Glovo deliverer");
            foreach(string s in resume)
            {
                MessageBox.Show(s, "Resume", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            MessageBox.Show("Message box count: " + resume.Count.ToString(), "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Загадайте число от 1 до 2000", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            int left = 1;
            int right = 2000;
            int mid = (left+ right)/2;
            int cnt = 0;
            while (left!=right)
            {
                DialogResult res = MessageBox.Show("Ваше число равно " + mid+ "?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                cnt++;
                if(res == DialogResult.Yes)
                {
                    MessageBox.Show("ваше число " + mid + "!", "Число отгадано", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
                else
                {
                    DialogResult res2 = MessageBox.Show("Ваше число больше " + mid + "?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    cnt++;
                    if (res2 == DialogResult.Yes)
                    {
                        left = mid+1;
                    }
                    else
                    {
                        right = mid-1;
                    }
                }
                mid = (left+right)/2;
                if(left == right)
                {
                    MessageBox.Show("ваше число " + left + "!", "Число отгадано", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            MessageBox.Show("Потребовалось " + cnt + " запросов что бы угадать ваше число!", "Сводная информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
