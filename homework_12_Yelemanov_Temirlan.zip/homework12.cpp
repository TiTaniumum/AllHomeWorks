﻿#include <iostream>
#include <algorithm>
#include <iomanip>
#include <stdlib.h>
#include <random>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
#include "problem7.h"
#include "problem8.h"
#include "problem9.h"
#include "problem10.h"

using namespace std;


int main()
{
  setlocale(LC_CTYPE, "Russian");
  //аудиторные задания 
  //problem1();
  //problem2();
  //домашние задания
  //problem3(); //перемешал массив с уникальными числами
  //problem4(); //дз
  //problem5(); //усложненная
  //задания из следующего листа задач
  //problem6();
  //problem7(); // проверка на уникальность чисел
  //problem7_1(); // быстрая проверка на уникальность чисел
  //problem8();
  //problem9(); // бинарный поиск
  problem10(); // усложненная 
  cout << "end! . . . . . .. . . \n";
}
