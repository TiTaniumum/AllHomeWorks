﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Sys7
{
    [Serializable]
    public class Resume
    {
        //public string path { get; set; }
        public string name { get; set; }
        public int salaryRequirement { get; set; }
        public short jobExperience { get; set; }
        public City city { get; set; }
        [NonSerialized]
        public static Random random;
        static Resume()
        {
            random = new Random();
        }
        public Resume(){
            name = GenerateString();
            salaryRequirement = random.Next(100000,1000000);
            jobExperience = (short)random.Next(0, 50);
            city = (City)random.Next(0,Enum.GetValues(typeof(City)).Length);
        }
        public Resume(string name, int salaryRequirement, short jobExperience, City city)
        {
            this.name = name;
            this.salaryRequirement = salaryRequirement;
            this.jobExperience = jobExperience;
            this.city = city;
        }
        static public string GenerateString()
        {
            short minLength = 4;
            short maxLength = 15;
            string str = string.Empty;
            str += (char)random.Next('A', 'Z');
            for (int i = minLength;i <= maxLength;i++)
            {
                str += (char)random.Next('a','z');
            }
            return str;
        }
        public static void Serialize(Resume resume, string path)
        {
            File.WriteAllText(path,string.Empty);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Resume));
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                xmlSerializer.Serialize(fs, resume);
            }
        }
        public static Resume Deserialize(string path)
        {
            XmlSerializer xmlSerializer = new XmlSerializer (typeof(Resume));
            Resume resume = null;
            using (FileStream fs = new FileStream(path, FileMode.Open))
            {
                resume = xmlSerializer.Deserialize(fs) as Resume;
            }
            return resume;
        }
    }
    public enum City
    {
        Solitude,
        Morthal,
        Markarth,
        Whiterun,
        Dawnstar,
        Winterhold,
        Windhelm,
        Falkreath,
        Riften,
    }
}
