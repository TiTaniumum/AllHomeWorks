﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;

//Создайте приложение для анализа массива резюме. 
//Каждое резюме находится в файле. Формат файла фиксированный. Пользователь может загрузить одно резюме,
//несколько резюме или все резюме в папке. Загрузка резюме выполняется с помощью механизмов параллельного 
//программирования. Приложение должно поддерживать 
//следующие отчёты:
//■ Самый опытный кандидат (по количеству лет опыта);
//■ Самый неопытный кандидат (по количеству лет опыта);
//■ Кандидаты из одного города;
//■ Кандидат с самыми низкими зарплатными требованиями;
//■ Кандидат с самыми высокими зарплатными требованиями.
//Используйте механизмы параллельного программирования для формирования отчётов.
//Отчёты отображаются в окне приложения.

namespace Sys7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public short leastYears = -1;
        public short mostYears = -1;
        public int leastSalery = -1;
        public int mostSalery = -1;

        public object lylock = new object();
        public object mylock = new object();
        public object lslock = new object();
        public object mslock = new object();
        public int resumeCount = 50;
        private void buttonInit_Click(object sender, EventArgs e)
        {
            buttonInit.Enabled = false;
            checkedListBox1.Items.Clear();
            Thread thread = new Thread(InitResumeList);
            thread.IsBackground = true;
            thread.Start();
        }
        public void InitResumeList(object parameter)
        {
            //int resumeCount = 50;
            string name = "Resume";
            progressBar1.Invoke((Action)delegate { progressBar1.Value = progressBar1.Minimum; progressBar1.Maximum = resumeCount; progressBar1.Step = 1; });
            for (int i = 0; i < resumeCount; i++)
            {
                Resume resume = new Resume();
                string path = name+i+".xml";
                Resume.Serialize(resume, path);
                checkedListBox1.Invoke((Action)delegate { checkedListBox1.Items.Add(path); });
                progressBar1.Invoke((Action)delegate { progressBar1.PerformStep(); });
            }
            buttonInit.Invoke((Action)delegate { buttonInit.Enabled = true; });
        }

        private void buttonAnalyze_Click(object sender, EventArgs e)
        {
            leastSalery = -1;
            mostSalery = -1;
            leastYears  = -1;
            mostYears = -1;
            progressBar1.Value = progressBar1.Minimum;
            progressBar1.Maximum = checkedListBox1.CheckedItems.Count;
            List<string> list = new List<string>();
            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
            {
                list.Add(checkedListBox1.CheckedItems[i].ToString());
            }
            List<List<string>> lists = new List<List<string>>();
            for (int i = 0; i < numericUpDown1.Value; i++)
            {
                lists.Add(new List<string>());
            }
            //делю лист по колличеству потоков
            for (int i = 0; i < list.Count; i++)
            {
                lists[i%(int)numericUpDown1.Value].Add(list[i]);
            }
            for (int i = 0; i< lists.Count; i++)
            {
                Thread thread = new Thread(Analyze);
                thread.IsBackground = true;
                thread.Start(lists[i]);
            }
        }
        public void Analyze(object arg)
        {
            List<string> paths = arg as List<string>;
            Resume resume;
            Monitor.Enter(this);
            
            if (leastYears==-1 && paths.Count!= 0)
            {
                resume = Resume.Deserialize(paths[0]);
                leastYears = resume.jobExperience;
                mostYears = resume.jobExperience;
                leastSalery = resume.salaryRequirement;
                mostSalery = resume.salaryRequirement;
            }
            Monitor.Exit(this);
            for (int i = 0; i < paths.Count; i++)
            {
                progressBar1.Invoke((Action)delegate { progressBar1.PerformStep(); });
                resume = Resume.Deserialize(paths[i]);
                if (resume == null) continue;
                lock (lylock) if (leastYears > resume.jobExperience) leastYears = resume.jobExperience;
                lock (mylock) if (mostYears < resume.jobExperience) mostYears = resume.jobExperience;
                lock (lslock) if (leastSalery >resume.salaryRequirement) leastSalery = resume.salaryRequirement;
                lock (mslock) if (mostSalery < resume.salaryRequirement) mostSalery = resume.salaryRequirement;
            }
            Monitor.Enter(this);
            this.Invoke((Action)delegate
            {
                lLeastExp.Text = "Least experienced: "+ leastYears;
                lMostExp.Text = "Most experienced: "+ mostYears;
                lLeastS.Text = "Least salary expectation: " + leastSalery;
                lMostS.Text = "Most salary expectation: " + mostSalery;
            });
            Monitor.Exit(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, true);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }
        }
    }
}
