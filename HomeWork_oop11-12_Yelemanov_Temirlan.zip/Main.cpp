#include "problem1.h"
#include "problem2.h"
int main() {
  //problem1();
  problem2();
}