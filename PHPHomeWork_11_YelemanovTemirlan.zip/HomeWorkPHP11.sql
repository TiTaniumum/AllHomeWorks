use gameshop;

create table subscriptions(
id int primary key auto_increment,
id_customer int not null,
name varchar(32)
);

insert into subscriptions(id_customer, name) values
(1, "News"),
(2, "News"),
(3, "News"),
(4, "News"),
(5, "Notification"),
(6, "Notification"),
(7, "Notification");

insert into subscriptions(id_customer, name) values
(1, "Notification");

-- 1) ============================ --
select count(c.id) as SubscribedCustomersAndNot from customers c
where c.id in(select id_customer from subscriptions
group by id_customer)
union
select count(c.id) from customers c
where c.id not in(select id_customer from subscriptions
group by id_customer);


alter table customers add column country varchar(32);
alter table customers add column city varchar(32);

update customers
set country = "Kazakhstan"
where id = case when id%2=0 then id else 0 end;

update customers
set country = "Russia"
where id = case when id%3=0 then id  else 0 end;

update customers
set country = "USA"
where country is null;

update customers 
set city = "Almaty"
where id in(2,4);

update customers
set city = "Astana"
where id in(select id from customers where country = "Kazakhstan" and city is null);

update customers
set city = "Petersburg"
where id in(3,6,9);

update customers
set city = "Moscow"
where id in(select id from customers where country = "Russia" and city is null);

update customers
set city = "Ohio"
where id=1;

update customers
set city = "NewYork"
where id in(select id from customers where country = "USA" and city is null);

update customers
set country = "Kazakhstan"
where id in(select id from customers where country = "USA" and city = "NewYork");
update customers
set city = "Astana"
where city = "NewYork";

-- 2)  ================================   --
select id, country, count(city) as CityCount from customers
group by country
having CityCount > 3;

-- 3) =================================   --
select concat(firstname," " ,lastname) as fullname, count(*) as dealcount from deals d
left join customers c on d.id_customer = c.id
group by c.id;

create view DealCountPerUser as 
select concat(firstname," " ,lastname) as fullname, count(*) as dealcount from deals d
left join customers c on d.id_customer = c.id
group by c.id;

select * from DealCountPerUser 
where dealcount >= 4;