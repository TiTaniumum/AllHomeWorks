﻿using System;
using System.Diagnostics;

namespace Sys1_1
{
    public class MainClass
    {
        public static Random рандом = new Random();
        public static void Main(string[] аргументы)
        {
            List<int> Результаты = new List<int>();
            for (int и = 0; и<10; и++)
            {
                int число1 = рандом.Next(0, 1000);   
                int число2 = рандом.Next(0,1000);
                string операция = дайРандомнуюОперацию();
                Process процесс = Process.Start("simpleCalculator\\Sys1.exe", число1 + " " + операция + " " + число2);
                процесс.WaitForExit();
                Результаты.Add(процесс.ExitCode);
            }
            Console.WriteLine("-----------------------------------------------------------------------------------------");
            Console.WriteLine("Results: ");
            foreach (int результат in Результаты)
            {
                Console.WriteLine(результат);
            }
            Console.ReadLine();
        }
        public static string дайРандомнуюОперацию()
        {
            switch (рандом.Next(0, 5))
            {
                default:
                case 0: return "+";
                case 1: return "-";
                case 2: return "/";
                case 3: return "%";
                case 4: return "*";
            }
        }
    }
}