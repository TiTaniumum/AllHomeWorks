﻿using System;

namespace Sys1
{
    public class MainClass
    {
        public static int Main(string[] аргументы)
        {
            double число1 = 0;
            double число2 = 0;
            string операция = string.Empty;
            bool правильноли = true;
            int счетчик = 0;
            double результат = 0;
            foreach (string аргумент in аргументы)
            {
                if (счетчик>=3) break;
                if (Операцияли(аргумент))
                {
                    операция = аргумент;
                }
                else
                {
                    if (число1 == 0)
                    {
                        if (!double.TryParse(аргумент, out число1))
                        {
                            Console.WriteLine("Arguments were not right!");
                            правильноли = false;
                            break;
                        }
                    }
                    else
                    {
                        if (!double.TryParse(аргумент, out число2))
                        {
                            Console.WriteLine("Arguments were not right!");
                            правильноли = false;
                            break;
                        }
                    }
                }
                счетчик++;
            }
            if (счетчик!=3)
            {
                Console.WriteLine("Arguments missing!");
            }
            if (правильноли)
            {
                if(!Вычисление(число1, операция, число2, out результат)){
                    Console.WriteLine("Arguments didn't have any operation sign!");
                    return (int)результат;
                }
                Console.WriteLine(число1 + " " + операция + " " + число2 + " = " + результат);
                Console.WriteLine("Result: " + результат);
            }
            return (int)результат;
        }
        public static bool Операцияли(string строка)
        {
            switch (строка)
            {
                case "+":
                case "-":
                case "*":
                case "/":
                case "%":
                    return true;
                default:
                    return false;
            }
        }
        public static double Вычисление(double число1, string операция, double число2)
        {
            switch (операция)
            {
                case "+": return число1+число2;
                case "-": return число1-число2;
                case "*": return число1*число2;
                case "/": return число1/число2;
                case "%": return число1%число2;
                default:
                    throw new Exception("Arguments didn't have any operation sign!");
            }
        }
        //true if operation was successfull
        public static bool Вычисление(double число1, string операция, double число2, out double результат)
        {
            switch (операция)
            {
                case "+": результат = число1+число2; return true;
                case "-": результат = число1-число2; return true;
                case "*": результат = число1*число2; return true;
                case "/": результат = число1/число2; return true;
                case "%": результат = число1%число2; return true;
                default: результат = 0; return false;
            }
        }
    }
}