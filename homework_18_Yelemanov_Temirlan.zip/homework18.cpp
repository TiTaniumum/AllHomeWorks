﻿#include <iostream>
#include <iomanip>
#include <random>
#include <algorithm>
#include "problem1.h"
#include "problem2.h"
using namespace std;

int main()
{
  srand(time(NULL));
  //problem1(); //homework
  problem2(); //CollatzConjecture
  cout << "\nend!  ..  . . . . .\n";
}