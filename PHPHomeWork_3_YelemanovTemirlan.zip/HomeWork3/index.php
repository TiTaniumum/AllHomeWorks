<?php
//  Создайте функцию, которая принимает на входе массив, 
//  ищет в нем отрицательные числа, выводит массив на страницу
//  и меняет цвет отрицательных чисел на красный.
function createArr($length = 20, $min = -20, $max = 20)
{
    if($min > $max){
        $temp = $min;
        $min = $max;
        $max = $temp;
    }
    $arr = [];
    for ($i = 0; $i < $length; $i++) {
        $arr[$i] = rand($min, $max);
    }
    return $arr;
}
function printHilightNegativeNums($arr)
{
    foreach ($arr as $k => $v) {
        if ($v < 0) {
            echo "<p class='negativeNum'>";
            echo "$v";
            echo "</p>";
        } else {
            echo " $v ";
        }
    }
}
// Создайте функцию, которая будет конвертировать число
// в текст (4532 — четыре тысячи пятьсот тридцать два). На входе
// функция принимает число, на выходе возвращает результирующую
// строку

function getDigitName($digit)
{
    switch ($digit) {
        case 1:
            return "one";
        case 2:
            return "two";
        case 3:
            return "three";
        case 4:
            return "four";
        case 5:
            return "five";
        case 6:
            return "six";
        case 7:
            return "seven";
        case 8:
            return "eight";
        case 9:
            return "nine";
        //case 0: return "zero";
    }
    return "";
}
function get10To19Name($num)
{
    switch ($num) {
        case 10:
            return "ten";
        case 11:
            return "eleven";
        case 12:
            return "twelve";
        case 13:
            return "thirteen";
        case 14:
            return "fourteen";
        case 15:
            return "fiveteen";
        case 16:
            return "sixteen";
        case 17:
            return "seventeen";
        case 18:
            return "eighteen";
        case 19:
            return "nineteen";
    }
}
function getTens($num)
{
    if ($num < 10)
        return getDigitName($num);
    if ($num < 20)
        return get10To19Name($num);
    $temp = (string) $num;
    switch ($temp[0]) {
        case 2:
            return "twenty " . getDigitName($temp[1]);
        case 3:
            return "thirty " . getDigitName($temp[1]);
        case 4:
            return "fourty " . getDigitName($temp[1]);
        case 5:
            return "fivety " . getDigitName($temp[1]);
        case 6:
            return "sixty " . getDigitName($temp[1]);
        case 7:
            return "seventy " . getDigitName($temp[1]);
        case 8:
            return "eighty " . getDigitName($temp[1]);
        case 9:
            return "ninety " . getDigitName($temp[1]);
    }
    return "";
}
function getHundreds($num)
{
    if ($num == 0)
        return "";
    return getTens($num) . " hundred";
}
function getThousands($num)
{
    if ($num == 0)
        return "";
    if ($num < 100)
        return getTens($num) . " thousand";
    $temp1 = (string) $num;
    return getHundreds($temp1[0]) . " " . getTens($temp1[1] . $temp1[2]) . " thousand";
}
function stringifyNum($num)
{
    $temp2 = (string) $num;
    if ($num == 0)
        return "zero";
    if ($num < 100)
        return getTens($num);
    if ($num < 1000)
        return getHundreds($temp2[0]) . " " . getTens($temp2[1] . $temp2[2]);
    if ($num < 10000)
        return getThousands($temp2[0]) . " " . getHundreds($temp2[1]) . " " . getTens($temp2[2] . $temp2[3]);
    if ($num < 100000)
        return getThousands($temp2[0] . $temp2[1]) . " " . getHundreds($temp2[2]) . " " . getTens($temp2[3] . $temp2[4]);
    if ($num < 1000000)
        return getThousands($temp2[0] . $temp2[1] . $temp2[2]) . " " . getHundreds($temp2[3]) . " " . getTens($temp2[4] . $temp2[5]);
    return "your number is too big!";
}

$num = isset($_POST["stringifyNum"]) ? $_POST["stringifyNum"] : null;
$stringifiedNum = "";
if ($num != null) {
    $stringifiedNum = stringifyNum($num);
}

//создайте функцию, которая на входе принимает переменные name, image, price и создаёт карточку продукта с информацией о нём и кнопкой «Купить»
function createProductCard($name, $imgurl, $price)
{
    return "<div class='item'>
            <p>$name</p>
            <img src='$imgurl'>
            <p>$price $</p>
            <button>Buy</button>
        </div>
        ";
}

$name = isset($_POST["productName"]) ? $_POST["productName"] : null;
$imgurl = isset($_POST["imgurl"]) ? $_POST["imgurl"] : null;
$price = isset($_POST["price"]) ? $_POST["price"] : null;
$isFilled = false;
if ($name != null && $imgurl != null && $price != null) {
    $isFilled = true;
}

// Создайте функцию, которая на вход принимает два числа: 
// число, которое нужно возвести в степень и степень до которого
// нужно возвести число.

function powNum($num, $exponent)
{
    $result1 = $num;
    for ($i = 1; $i < $exponent; $i++) {
        $result1 *= $num;
    }
    return $result1;
}
$number = isset($_POST["number"]) ? $_POST["number"] : null;
$exponent = isset($_POST["exponent"]) ? $_POST["exponent"] : null;
$result = "";
if ($number != null && $exponent != null) {
    $result = powNum($number, $exponent);
}

// Создайте функцию, которая принимает пример в виде
// строки и возвращает подсчитанный результат. Требования к примеру: однозначные числа (цифры), действия +, –, ×, ÷. Операции
// должны происходить в правильной математической последовательности (сначала действия умножения и деления, затем сложение и вычитание)
function splitByOperators($str)
{
    $splited = [];
    $tempnum = "";
    for ($i = 0; $i < strlen($str); $i++) {
        if ($i == strlen($str) - 1) {
            $splited[] = $tempnum . $str[$i];
        } else if ($str[$i] == "+" || $str[$i] == "-" || $str[$i] == "*" || $str[$i] == "/") {
            $splited[] = $tempnum;
            $splited[] = $str[$i];
            $tempnum = "";
        } else {
            $tempnum .= $str[$i];
        }

    }
    return $splited;
}
function isOperator($str)
{
    return $str == "+" || $str == "-" || $str == "*" || $str == "/";
}
function isMultOrDiv($str)
{
    return $str == "*" || $str == "/";
}
function calculate($str)
{
    $splited = splitByOperators($str);
    for ($i = 0; $i < count($splited); $i++) {
        if (isOperator($splited[$i])) {
            if (isMultOrDiv($splited[$i])) {
                $temp = "";
                switch ($splited[$i]) {
                    case "*":
                        $temp = $splited[$i - 1] * $splited[$i + 1];
                        break;
                    case "/":
                        $temp = $splited[$i - 1] / $splited[$i + 1];
                        break;
                }
                array_splice($splited, $i - 1, 3, $temp);
                $i = $i - 1;
            }
        }
    }
    for ($i = 0; $i < count($splited); $i++) {
        if (isOperator($splited[$i])) {
            $temp = "";
            switch ($splited[$i]) {
                case "+":
                    $temp = $splited[$i - 1] + $splited[$i + 1];
                    break;
                case "-":
                    $temp = $splited[$i - 1] - $splited[$i + 1];
                    break;
            }
            array_splice($splited, $i - 1, 3, $temp);
            $i = $i - 1;
        }
    }
    return join("", $splited);
}
$calculation = isset($_POST["calculation"]) ? $_POST["calculation"] :null;
$calculationResult = "";
if($calculation !=  null){
    $calculationResult = calculate($calculation);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <hr>
    <div class='row'>
        <?php printHilightNegativeNums(createArr()); ?>
    </div>
    <hr>
    <form action="index.php" method="post">
        <input type="number" name="stringifyNum">
        <button type="submit">stringify</button>
        <?= $stringifiedNum; ?>
    </form>
    <hr>
    <form action="index.php" method="post">
        <input type="text" placeholder="product name..." name="productName">
        <input type="text" placeholder="URL..." name="imgurl">
        <input type="number" placeholder="price..." name="price">
        <button type="submit">Create</button>
        <br>
        <?php
        if ($isFilled) {
            echo createProductCard($name, $imgurl, $price);
        }
        ?>
    </form>
    <hr>
    <form action="index.php" method="post">
        <input type="number" name="number" placeholder="number">
        <input type="number" name="exponent" placeholder="exponent">
        <button type="submit">POW</button>
        <?= $result; ?>
    </form>
    <hr>
    <form action="index.php" method="post">
        <input type="text" name="calculation" placeholder="12+30*23...">
        <button type="submit">Calculate</button>
        <?=$calculationResult?>
    </form>
    <hr>
    <form action="index.php" method="post">
        <input type="number" name="arrlength" placeholder="length of array">
        <input type="number" name="minval" placeholder="minimum value">
        <input type="number" name="maxval" placeholder="maximum value">
        <button type="submit">Get Array</button>
        <div class='row'>
        <?php 
            $arrlength = isset($_POST["arrlength"]) ? $_POST["arrlength"] : null;
            $minval = isset($_POST["minval"]) ? $_POST["minval"] : null;
            $maxval = isset($_POST["maxval"]) ? $_POST["maxval"] : null;
            if($arrlength && $minval && $maxval){
                printHilightNegativeNums(createArr($arrlength, $minval, $maxval));
            }
         ?>
        </div>
    </form>
</body>

</html>