use shop3;

create view productCountPerUser as 
select u.name as UserName, count(c.id) as productCount from cart c 
join product p on c.id_product = p.id
join user u on c.id_user = u.id
group by u.name
order by c.id;

select * from productCountPerUser;

create view SortedProductCountPerUser as 
select u.name as UserName, count(c.id) as productCount from cart c 
join product p on c.id_product = p.id
join user u on c.id_user = u.id
group by u.name
order by productCount desc;

select * from SortedProductCountPerUser;

insert into user(name) value
("Zhmot Zhmotyara"),
("Bomzh Bomzhevich");

create view UsersDidntBuy as
select * from user
where id not in(select id_user from cart group by id_user);

select * from UsersDidntBuy;

insert into cart(id_user,id_product) values
(1, 9),
(5, 9),
(3, 9);


create view LeasExpensiveProductCountAndSumEverBought as
with LeastExpensiveProduct as (select id, name , price from product
order by price limit 1)
select lep.name,count(*) as ProductCount, sum(lep.price) as Total from cart c
join LeastExpensiveProduct lep on c.id_product = lep.id;

select * from LeasExpensiveProductCountAndSumEverBought;


create view MostPopularProductPerCategory as
with EveryProductCountEverBought as (
select cat.name as CategoryName, p.name as ProductName, count(id_product) as productCount from cart c
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
group by p.name
order by cat.name, productCount desc)
select CategoryName, ProductName ,max(productCount) as PopularProductCount from EveryProductCountEverBought
group by CategoryName;

select * from MostPopularProductPerCategory;


create view LeastExpensiveProductPerCategory as
with EveryProductCountEverBought as (
select cat.name as CategoryName, p.name as ProductName, count(id_product) as productCount, p.price from cart c
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
group by p.name
order by cat.name, productCount desc)
select CategoryName, ProductName ,min(price) as PriceOfLeastExpensiveProduct, productCount from EveryProductCountEverBought
group by CategoryName
order by PriceOfLeastExpensiveProduct desc;

select * from LeastExpensiveProductPerCategory;

alter table user add column age int;

update user
set age = FLOOR(Rand()*(60-15))+15
where id < 11;

select * from user;

create view UsersThatDidntFillSomeFields as
select * from user 
where name is null or age is null;

select * from UsersThatDidntFillSomeFields;

create view AscSortedProductsUserBought as
select u.name as UserName, p.name as ProductName, p.price from cart c
join product p on c.id_product = p.id
join user u on c.id_user = u.id
order by u.name, p.price;

select * from AscSortedProductsUserBought;

create view TotalSpentPerUser as
select u.name as UserName, p.name as ProductName, sum(p.price) as Total from cart c
join product p on c.id_product = p.id
join user u on c.id_user = u.id
group by u.name
order by Total;

select * from TotalSpentPerUser;


create view ProductsEverBoughtCountAndSum as
select p.name as ProductName, count(*) as BoughtCount, sum(p.price) as Total from cart c
join product p on c.id_product = p.id
group by c.id_product
order by BoughtCount;

select* from ProductsEverBoughtCountAndSum;



create table backup_users(
id int primary key not null auto_increment,
id_user int,
old_name varchar(32),
old_age int, 
new_name varchar(32),
new_age int,
change_date datetime default now()
);

delimiter //
create trigger user_update_trigger before update on user 
for each row
begin 
	insert into backup_users(id_user, old_name, old_age, new_name, new_age) values
    (old.id,old.name, old.age, new.name,new.age);
end//
delimiter ;

select * from user;

update user 
set name = "Street Bomzhevski"
where id = 12;

update user
set name = "Bomzh Bomzhevich"
where id = 12;

select * from backup_users;


create table backup_product(
id int auto_increment not null primary key,
product text,
deleted_date datetime default now()
);

select* from product;

delimiter //
create trigger SaveDeleted before delete on product 
for each row
begin
	insert into backup_product(product) values
    (concat("{id: '",old.id,"', name: '",old.name,"', price: ",old.price,", id_category: ",old.id_category,"}"));
end//
delimiter ;

insert into product(name, price, id_category) values
("test", 10, 1);

delete from product
where name= "test";

select * from backup_product;

delimiter //
create function GetNameById(id_user int) returns varchar(32)
begin 
return (select name from user where id = id_user);
end//
delimiter ;

select GetNameById(1);


delimiter //
create function GetUserChangeHistory(id_user_search int) returns text
begin
	return (select group_concat(concat(old_name,"->",new_name) separator " | " ) from backup_users
	where id_user = id_user_search);
end//
delimiter ;

select GetUserChangeHistory(12);