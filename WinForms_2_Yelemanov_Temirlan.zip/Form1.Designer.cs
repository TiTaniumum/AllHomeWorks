﻿namespace winformsHW2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbOilType = new System.Windows.Forms.ComboBox();
            this.tbOilValue = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbtnAmount = new System.Windows.Forms.RadioButton();
            this.rbtnSum = new System.Windows.Forms.RadioButton();
            this.tbSum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbLiterAmount = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lAutostationTotal = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbHotDog = new System.Windows.Forms.CheckBox();
            this.cbHamburger = new System.Windows.Forms.CheckBox();
            this.cbFries = new System.Windows.Forms.CheckBox();
            this.cbCola = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbHotDog = new System.Windows.Forms.TextBox();
            this.tbHamburger = new System.Windows.Forms.TextBox();
            this.tbFries = new System.Windows.Forms.TextBox();
            this.tbCola = new System.Windows.Forms.TextBox();
            this.tbHotDogValue = new System.Windows.Forms.TextBox();
            this.tbHamburgerValue = new System.Windows.Forms.TextBox();
            this.tbFriesValue = new System.Windows.Forms.TextBox();
            this.tbColaValue = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lKafeTotal = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnPay = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.lTotal = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.tbLiterAmount);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbSum);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbOilValue);
            this.groupBox1.Controls.Add(this.cbOilType);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(446, 393);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Автозаправка";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(24, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Бензин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(24, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Цена";
            // 
            // cbOilType
            // 
            this.cbOilType.FormattingEnabled = true;
            this.cbOilType.Items.AddRange(new object[] {
            "АИ-92",
            "АИ-95",
            "АИ-98",
            "ДТ",
            "Газ",
            ""});
            this.cbOilType.Location = new System.Drawing.Point(149, 42);
            this.cbOilType.Name = "cbOilType";
            this.cbOilType.Size = new System.Drawing.Size(194, 24);
            this.cbOilType.TabIndex = 2;
            this.cbOilType.SelectedIndexChanged += new System.EventHandler(this.cbOilType_SelectedIndexChanged);
            // 
            // tbOilValue
            // 
            this.tbOilValue.Enabled = false;
            this.tbOilValue.Location = new System.Drawing.Point(149, 89);
            this.tbOilValue.Name = "tbOilValue";
            this.tbOilValue.Size = new System.Drawing.Size(194, 22);
            this.tbOilValue.TabIndex = 3;
            this.tbOilValue.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(349, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "тг.";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.rbtnSum);
            this.panel1.Controls.Add(this.rbtnAmount);
            this.panel1.Location = new System.Drawing.Point(29, 133);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(153, 109);
            this.panel1.TabIndex = 5;
            // 
            // rbtnAmount
            // 
            this.rbtnAmount.AutoSize = true;
            this.rbtnAmount.Checked = true;
            this.rbtnAmount.Location = new System.Drawing.Point(20, 19);
            this.rbtnAmount.Name = "rbtnAmount";
            this.rbtnAmount.Size = new System.Drawing.Size(106, 20);
            this.rbtnAmount.TabIndex = 1;
            this.rbtnAmount.TabStop = true;
            this.rbtnAmount.Text = "Количество";
            this.rbtnAmount.UseVisualStyleBackColor = true;
            this.rbtnAmount.CheckedChanged += new System.EventHandler(this.rbtnAmount_CheckedChanged);
            // 
            // rbtnSum
            // 
            this.rbtnSum.AutoSize = true;
            this.rbtnSum.Location = new System.Drawing.Point(20, 65);
            this.rbtnSum.Name = "rbtnSum";
            this.rbtnSum.Size = new System.Drawing.Size(71, 20);
            this.rbtnSum.TabIndex = 2;
            this.rbtnSum.Text = "Сумма";
            this.rbtnSum.UseVisualStyleBackColor = true;
            this.rbtnSum.CheckedChanged += new System.EventHandler(this.rbtnSum_CheckedChanged);
            // 
            // tbSum
            // 
            this.tbSum.Enabled = false;
            this.tbSum.Location = new System.Drawing.Point(203, 196);
            this.tbSum.Name = "tbSum";
            this.tbSum.Size = new System.Drawing.Size(140, 22);
            this.tbSum.TabIndex = 7;
            this.tbSum.Text = "0";
            this.tbSum.TextChanged += new System.EventHandler(this.tbSum_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(349, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "литров";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(349, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "тг.";
            // 
            // tbLiterAmount
            // 
            this.tbLiterAmount.Location = new System.Drawing.Point(203, 150);
            this.tbLiterAmount.MaxLength = 4;
            this.tbLiterAmount.Name = "tbLiterAmount";
            this.tbLiterAmount.Size = new System.Drawing.Size(140, 22);
            this.tbLiterAmount.TabIndex = 10;
            this.tbLiterAmount.Text = "0";
            this.tbLiterAmount.TextChanged += new System.EventHandler(this.tbLiterAmount_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lAutostationTotal);
            this.groupBox2.Location = new System.Drawing.Point(29, 264);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(391, 107);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "К оплате";
            // 
            // lAutostationTotal
            // 
            this.lAutostationTotal.AutoSize = true;
            this.lAutostationTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lAutostationTotal.Location = new System.Drawing.Point(46, 43);
            this.lAutostationTotal.Name = "lAutostationTotal";
            this.lAutostationTotal.Size = new System.Drawing.Size(29, 31);
            this.lAutostationTotal.TabIndex = 0;
            this.lAutostationTotal.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "тг.";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.tbColaValue);
            this.groupBox3.Controls.Add(this.tbFriesValue);
            this.groupBox3.Controls.Add(this.tbHamburgerValue);
            this.groupBox3.Controls.Add(this.tbHotDogValue);
            this.groupBox3.Controls.Add(this.tbCola);
            this.groupBox3.Controls.Add(this.tbFries);
            this.groupBox3.Controls.Add(this.tbHamburger);
            this.groupBox3.Controls.Add(this.tbHotDog);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.cbCola);
            this.groupBox3.Controls.Add(this.cbFries);
            this.groupBox3.Controls.Add(this.cbHamburger);
            this.groupBox3.Controls.Add(this.cbHotDog);
            this.groupBox3.Location = new System.Drawing.Point(491, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(521, 393);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Мини-Кафе";
            // 
            // cbHotDog
            // 
            this.cbHotDog.AutoSize = true;
            this.cbHotDog.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbHotDog.Location = new System.Drawing.Point(16, 56);
            this.cbHotDog.Name = "cbHotDog";
            this.cbHotDog.Size = new System.Drawing.Size(120, 33);
            this.cbHotDog.TabIndex = 0;
            this.cbHotDog.Text = "ХотДог";
            this.cbHotDog.UseVisualStyleBackColor = true;
            this.cbHotDog.CheckedChanged += new System.EventHandler(this.cbHotDog_CheckedChanged);
            // 
            // cbHamburger
            // 
            this.cbHamburger.AutoSize = true;
            this.cbHamburger.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbHamburger.Location = new System.Drawing.Point(16, 95);
            this.cbHamburger.Name = "cbHamburger";
            this.cbHamburger.Size = new System.Drawing.Size(160, 33);
            this.cbHamburger.TabIndex = 1;
            this.cbHamburger.Text = "Гамбургер";
            this.cbHamburger.UseVisualStyleBackColor = true;
            this.cbHamburger.CheckedChanged += new System.EventHandler(this.cbHamburger_CheckedChanged);
            // 
            // cbFries
            // 
            this.cbFries.AutoSize = true;
            this.cbFries.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbFries.Location = new System.Drawing.Point(16, 134);
            this.cbFries.Name = "cbFries";
            this.cbFries.Size = new System.Drawing.Size(223, 33);
            this.cbFries.TabIndex = 2;
            this.cbFries.Text = "Картофель фри";
            this.cbFries.UseVisualStyleBackColor = true;
            this.cbFries.CheckedChanged += new System.EventHandler(this.cbFries_CheckedChanged);
            // 
            // cbCola
            // 
            this.cbCola.AutoSize = true;
            this.cbCola.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbCola.Location = new System.Drawing.Point(16, 173);
            this.cbCola.Name = "cbCola";
            this.cbCola.Size = new System.Drawing.Size(160, 33);
            this.cbCola.TabIndex = 3;
            this.cbCola.Text = "Кока-Кола";
            this.cbCola.UseVisualStyleBackColor = true;
            this.cbCola.CheckedChanged += new System.EventHandler(this.cbCola_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(300, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Цена";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(397, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Количество";
            // 
            // tbHotDog
            // 
            this.tbHotDog.Enabled = false;
            this.tbHotDog.Location = new System.Drawing.Point(272, 65);
            this.tbHotDog.Name = "tbHotDog";
            this.tbHotDog.Size = new System.Drawing.Size(100, 22);
            this.tbHotDog.TabIndex = 6;
            this.tbHotDog.Text = "400";
            // 
            // tbHamburger
            // 
            this.tbHamburger.Enabled = false;
            this.tbHamburger.Location = new System.Drawing.Point(272, 104);
            this.tbHamburger.Name = "tbHamburger";
            this.tbHamburger.Size = new System.Drawing.Size(100, 22);
            this.tbHamburger.TabIndex = 7;
            this.tbHamburger.Text = "500";
            // 
            // tbFries
            // 
            this.tbFries.Enabled = false;
            this.tbFries.Location = new System.Drawing.Point(272, 143);
            this.tbFries.Name = "tbFries";
            this.tbFries.Size = new System.Drawing.Size(100, 22);
            this.tbFries.TabIndex = 8;
            this.tbFries.Text = "200";
            // 
            // tbCola
            // 
            this.tbCola.Enabled = false;
            this.tbCola.Location = new System.Drawing.Point(272, 182);
            this.tbCola.Name = "tbCola";
            this.tbCola.Size = new System.Drawing.Size(100, 22);
            this.tbCola.TabIndex = 9;
            this.tbCola.Text = "250";
            // 
            // tbHotDogValue
            // 
            this.tbHotDogValue.Enabled = false;
            this.tbHotDogValue.Location = new System.Drawing.Point(400, 65);
            this.tbHotDogValue.Name = "tbHotDogValue";
            this.tbHotDogValue.Size = new System.Drawing.Size(100, 22);
            this.tbHotDogValue.TabIndex = 10;
            this.tbHotDogValue.Text = "0";
            this.tbHotDogValue.TextChanged += new System.EventHandler(this.tbHotDogValue_TextChanged);
            // 
            // tbHamburgerValue
            // 
            this.tbHamburgerValue.Enabled = false;
            this.tbHamburgerValue.Location = new System.Drawing.Point(400, 104);
            this.tbHamburgerValue.Name = "tbHamburgerValue";
            this.tbHamburgerValue.Size = new System.Drawing.Size(100, 22);
            this.tbHamburgerValue.TabIndex = 11;
            this.tbHamburgerValue.Text = "0";
            this.tbHamburgerValue.TextChanged += new System.EventHandler(this.tbHotDogValue_TextChanged);
            // 
            // tbFriesValue
            // 
            this.tbFriesValue.Enabled = false;
            this.tbFriesValue.Location = new System.Drawing.Point(400, 143);
            this.tbFriesValue.Name = "tbFriesValue";
            this.tbFriesValue.Size = new System.Drawing.Size(100, 22);
            this.tbFriesValue.TabIndex = 12;
            this.tbFriesValue.Text = "0";
            this.tbFriesValue.TextChanged += new System.EventHandler(this.tbHotDogValue_TextChanged);
            // 
            // tbColaValue
            // 
            this.tbColaValue.Enabled = false;
            this.tbColaValue.Location = new System.Drawing.Point(400, 182);
            this.tbColaValue.Name = "tbColaValue";
            this.tbColaValue.Size = new System.Drawing.Size(100, 22);
            this.tbColaValue.TabIndex = 13;
            this.tbColaValue.Text = "0";
            this.tbColaValue.TextChanged += new System.EventHandler(this.tbHotDogValue_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.lKafeTotal);
            this.groupBox4.Location = new System.Drawing.Point(16, 264);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(484, 107);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "К оплате";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 16);
            this.label9.TabIndex = 12;
            this.label9.Text = "тг.";
            // 
            // lKafeTotal
            // 
            this.lKafeTotal.AutoSize = true;
            this.lKafeTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lKafeTotal.Location = new System.Drawing.Point(59, 41);
            this.lKafeTotal.Name = "lKafeTotal";
            this.lKafeTotal.Size = new System.Drawing.Size(29, 31);
            this.lKafeTotal.TabIndex = 0;
            this.lKafeTotal.Text = "0";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.lTotal);
            this.groupBox5.Controls.Add(this.btnPay);
            this.groupBox5.Controls.Add(this.panel2);
            this.groupBox5.Location = new System.Drawing.Point(12, 438);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1000, 203);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Всего к оплате";
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(34, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(120, 120);
            this.panel2.TabIndex = 0;
            // 
            // btnPay
            // 
            this.btnPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPay.Location = new System.Drawing.Point(202, 60);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(298, 120);
            this.btnPay.TabIndex = 1;
            this.btnPay.Text = "Оплатить";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(569, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 16);
            this.label11.TabIndex = 14;
            this.label11.Text = "тг.";
            // 
            // lTotal
            // 
            this.lTotal.AutoSize = true;
            this.lTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lTotal.Location = new System.Drawing.Point(609, 93);
            this.lTotal.Name = "lTotal";
            this.lTotal.Size = new System.Drawing.Size(43, 48);
            this.lTotal.TabIndex = 13;
            this.lTotal.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 669);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.MaximumSize = new System.Drawing.Size(1057, 716);
            this.MinimumSize = new System.Drawing.Size(1057, 716);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbOilValue;
        private System.Windows.Forms.ComboBox cbOilType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lAutostationTotal;
        private System.Windows.Forms.TextBox tbLiterAmount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbSum;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbtnSum;
        private System.Windows.Forms.RadioButton rbtnAmount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cbHotDog;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lKafeTotal;
        private System.Windows.Forms.TextBox tbColaValue;
        private System.Windows.Forms.TextBox tbFriesValue;
        private System.Windows.Forms.TextBox tbHamburgerValue;
        private System.Windows.Forms.TextBox tbHotDogValue;
        private System.Windows.Forms.TextBox tbCola;
        private System.Windows.Forms.TextBox tbFries;
        private System.Windows.Forms.TextBox tbHamburger;
        private System.Windows.Forms.TextBox tbHotDog;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox cbCola;
        private System.Windows.Forms.CheckBox cbFries;
        private System.Windows.Forms.CheckBox cbHamburger;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lTotal;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Panel panel2;
    }
}

