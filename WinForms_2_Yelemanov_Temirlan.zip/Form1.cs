﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winformsHW2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cbOilType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbOilType.SelectedIndex)
            {
                case 0: tbOilValue.Text = "205";break;
                case 1: tbOilValue.Text = "245";break;
                case 2: tbOilValue.Text = "280";break;
                case 3: tbOilValue.Text = "295";break;
                case 4: tbOilValue.Text = "70";break;
                default: tbOilValue.Text = "0"; break;
            }
        }

        private void rbtnAmount_CheckedChanged(object sender, EventArgs e)
        {
            tbLiterAmount.Enabled = rbtnAmount.Checked;
            tbLiterAmount.Text = "0";
        }

        private void rbtnSum_CheckedChanged(object sender, EventArgs e)
        {
            tbSum.Enabled = rbtnSum.Checked;
            tbSum.Text = "0";
        }

        private void tbLiterAmount_TextChanged(object sender, EventArgs e)
        {
            if (tbLiterAmount.Text.Length == 0)
            {
                lAutostationTotal.Text = "0";
                return;
            }
            lAutostationTotal.Text = (int.Parse(tbLiterAmount.Text) * int.Parse(tbOilValue.Text)).ToString();
            lTotal.Text = (int.Parse(lKafeTotal.Text) + int.Parse(lAutostationTotal.Text)).ToString();
        }

        private void tbSum_TextChanged(object sender, EventArgs e)
        {
            if(tbSum.Text.Length == 0)
            {
                lAutostationTotal.Text = "0";
                return;
            }
            tbLiterAmount.Text = (int.Parse(tbSum.Text)/int.Parse(tbOilValue.Text)).ToString();
            lAutostationTotal.Text = tbSum.Text;
            lTotal.Text = (int.Parse(lKafeTotal.Text) + int.Parse(lAutostationTotal.Text)).ToString();
        }

        private void cbHotDog_CheckedChanged(object sender, EventArgs e)
        {
            tbHotDogValue.Enabled = cbHotDog.Checked;
            tbHotDogValue.Text = "0";
        }

        private void cbHamburger_CheckedChanged(object sender, EventArgs e)
        {
            tbHamburgerValue.Enabled = cbHamburger.Checked;
            tbHamburgerValue.Text = "0";
        }

        private void cbFries_CheckedChanged(object sender, EventArgs e)
        {
            tbFriesValue.Enabled = cbFries.Checked;
            tbFriesValue.Text = "0";
        }

        private void cbCola_CheckedChanged(object sender, EventArgs e)
        {
            tbColaValue.Enabled = cbCola.Checked;
            tbColaValue.Text = "0";
        }

        private void tbHotDogValue_TextChanged(object sender, EventArgs e)
        {
            lKafeTotal.Text = (int.Parse(tbHotDog.Text == "" ? "0" : tbHotDog.Text) * int.Parse(tbHotDogValue.Text == "" ? "0" : tbHotDogValue.Text)+
            int.Parse(tbHamburger.Text == "" ? "0" : tbHamburger.Text) * int.Parse(tbHamburgerValue.Text == "" ? "0":tbHamburgerValue.Text)+
            int.Parse(tbFries.Text == "" ? "0" : tbFries.Text) * int.Parse(tbFriesValue.Text == "" ? "0" : tbFriesValue.Text)+
            int.Parse(tbCola.Text == "" ? "0" : tbCola.Text) * int.Parse(tbColaValue.Text == "" ? "0" :tbColaValue.Text)).ToString();
            lTotal.Text = (int.Parse(lKafeTotal.Text) + int.Parse(lAutostationTotal.Text)).ToString();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Сумма к оплате = " + lTotal.Text, "Оплачено!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            cbOilType.SelectedIndex = 5;
            tbLiterAmount.Text = "0";
            tbSum.Text = "0";
            lAutostationTotal.Text = "0";
            lTotal.Text = "0";
            cbHotDog.Checked = false;
            cbHamburger.Checked = false;
            cbFries.Checked = false;
            cbCola.Checked = false;
        }
    }
}
