#pragma once
using namespace std;

template<typename T>
void fillArr(T arr[], int length, int min = -100, int max = 100) {
	for (size_t i = 0; i < length; i++)
	{
		arr[i] = min + rand() % (max - min + 1);
	}
}

template<typename T>
void printArr(T arr[], int length, int width = 3) {
	for (size_t i = 0; i < length; i++)
	{
		cout << setw(width) << arr[i];
	}
	cout << endl;
}

//1)** �������� ����������� �����������, ��������� ������ �����������.

void problem1() {
	double a, b;
	double* pa = &a, * pb = &b;
	bool isOn = true;
	while (isOn) {
		cout << "type first num = \n";
		cin >> *pa;
		cout << "type second num = \n";
		cin >> *pb;
		cout << "choose action: 1(+) 2(-) 3(*) 4(/) or 5 to exit\n";
		short action;
		cin >> action;
		switch (action) {
		case 1: cout << "output = " << *pa + *pb << endl;
			break;
		case 2: cout << "output = " << *pa - *pb << endl;
			break;
		case 3: cout << "output = " << *pa * *pb << endl;
			break;
		case 4: cout << "output = " << *pa / *pb << endl;
			break;
		case 5: isOn = false;
			break;
		default: cout << "unknown input\n";
			break;
		}
	}
}