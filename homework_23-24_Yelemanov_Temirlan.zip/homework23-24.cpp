﻿#include <iostream>
#include <random>
#include <algorithm>
#include <stdlib.h>
#include <iomanip>
#include <chrono>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
#include "problem7.h"
using namespace std;

int main()
{
  srand(time(NULL));
  //problem1();
  //problem2();
  //problem3();
  
  //доп задания 
  //problem4();
  //problem5();
  //problem6();
  problem7();
  cout << "\nend! . . . . . . . . . . .  . . . . . . \n";
}