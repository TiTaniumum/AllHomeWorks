﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace winforms8
{
    public partial class FormBus : Form
    {
        BusSchedule busSchedule;
        public FormBus()
        {
            InitializeComponent();
            busSchedule = new BusSchedule();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string name = textBoxBusName.Text;
            string type = textBoxBusType.Text;
            string destination = textBoxDestination.Text;
            DateTime departure = dateTimePickerDeparture.Value;
            DateTime arrival = dateTimePickerArrival.Value;
            Bus bus = new Bus(name, type, destination, departure, arrival);
            busSchedule.buss.Add(bus);
            labelBusCount.Text = "Count: " + busSchedule.buss.Count;
            textBoxBusName.Text = string.Empty;
            textBoxBusType.Text = string.Empty;
            textBoxDestination.Text = string.Empty;
            dateTimePickerDeparture.Value = DateTime.Now;
            dateTimePickerArrival.Value = DateTime.Now;
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (textBoxFileName.Text == string.Empty) return;
            try
            {
                BusSchedule.Serialize(textBoxFileName.Text + ".xml", busSchedule);
                textBoxFileName.Text = string.Empty;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonNewSchedule_Click(object sender, EventArgs e)
        {
            busSchedule = new BusSchedule();
            labelBusCount.Text = "Count: " + busSchedule.buss.Count;
        }
    }
}
