﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;
using System.Xml.Serialization;

namespace winforms8
{
    [Serializable]
    public class Bus
    {
        public string name { get; set; }
        public string type { get; set; }
        public string destination{ get; set; }
        public DateTime departure{get;set;}
        public DateTime arrival { get; set; }
        public Bus() {
            name = string.Empty;
            type = string.Empty;
            destination = string.Empty;
            departure = DateTime.MinValue;
            arrival = DateTime.MinValue;
        }
        public Bus(string name, string type, string destination, DateTime departure, DateTime arrival)
        {
            this.name=name;
            this.type=type;
            this.destination=destination;
            this.departure=departure;
            this.arrival=arrival;
        }
        public override string ToString()
        {
            return $"BusNumber: {name}; BusType: {type}; Destination: {destination}; DepartureDate: {departure}; ArrivalDate: {arrival}";
        }
    }
    [Serializable]
    public class BusSchedule
    {
        public List<Bus> buss;
        public BusSchedule()
        {
            buss = new List<Bus>();
        }

        public static void Serialize(string fileName, BusSchedule bs)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BusSchedule));
            using (TextWriter textWriter = new StreamWriter(fileName))
            {
                serializer.Serialize(textWriter, bs);
            }
        }

        public static BusSchedule Deserialize(string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BusSchedule));
            using (TextReader reader = new StreamReader(fileName))
            {
                return (BusSchedule)serializer.Deserialize(reader);
            }
        }
    }
}
