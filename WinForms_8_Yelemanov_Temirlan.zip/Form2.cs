﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winforms8
{
    public partial class Form2 : Form
    {
        public string fileName;
        private BusSchedule bs;
        public Form2()
        {
            InitializeComponent();
        }

        public void InitSchedule(string filename)
        {
            fileName = filename;
            bs = BusSchedule.Deserialize(fileName);
            foreach (var item in bs.buss)
            {
                listViewSchedule.Items.Add(item.ToString());
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            listViewResult.Items.Clear();
            foreach(var item in bs.buss)
            {
                if(item.destination == textBoxDestination.Text &&  item.arrival <= dateTimePickerArrival.Value)
                {
                    listViewResult.Items.Add(item.ToString());
                }
            }
        }
    }
}
