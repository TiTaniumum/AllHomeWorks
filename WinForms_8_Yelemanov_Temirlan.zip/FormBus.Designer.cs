﻿namespace winforms8
{
    partial class FormBus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxBusName = new System.Windows.Forms.TextBox();
            this.textBoxBusType = new System.Windows.Forms.TextBox();
            this.textBoxDestination = new System.Windows.Forms.TextBox();
            this.dateTimePickerDeparture = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerArrival = new System.Windows.Forms.DateTimePicker();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxFileName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.labelBusCount = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonNewSchedule = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxBusName
            // 
            this.textBoxBusName.Location = new System.Drawing.Point(25, 30);
            this.textBoxBusName.Name = "textBoxBusName";
            this.textBoxBusName.Size = new System.Drawing.Size(260, 22);
            this.textBoxBusName.TabIndex = 0;
            // 
            // textBoxBusType
            // 
            this.textBoxBusType.Location = new System.Drawing.Point(25, 92);
            this.textBoxBusType.Name = "textBoxBusType";
            this.textBoxBusType.Size = new System.Drawing.Size(260, 22);
            this.textBoxBusType.TabIndex = 1;
            // 
            // textBoxDestination
            // 
            this.textBoxDestination.Location = new System.Drawing.Point(25, 153);
            this.textBoxDestination.Name = "textBoxDestination";
            this.textBoxDestination.Size = new System.Drawing.Size(260, 22);
            this.textBoxDestination.TabIndex = 2;
            // 
            // dateTimePickerDeparture
            // 
            this.dateTimePickerDeparture.Location = new System.Drawing.Point(25, 217);
            this.dateTimePickerDeparture.Name = "dateTimePickerDeparture";
            this.dateTimePickerDeparture.Size = new System.Drawing.Size(260, 22);
            this.dateTimePickerDeparture.TabIndex = 3;
            // 
            // dateTimePickerArrival
            // 
            this.dateTimePickerArrival.Location = new System.Drawing.Point(25, 299);
            this.dateTimePickerArrival.Name = "dateTimePickerArrival";
            this.dateTimePickerArrival.Size = new System.Drawing.Size(260, 22);
            this.dateTimePickerArrival.TabIndex = 4;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(25, 367);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(260, 44);
            this.buttonAdd.TabIndex = 5;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Bus Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Bus Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Destination";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Date of departure";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Date of arrival";
            // 
            // textBoxFileName
            // 
            this.textBoxFileName.Location = new System.Drawing.Point(488, 30);
            this.textBoxFileName.Name = "textBoxFileName";
            this.textBoxFileName.Size = new System.Drawing.Size(285, 22);
            this.textBoxFileName.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(485, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "FileName";
            // 
            // labelBusCount
            // 
            this.labelBusCount.AutoSize = true;
            this.labelBusCount.Location = new System.Drawing.Point(291, 381);
            this.labelBusCount.Name = "labelBusCount";
            this.labelBusCount.Size = new System.Drawing.Size(54, 16);
            this.labelBusCount.TabIndex = 13;
            this.labelBusCount.Text = "Count: 0";
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(488, 73);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(285, 41);
            this.buttonSave.TabIndex = 14;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonNewSchedule
            // 
            this.buttonNewSchedule.Location = new System.Drawing.Point(488, 367);
            this.buttonNewSchedule.Name = "buttonNewSchedule";
            this.buttonNewSchedule.Size = new System.Drawing.Size(285, 44);
            this.buttonNewSchedule.TabIndex = 15;
            this.buttonNewSchedule.Text = "New bus Schedule";
            this.buttonNewSchedule.UseVisualStyleBackColor = true;
            this.buttonNewSchedule.Click += new System.EventHandler(this.buttonNewSchedule_Click);
            // 
            // FormBus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonNewSchedule);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.labelBusCount);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxFileName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.dateTimePickerArrival);
            this.Controls.Add(this.dateTimePickerDeparture);
            this.Controls.Add(this.textBoxDestination);
            this.Controls.Add(this.textBoxBusType);
            this.Controls.Add(this.textBoxBusName);
            this.Name = "FormBus";
            this.Text = "FormBus";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxBusName;
        private System.Windows.Forms.TextBox textBoxBusType;
        private System.Windows.Forms.TextBox textBoxDestination;
        private System.Windows.Forms.DateTimePicker dateTimePickerDeparture;
        private System.Windows.Forms.DateTimePicker dateTimePickerArrival;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxFileName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelBusCount;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonNewSchedule;
    }
}