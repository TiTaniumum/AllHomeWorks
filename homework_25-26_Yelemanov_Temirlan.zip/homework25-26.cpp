﻿#include <iostream>
#include <random>
#include <algorithm>
#include <stdlib.h>
#include <iomanip>
#include <chrono>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
using namespace std;

int main()
{
  srand(time(NULL));
  //problem1();
  //problem2();
  //problem3();
  problem4();
  cout << "\nend!  . . . . . . . . . . . . . . .\n";
}