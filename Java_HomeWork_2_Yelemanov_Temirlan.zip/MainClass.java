import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MainClass{
    public static Scanner scanner = new Scanner(System.in);
    public static void main(String[] str){
        
    }
    public static void Task1(){
        System.out.println("\"Your time is limited,\n\tso don't waste it\n\t\tliving someone else's life\"\n\t\t\tSteve Jobs");
    }
    public static void Task2(){
        float number = getInt();
        float percent = getInt();
        percent = percent/100;
        Print(""+(number*percent));
    }
    public static void Task3(){
        int n1 = getInt();
        int n2 = getInt();
        int n3 = getInt();
        Print(""+n1+n2+n3);
    }
    public static void Task4(){
        String number = getStr();
        if(number.length() != 6){
            Print("number is not 6 digits");
            return;
        }
        String[] arr = number.split("");
        Print(arr[5]+arr[4]+arr[2]+arr[3]+arr[1]+arr[0]);
    }
    public static void Task5(){
        int month = getInt();
        if(month==1 || month==2 || month == 12){
            Print("Winter");
        }else if(month >=3 && month <= 5){
            Print("Spring");
        }else if(month >=6 && month <=8){
            Print("Summer");
        }else if(month >=9 &&  month <=11){
            Print("Autumn");
        }else{
            Print("Error");
        }
    }
    public static void Task6(){
        int meters = getInt();
        Print("1: Miles, 2:Inch, 3:Yard");
        int mode = getInt();
        switch (mode) {
            case 1:
                Print("Miles "+ (meters*0.000621371));
                break;
            case 2:
                Print("Inches "+ (meters*39.3701));
                break;  
            case 3:
                Print("Yards "+(meters*1.09361));
                break;
            default:
                Print("Wrong mode");
                return;
        }
    }
    public static void Task7(){
        int left = getInt();
        int right = getInt();
        if(left > right) {
            int temp = left;
            left = right;
            right = temp;
        }
        for(int i = left; i< right; i++){
            Print(""+i);
        }
    }
    public static void Task8(){
        int left = getInt();
        int right = getInt();
        if(left > right) {
            int temp = left;
            left = right;
            right = temp;
        }
        for(int i = left; i<= right;i++){
            String multiplications = "";
            for(int j = 1; j<=10; j++){
                multiplications += i+"*"+j+"="+(i*j)+" ";
            }
            Print(multiplications);
        }
    }
    public static void Task9(){
        int length = 100;
        int[]arr = new int[length];
        for(int i = 0; i< length; i++){
            arr[i] = random(-10000, 10000);
        }
        int negatives = 0;
        int positives = 0;
        int zeroes = 0;
        for(int i = 0; i< length; i++){
            if(arr[i]<0)
                negatives++;
            else if(arr[i]>0)
                positives++;
            else 
                zeroes++;
        }
        Print("negatives: " + negatives+" | positives: "+ positives+" | zeroes: " + zeroes);
    }
    public static void Task10(){
        int length = 100;
        int[]arr = new int[length];
        for(int i = 0; i< length; i++){
            arr[i] = random(-10000, 10000);
        }
        List<Integer> negative = new ArrayList<Integer>();
        List<Integer> positive = new ArrayList<Integer>();
        List<Integer> even = new ArrayList<Integer>();
        List<Integer> odd = new ArrayList<Integer>();
        for(int i = 0; i< length; i++){
            if(arr[i]%2 == 0)
                even.add(arr[i]);
            else
                odd.add(arr[i]);
            if(arr[i] <0)
                negative.add(arr[i]);
            else 
                positive.add(arr[i]);
        }
        Print(negative.toString());
        Print(positive.toString());
        Print(odd.toString());
        Print(even.toString());
    }
    public static void Task11(int length, int dir, char symbol){
        if(dir == 0){
            String str = "";
            for(int i = 0; i < length; i++){
                str+= symbol;
            }
            Print(str);
        }else {
            for(int i = 0; i < length; i++){
                Print(""+symbol);
            }   
        }
    }
    public static void Task12(){
        int length = 100;
        int[]arr = new int[length];
        for(int i = 0; i< length; i++){
            arr[i] = random(-10000, 10000);
        }
        Arrays.sort(arr);
        Print(arr.toString());
    }
    public static int random(int min,int max){
        return (int)(Math.random()*(max - min)+min);
    }
    public static String getStr(){
        return scanner.nextLine();
    }
    public static int getInt(){
        return Integer.parseInt(scanner.nextLine());
    }
    public static void Print(String str){
        System.out.println(str);
    }
}