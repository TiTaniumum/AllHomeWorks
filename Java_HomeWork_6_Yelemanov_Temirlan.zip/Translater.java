import java.util.HashMap;
import java.util.Map;

public class Translater {
    private HashMap<String, String> map;
    private HashMap<String, Integer> keyCounter;
    private HashMap<String, Integer> valueCounter;

    public Translater(){
        this.map = new HashMap<>();
        this.keyCounter = new HashMap<>();
        this.valueCounter = new HashMap<>();
    }
    public Translater(HashMap<String,String> map){
        this.map = map;
        this.keyCounter = new HashMap<>();
        this.valueCounter = new HashMap<>();
        for(Map.Entry<String,String> entry: map.entrySet()){
            keyCounter.put(entry.getKey(), 0);
            valueCounter.put(entry.getValue(), 0);
        }
    }
    public Translater put(String key, String value){
        map.put(key, value);
        return this;
    }
    public Translater remove(String key){
        map.remove(key);
        return this;
    }
    public String translateKey(String key){
        if(map.get(key) != null){
            keyCounter.put(key, keyCounter.get(key)+1);
        }
        return map.get(key);
    }
    public String translateValue(String value){
        for(Map.Entry<String,String> entry: map.entrySet()){
            if(entry.getValue().equals(value)){
                valueCounter.put(value, valueCounter.get(value)+1);
                return entry.getValue();
            }
        }
        return null;
    }
    public String mostPopular(){
        int max = keyCounter.get(keyCounter.keySet().toArray()[0]);
        String word = (String)keyCounter.keySet().toArray()[0];
        for(Map.Entry<String,Integer> entry : keyCounter.entrySet()){
            if(max < entry.getValue()){
                max = entry.getValue();
                word = entry.getKey();
            }
        }
        for(Map.Entry<String,Integer> entry : keyCounter.entrySet()){
            if(max < entry.getValue()){
                max = entry.getValue();
                word = entry.getKey();
            }
        }
        return word;
    }
    public String leastPopular(){
        int min = keyCounter.get(keyCounter.keySet().toArray()[0]);
        String word = (String)keyCounter.keySet().toArray()[0];
        for(Map.Entry<String,Integer> entry : keyCounter.entrySet()){
            if(min > entry.getValue()){
                min = entry.getValue();
                word = entry.getKey();
            }
        }
        for(Map.Entry<String,Integer> entry : keyCounter.entrySet()){
            if(min > entry.getValue()){
                min = entry.getValue();
                word = entry.getKey();
            }
        }
        return word;
    }
}
