public class Fine {
    private int amount;
    private String reason;
    private FineType fineType;
    private Long cityCode;
    public Fine(int amount, String reason, FineType fineType, Long cityCode){
        this.amount = amount;
        this.reason = reason;
        this.fineType = fineType;
        this.cityCode = cityCode;
    }
    public int getAmount() {
        return amount;
    }
    public String getReason() {
        return reason;
    }
    public Long getCityCode() {
        return cityCode;
    }
    public FineType getFineType() {
        return fineType;
    }
    @Override
    public String toString() {
        return "{Amount: " + amount + " Reason: " + reason + " Fine type: " + fineType + " City code: " + cityCode + "}";
    }
    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Fine)){
            return false;
        }
        Fine fine = (Fine)obj;
        return fine.getAmount() == amount && fine.getReason().equals(reason) && fine.getFineType() == fineType && fine.getCityCode() == cityCode;
    }
}