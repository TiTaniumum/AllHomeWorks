public enum FineType {
    crime,
    administrative,
    low,
    pinapplepizza,
}
