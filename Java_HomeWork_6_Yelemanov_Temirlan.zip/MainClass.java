import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

public class MainClass{
    public static void main(String[] args) {
        Task3();
    }
    public static void Task2(){
        HashMap<String, String> map = new HashMap<>();
        map.put("hello", "привет");
        map.put("world", "мир");
        map.put("map", "карта");
        Translater translater = new Translater(map);
        translater.translateKey("map");
        translater.translateKey("map");
        System.out.println(translater.translateKey("hello"));
        System.out.println(translater.mostPopular());
        System.out.println(translater.leastPopular());
    }
    public static void Task3(){
        HashMap<Long, ArrayList<Fine>> map = new HashMap<>();
        map.put(281107857727l, new ArrayList<>());
        map.put(150384946180l, new ArrayList<>());
        map.put(658182163293l, new ArrayList<>());

        FineList list = new FineList(map);
        list.addFine(281107857727l, new Fine(100, "Walked on red light", FineType.low, 0l))
            .addFine(281107857727l,new Fine(1000, "Drived on red light", FineType.low, 1l))
            .addFine(150384946180l,new Fine(222, "Publicly farted",FineType.pinapplepizza,0l))
            .addFine(150384946180l,new Fine(-69, "Lost virginity",FineType.crime, 69l))
            .addFine(658182163293l,new Fine(99999, "Didn't do home works for a lot of days",FineType.crime, 1l));
        System.out.println(list.getFineListByFineType(FineType.crime).toString());
        System.out.println(list.getFineListByCityCode(0l));
    }
}