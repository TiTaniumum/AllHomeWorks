import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FineList {
    public HashMap<Long, ArrayList<Fine>> map;
    
    public FineList(HashMap<Long, ArrayList<Fine>> map){
        this.map = map;
    }

    public FineList addFine(Long personID, Fine fine){
        map.get(personID).add(fine);
        return this;
    }

    @Override
    public String toString() {
        return map.toString();
    }

    public ArrayList<Fine> getFines(Long personID){
        return map.get(personID);
    }

    public ArrayList<Fine> getFineListByFineType(FineType fineType){
        ArrayList<Fine> list = new ArrayList<Fine>();
        for(Map.Entry<Long, ArrayList<Fine>> entry : map.entrySet()){
            ArrayList<Fine> temp = entry.getValue();
            for(Fine fine : temp){
                if(fine.getFineType() == fineType){
                    list.add(fine);
                }
            }
        }
        return list;
    }
    public ArrayList<Fine> getFineListByCityCode(Long cityCode){
        ArrayList<Fine> list = new ArrayList<Fine>();
        for(Map.Entry<Long, ArrayList<Fine>> entry : map.entrySet()){
            ArrayList<Fine> temp = entry.getValue();
            for(Fine fine : temp){
                if(fine.getCityCode() == cityCode){
                    list.add(fine);
                }
            }
        }
        return list;
    }
    public FineList removeFine(Long personID, Fine fine){
        map.get(personID).remove(fine);
        return this;
    }
}
