﻿using System;



namespace csharp10
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            PairGame pg = new PairGame();   
            pg.Start();
        }
    }
}