﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonTools;
using CommonTools.ConsoleShortCuts;
using static CommonTools.ConsoleShortCuts.C;
using static System.Console;
using System.Runtime.Serialization;
using System.Reflection.Metadata;

namespace csharp10
{
    partial class PairGame
    {
        private List<(int i, int j)> tempActivations;

        private delegate void Activation();

        private Activation activation;

        private (int j, int i) beforeEnter;
        private void AddActive()
        {
            if(tempActivations.Count == 0 || tempActivations.Count == 1)
            {
                (int x, int y) = beforeEnter;
                if (active[y][x/2]) return;
                tempActivations.Add((y, x/2));
                active[y][x/2] = true;
                SetCursorPosition(x, y);
                Print();
            }
        }

        private void Message()
        {
            if (tempActivations.Count==2)
            {
                if (tempActivations[0] == tempActivations[1])
                {
                    active[tempActivations[0].i][tempActivations[0].j] = false;
                    active[tempActivations[1].i][tempActivations[1].j] = false;
                    tempActivations.Clear();
                    (int x, int y) = GetCursorPosition();
                    ConsoleColor old = BackgroundColor;
                    ConsoleColor old1 = ForegroundColor;
                    BackgroundColor = ConsoleColor.Black;
                    ForegroundColor = ConsoleColor.White;
                    SetCursorPosition(10, 10);
                    Out("Don't choose the same cell!");
                    BackgroundColor = old;
                    ForegroundColor = old1;
                    SetCursorPosition(x, y);
                    return;
                }
                if(pairs[tempActivations[0].i][tempActivations[0].j] == pairs[tempActivations[1].i][tempActivations[1].j])
                {
                    tempActivations.Clear();
                }
                else
                {
                    Print();
                    active[tempActivations[0].i][tempActivations[0].j] = false;
                    active[tempActivations[1].i][tempActivations[1].j] = false;
                    tempActivations.Clear();
                    (int x,int y) = GetCursorPosition();
                    ConsoleColor old = BackgroundColor;
                    ConsoleColor old1 = ForegroundColor;
                    BackgroundColor = ConsoleColor.Black;
                    BackgroundColor = ConsoleColor.White;
                    SetCursorPosition(10,10);
                    Out("Don't match!");
                    BackgroundColor = old;
                    BackgroundColor = old1;
                    SetCursorPosition(x, y);
                }
            }
        }
    }
}
