﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using CommonTools;
using CommonTools.ConsoleShortCuts;
using static CommonTools.ConsoleShortCuts.C;
using static System.Console;
using Microsoft.VisualBasic;
using System.Drawing;
using System.Runtime.InteropServices;

namespace csharp10
{
    partial class PairGame
    {
        private char[][] pairs;
        private bool[][] active;
        bool isExit = false;
        private bool IsGameOver
        {
            get
            {
                for (int i = 0; i < active.Length; i++)
                {
                    for (int j = 0; j < active[i].Length; j++)
                    {
                        if (!active[i][j]) return false;
                    }
                }
                return true;
            }
        }
        public PairGame()
        {
            Init();
        }
        private void Init()
        {
            pairs = new char[6][];
            active = new bool[6][];
            for (int i = 0; i < pairs.Length; i++)
            {
                pairs[i] = new char[6];
                active[i] = new bool[6];
            }
            Fill();
            Shuffle();
            tempActivations = new List<(int i, int j)>();
            activation += AddActive;
            activation += Message;
        }
        private void Fill()
        {
            char ch = ' ';
            for (int i = 0, cnt = 0; i < pairs.Length; i++)
            {
                for (int j = 0; j < pairs.Length; j++)
                {
                    if (cnt++%2==0)
                    {
                        ch = (char)Alg.RAND('A', 'Z');
                    }
                    pairs[i][j] = ch;
                }
            }
        }
        private void Shuffle()
        {
            int y1, x1;
            int y2, x2;
            for (int i = 0; i < 5*5*10; i++)
            {
                y1 = Alg.RAND(0, pairs.Length-1);
                x1 = Alg.RAND(0, pairs[y1].Length-1);
                y2 = Alg.RAND(0, pairs.Length-1);
                x2 = Alg.RAND(0, pairs[y2].Length-1);
                Alg.Swap(ref pairs[y1][x1], ref pairs[y2][x2]);
            }
        }
        private void Print()
        {
            (int x, int y) = GetCursorPosition();
            ConsoleColor old = BackgroundColor;
            ConsoleColor old1 = ForegroundColor;
            BackgroundColor = ConsoleColor.Black;
            ForegroundColor = ConsoleColor.White;
            Clear();
            SetCursorPosition(0, 0);
            for (int i = 0; i < pairs.Length; i++)
            {
                for (int j = 0; j < pairs.Length; j++)
                {
                    if ((y, x/2) == (i, j))
                    {
                        BackgroundColor = ConsoleColor.Green;
                        ForegroundColor = ConsoleColor.Black;
                        Out(GetCharByPos(i, j));
                        BackgroundColor = ConsoleColor.Black;
                        ForegroundColor = ConsoleColor.White;
                        Out(" ");
                    }
                    else
                    {
                        Out(GetCharByPos(i, j)+" ");
                    }
                }
                OutLine("");
            }
            SetCursorPosition(x, y);
            BackgroundColor = old;
            ForegroundColor = old1;
        }
        private char GetCharByPos(int i, int j)
        {
            if (active[i][j]) return pairs[i][j];
            else return '*';
        }
        private void Action(ConsoleKey key)
        {
            (int x, int y) = GetCursorPosition();
            char ch1 = GetCharByPos(y, x/2);
            switch (key)
            {
                case ConsoleKey.UpArrow:
                    {
                        if (y == 0) return;
                        BackgroundColor = ConsoleColor.Black;
                        ForegroundColor = ConsoleColor.White;
                        Out(ch1);
                        char ch2 = GetCharByPos(y-1, x/2);
                        SetCursorPosition(x, y-1);
                        BackgroundColor = ConsoleColor.Green;
                        ForegroundColor = ConsoleColor.Black;
                        Out(ch2);
                        SetCursorPosition(x, y-1);
                    }
                    break;
                case ConsoleKey.DownArrow:
                    {
                        if (y >= pairs.Length-1) return;
                        BackgroundColor = ConsoleColor.Black;
                        ForegroundColor = ConsoleColor.White;
                        Out(ch1);
                        char ch2 = GetCharByPos(y+1, x/2);
                        SetCursorPosition(x, y+1);
                        BackgroundColor = ConsoleColor.Green;
                        ForegroundColor = ConsoleColor.Black;
                        Out(ch2);
                        SetCursorPosition(x, y+1);
                    }
                    break;
                case ConsoleKey.LeftArrow:
                    {
                        if (x/2 == 0) return;
                        BackgroundColor= ConsoleColor.Black;
                        ForegroundColor = ConsoleColor.White;
                        Out(ch1);
                        char ch2 = GetCharByPos(y, x/2-1);
                        SetCursorPosition(x-2, y);
                        BackgroundColor = ConsoleColor.Green;
                        ForegroundColor = ConsoleColor.Black;
                        Out(ch2);
                        SetCursorPosition(x-2, y);
                    }
                    break;
                case ConsoleKey.RightArrow:
                    {
                        if (x/2>=pairs[0].Length-1) return;
                        BackgroundColor= ConsoleColor.Black;
                        ForegroundColor= ConsoleColor.White;
                        Out(ch1);
                        char ch2 = GetCharByPos(y, x/2+1);
                        SetCursorPosition(x+2, y);
                        BackgroundColor = ConsoleColor.Green;
                        ForegroundColor = ConsoleColor.Black;
                        Out(ch2);
                        SetCursorPosition(x+2, y);
                    }
                    break;
                case ConsoleKey.Enter:
                    activation.Invoke();
                    break;
                case ConsoleKey.Escape:
                    isExit = true;
                    break;
                default: break;
            }
        }
        public void Start()
        {
            OutLine("Управление: движение - стрелочками, Enter - выбор.");
            ReadLine();
            CursorVisible = false;
            SetCursorPosition(0, 0);
            Print();
            while (!IsGameOver)
            {
                if (Console.KeyAvailable)
                {
                    Print();
                    beforeEnter = GetCursorPosition();
                    ConsoleKey key = Console.ReadKey().Key;
                    Action(key);
                }
                if (isExit) break;
            }
            BackgroundColor = ConsoleColor.Black;
            ForegroundColor = ConsoleColor.White;
            Clear();
            SetCursorPosition(0, 0);
            Out("YOU WIN!");
            ReadLine();
        }
    }
}
