public class Baz {

    private int count;

    public Baz(int count){
        this.count = count;
    }

    public void Print(Thread thread){
        System.out.println(thread.getName()+": [count: "+ count++ +"]");
    }    
}
