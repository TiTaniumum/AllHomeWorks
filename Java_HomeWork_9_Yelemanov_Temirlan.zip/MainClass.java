import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class MainClass{
    public static void main(String[] args){
        //SemaphoreDemo();
        ExecutorServiceDemo();
    }

    public static void SemaphoreDemo(){
        // Only One Thread can work with the object

        Semaphore semaphore = new Semaphore(1);
        new Foo(semaphore).start();
        new Foo(semaphore).start();
        new Foo(semaphore).start();
        new Foo(semaphore).start();
        new Foo(semaphore).start();
        new Foo(semaphore).start();
    }

    public static void ExecutorServiceDemo(){
        ExecutorService executor = Executors.newFixedThreadPool(10);

        Baz baz = new Baz(0);

        Runnable task = ()->{
            try{
                System.out.println("Runnable is being executed ");
                baz.Print(Thread.currentThread());
                TimeUnit.MICROSECONDS.sleep(300);
            }
            catch(Exception ex){ ex.printStackTrace();} 
        };

        Callable<String> callableTask  = () ->{
           TimeUnit.MICROSECONDS.sleep(300);
           baz.Print(Thread.currentThread());
           return "Callable done by : " + Thread.currentThread().getName();
        };

        List<Callable<String>> callableTasks = List.of(
            callableTask,
            callableTask,
            callableTask,
            callableTask,
            callableTask
        );


        System.out.println("Execute-------------------------");
        //execute demo. execute is void type
        executor.execute(task);

        System.out.println("Submit-------------------------");
        //submit dem. returns Future. Future awaits of task ending.
        Future<String> future =  executor.submit(callableTask);
        try{
            String str = future.get();
            System.out.println(str);
        }catch(InterruptedException ex){ex.printStackTrace();} catch (ExecutionException e) { e.printStackTrace();}

        System.out.println("Invoke any-------------------------");
        
        try{
            String str = executor.invokeAny(callableTasks);
            System.out.println(str);
        }catch(InterruptedException ex){ex.printStackTrace();} catch (ExecutionException e) { e.printStackTrace();}

        System.out.println("Invoke all-------------------------");

        try{
            List<Future<String>> futures = executor.invokeAll(callableTasks);

            for(Future<String> item : futures){
                System.out.println(item.get());
            }
        }catch(InterruptedException ex){ex.printStackTrace();} catch (ExecutionException e) { e.printStackTrace();}


        System.out.println("ShutDown-------------------------");

        try{
            List<Future<String>> futures = executor.invokeAll(callableTasks);
            executor.shutdown();
            if (!executor.awaitTermination(800, TimeUnit.MILLISECONDS)) {
                executor.shutdownNow();
            } 
        }catch(InterruptedException ex){
            ex.printStackTrace();
            executor.shutdownNow();
        }

        executor.close();
        
    }
}