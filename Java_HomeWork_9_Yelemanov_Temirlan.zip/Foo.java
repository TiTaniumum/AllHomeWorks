import java.util.concurrent.Semaphore;

public class Foo extends Thread {
    public static Baz baz = new Baz(0);
    public static Semaphore sem;

    public Foo(Semaphore sem){
        this.sem = sem;
    }

    @Override
    public void run(){
        try{
            sem.acquire();
            baz.Print(this);
            sleep(300);
            sem.release();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
