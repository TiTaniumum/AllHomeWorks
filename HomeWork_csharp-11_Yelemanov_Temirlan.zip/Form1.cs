using System.Diagnostics;

namespace csharp12Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();  
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string mainPath = comboBox1.SelectedItem.ToString();
            if (Directory.Exists(mainPath))
            {
                string[] paths = Directory.GetDirectories(mainPath);
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                foreach (string path in paths)
                {
                    listBox1.Items.Add(path);
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string mainPath = listBox1.SelectedItem.ToString();
            listBox2.Items.Clear();
            if (Directory.Exists(mainPath))
            {
                string[] paths = Directory.GetDirectories(mainPath);
                string[] files = Directory.GetFiles(mainPath);
                foreach (string path in paths)
                {
                    listBox2.Items.Add(path);
                }
                foreach (string file in files)
                {
                    listBox2.Items.Add(file);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string mainPath = listBox1.SelectedItem.ToString();
            listBox2.Items.Clear();
            if (Directory.Exists(mainPath))
            {
                string[] paths = Directory.GetDirectories(mainPath);
                string[] files = Directory.GetFiles(mainPath);
                var folders = paths.Where(name => name.Contains(textBox1.Text));
                var neededFiles = files.Where(file => file.Contains(textBox1.Text));
                foreach (string path in folders)
                {
                    listBox2.Items.Add(path);
                }
                foreach (string file in neededFiles)
                {
                    listBox2.Items.Add(file);
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> strings = new List<string>();
            foreach (string path in listBox2.Items)
            {
                strings.Add(path);
            }
            strings.Sort();
            string str = comboBox2.SelectedItem.ToString();
            listBox2.Items.Clear();
            if (str == "Z-A")
            {
                for (int i = strings.Count - 1; i >= 0; i--)
                {
                    listBox2.Items.Add(strings[i]);
                }
            }
            else
            {
                foreach (string item in strings)
                {
                    listBox2.Items.Add(item);
                }
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fileName = listBox2.SelectedItem.ToString();
            ProcessStartInfo ps = new ProcessStartInfo();
            ps.FileName = "cmd.exe";
            ps.WindowStyle = ProcessWindowStyle.Hidden;
            ps.Arguments = $"/c {fileName}";
            Process.Start(ps);
        }
    }
}