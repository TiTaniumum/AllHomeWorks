#pragma once
#include <iostream>
#include <string>
#include <windows.h>
using namespace std;
struct LC { LC() { srand(time(NULL)); } ~LC() { cout << "\nEND . . ..  . . ..  .. . \n"; cin.get(); } }_;
#define RAND(min, max) min+rand()%(max-(min)+1)

/*
������� 1
��������� ������� �������������� ������������, ������������ ����� "����������, ��������� � �������".
*/

void SetPos(int Row, int Col)
{
  COORD cd;
  cd.X = Col;
  cd.Y = Row;
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cd);
}

class Circle {
protected:
  double R;
public:
  Circle():R(){}
  Circle(double r) :R(r) {}
  double hypotenuse(double a, double b) {
    //double temp1 = pow(a,2);
    //double temp2 = pow(b,2);
    //cout << temp1 << " " << temp2 << " ";
    //double h = sqrt( temp1+temp2);
    //cout << h << endl;
    //return h;
    return sqrt(pow(a, 2) + pow(b, 2));
  }
  bool isInCircle(int i, int j) {
    double a, b;
    a = abs(R - i);
    b = abs(R - j);
    //cout << a << " " << b << endl;
    if (hypotenuse(a, b) <= R) return true;
    else return false;
  }
  void virtual Print() {
    for (size_t i = 0; i <= R*2; i++)
    {
      for (size_t j = 0; j <= R*2; j++)
      {
        if (isInCircle(i, j))cout << "**";
        else cout << "  ";
      }
      cout << '\n';
    }
  }
};

class Square {
protected:
  double side;
public:
  Square() :side() {}
  Square(double Side):side(Side){}
  void virtual Print() {
    for (size_t i = 0; i <= side; i++)
    {
      if (i == 0 || i == side) {
        for (size_t j = 0; j <= side; j++)
        {
          SetPos(i, j*2);
          cout << "##";
        }
      }
      else {
        SetPos(i, 0);
        cout << "##";
        SetPos(i, side*2);
        cout << "##";
      }
    }
  }
};

class CircleSquare : public virtual Circle, public virtual Square {
  public:
    CircleSquare(double r) : Circle(r), Square(r*2){}
    void virtual Print() {
      Circle::Print();
      Square::Print();
    }
};

void problem1() {
  /*Circle A(10);
  A.Print();
  Square B(20);
  B.Print();*/
  CircleSquare C(10);
  C.Print();
}