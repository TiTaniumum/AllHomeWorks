﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winforms6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            Cursor.Position = new Point(this.Left + StartPosition.Location.X+StartPosition.Size.Width/2, this.Top+ 30 + StartPosition.Location.Y + StartPosition.Size.Height/2);
        }

        private void panel37_MouseEnter(object sender, EventArgs e)
        {
            MessageBox.Show("You Win!", "You Win!", MessageBoxButtons.OK);
            Cursor.Position = new Point(this.Left + StartPosition.Location.X+StartPosition.Size.Width/2, this.Top+ 30 + StartPosition.Location.Y + StartPosition.Size.Height/2);
        }
    }
}
