﻿namespace winforms6
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.StartPosition = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Location = new System.Drawing.Point(109, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(13, 350);
            this.panel1.TabIndex = 0;
            this.panel1.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // StartPosition
            // 
            this.StartPosition.BackColor = System.Drawing.Color.Green;
            this.StartPosition.Location = new System.Drawing.Point(23, 21);
            this.StartPosition.Name = "StartPosition";
            this.StartPosition.Size = new System.Drawing.Size(49, 43);
            this.StartPosition.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Location = new System.Drawing.Point(109, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(658, 15);
            this.panel2.TabIndex = 2;
            this.panel2.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel3.Location = new System.Drawing.Point(109, 406);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(658, 17);
            this.panel3.TabIndex = 3;
            this.panel3.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel4.Location = new System.Drawing.Point(749, 73);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(18, 298);
            this.panel4.TabIndex = 4;
            this.panel4.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel5.Location = new System.Drawing.Point(162, 21);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(14, 96);
            this.panel5.TabIndex = 5;
            this.panel5.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel6.Location = new System.Drawing.Point(109, 147);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(183, 18);
            this.panel6.TabIndex = 5;
            this.panel6.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel7.Location = new System.Drawing.Point(234, 75);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(20, 72);
            this.panel7.TabIndex = 6;
            this.panel7.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel8.Location = new System.Drawing.Point(324, 38);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(23, 229);
            this.panel8.TabIndex = 7;
            this.panel8.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel9.Location = new System.Drawing.Point(162, 188);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(163, 13);
            this.panel9.TabIndex = 0;
            this.panel9.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel10.Location = new System.Drawing.Point(150, 237);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(12, 107);
            this.panel10.TabIndex = 8;
            this.panel10.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel11.Location = new System.Drawing.Point(163, 240);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(128, 26);
            this.panel11.TabIndex = 9;
            this.panel11.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel12.Location = new System.Drawing.Point(187, 297);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(159, 25);
            this.panel12.TabIndex = 10;
            this.panel12.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel13.Location = new System.Drawing.Point(346, 146);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(53, 13);
            this.panel13.TabIndex = 11;
            this.panel13.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel14.Location = new System.Drawing.Point(381, 158);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(22, 162);
            this.panel14.TabIndex = 12;
            this.panel14.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel15.Location = new System.Drawing.Point(324, 321);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(18, 53);
            this.panel15.TabIndex = 13;
            this.panel15.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel16.Location = new System.Drawing.Point(121, 370);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(124, 12);
            this.panel16.TabIndex = 14;
            this.panel16.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel17.Location = new System.Drawing.Point(274, 348);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(50, 22);
            this.panel17.TabIndex = 15;
            this.panel17.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel18.Location = new System.Drawing.Point(364, 354);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(34, 52);
            this.panel18.TabIndex = 16;
            this.panel18.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel19.Location = new System.Drawing.Point(424, 327);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(325, 27);
            this.panel19.TabIndex = 17;
            this.panel19.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel20.Location = new System.Drawing.Point(433, 370);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(21, 36);
            this.panel20.TabIndex = 18;
            this.panel20.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel21.Location = new System.Drawing.Point(482, 354);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(14, 26);
            this.panel21.TabIndex = 19;
            this.panel21.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel22.Location = new System.Drawing.Point(515, 378);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(12, 28);
            this.panel22.TabIndex = 20;
            this.panel22.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel23.Location = new System.Drawing.Point(539, 354);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(14, 29);
            this.panel23.TabIndex = 21;
            this.panel23.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel24.Location = new System.Drawing.Point(575, 377);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(13, 28);
            this.panel24.TabIndex = 22;
            this.panel24.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel25.Location = new System.Drawing.Point(604, 365);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(21, 28);
            this.panel25.TabIndex = 23;
            this.panel25.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel26.Location = new System.Drawing.Point(636, 354);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(25, 22);
            this.panel26.TabIndex = 24;
            this.panel26.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel27.Location = new System.Drawing.Point(636, 387);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(24, 19);
            this.panel27.TabIndex = 25;
            this.panel27.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel28.Location = new System.Drawing.Point(673, 371);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(8, 21);
            this.panel28.TabIndex = 26;
            this.panel28.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel29.Location = new System.Drawing.Point(703, 386);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(10, 20);
            this.panel29.TabIndex = 27;
            this.panel29.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel30.Location = new System.Drawing.Point(712, 354);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(15, 23);
            this.panel30.TabIndex = 28;
            this.panel30.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel31.Location = new System.Drawing.Point(726, 389);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(16, 17);
            this.panel31.TabIndex = 29;
            this.panel31.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel32.Location = new System.Drawing.Point(402, 267);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(298, 19);
            this.panel32.TabIndex = 30;
            this.panel32.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel33.Location = new System.Drawing.Point(428, 212);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(320, 25);
            this.panel33.TabIndex = 31;
            this.panel33.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel34.Location = new System.Drawing.Point(402, 147);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(297, 25);
            this.panel34.TabIndex = 32;
            this.panel34.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel35.Location = new System.Drawing.Point(415, 76);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(334, 31);
            this.panel35.TabIndex = 33;
            this.panel35.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel36.Location = new System.Drawing.Point(372, 63);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(25, 53);
            this.panel36.TabIndex = 34;
            this.panel36.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel37.Location = new System.Drawing.Point(747, 38);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(41, 36);
            this.panel37.TabIndex = 35;
            this.panel37.MouseEnter += new System.EventHandler(this.panel37_MouseEnter);
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel38.Location = new System.Drawing.Point(749, 371);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(41, 36);
            this.panel38.TabIndex = 36;
            this.panel38.MouseEnter += new System.EventHandler(this.panel37_MouseEnter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel38);
            this.Controls.Add(this.panel37);
            this.Controls.Add(this.panel36);
            this.Controls.Add(this.panel35);
            this.Controls.Add(this.panel34);
            this.Controls.Add(this.panel33);
            this.Controls.Add(this.panel32);
            this.Controls.Add(this.panel31);
            this.Controls.Add(this.panel30);
            this.Controls.Add(this.panel29);
            this.Controls.Add(this.panel28);
            this.Controls.Add(this.panel27);
            this.Controls.Add(this.panel26);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.StartPosition);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel StartPosition;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
    }
}

