﻿namespace Sys3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbLog = new System.Windows.Forms.TextBox();
            this.tbEnd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbStart = new System.Windows.Forms.TextBox();
            this.buttonStart = new System.Windows.Forms.Button();
            this.tbFibStart = new System.Windows.Forms.TextBox();
            this.tbFibEnd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonStartFibonacci = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbLog
            // 
            this.tbLog.Location = new System.Drawing.Point(12, 56);
            this.tbLog.Multiline = true;
            this.tbLog.Name = "tbLog";
            this.tbLog.ReadOnly = true;
            this.tbLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbLog.Size = new System.Drawing.Size(900, 382);
            this.tbLog.TabIndex = 0;
            // 
            // tbEnd
            // 
            this.tbEnd.Location = new System.Drawing.Point(171, 28);
            this.tbEnd.Name = "tbEnd";
            this.tbEnd.Size = new System.Drawing.Size(154, 22);
            this.tbEnd.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "начало простых чисел:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(174, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "конец простых чисел:";
            // 
            // tbStart
            // 
            this.tbStart.Location = new System.Drawing.Point(12, 28);
            this.tbStart.Name = "tbStart";
            this.tbStart.Size = new System.Drawing.Size(153, 22);
            this.tbStart.TabIndex = 5;
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(331, 27);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(92, 23);
            this.buttonStart.TabIndex = 6;
            this.buttonStart.Text = "Start Prime";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // tbFibStart
            // 
            this.tbFibStart.Location = new System.Drawing.Point(470, 28);
            this.tbFibStart.Name = "tbFibStart";
            this.tbFibStart.Size = new System.Drawing.Size(152, 22);
            this.tbFibStart.TabIndex = 7;
            // 
            // tbFibEnd
            // 
            this.tbFibEnd.Location = new System.Drawing.Point(637, 28);
            this.tbFibEnd.Name = "tbFibEnd";
            this.tbFibEnd.Size = new System.Drawing.Size(151, 22);
            this.tbFibEnd.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(467, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "начало Фибоначчи:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(634, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "конец Фибоначчи:";
            // 
            // buttonStartFibonacci
            // 
            this.buttonStartFibonacci.Location = new System.Drawing.Point(794, 27);
            this.buttonStartFibonacci.Name = "buttonStartFibonacci";
            this.buttonStartFibonacci.Size = new System.Drawing.Size(118, 23);
            this.buttonStartFibonacci.TabIndex = 11;
            this.buttonStartFibonacci.Text = "Start Fibonacci";
            this.buttonStartFibonacci.UseVisualStyleBackColor = true;
            this.buttonStartFibonacci.Click += new System.EventHandler(this.buttonStartFibonacci_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(923, 450);
            this.Controls.Add(this.buttonStartFibonacci);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbFibEnd);
            this.Controls.Add(this.tbFibStart);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.tbStart);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbEnd);
            this.Controls.Add(this.tbLog);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbLog;
        private System.Windows.Forms.TextBox tbEnd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbStart;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.TextBox tbFibStart;
        private System.Windows.Forms.TextBox tbFibEnd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonStartFibonacci;
    }
}

