﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

//Домашнее задание
//Тема: Потоки.Синхронизация потоков


//Обязательные задания

//Задание 1
//Создайте оконное приложение, генерирующее набор простых чисел в диапазоне, указанном пользователем.
//Если не указана нижняя граница, поток с стартует с 2.
//Если не указана верхняя граница, генерирование происходит до завершения приложения.
//Используйте механизм потоков. Числа должны отображаться в оконном интерфейсе.

//Задание 2
//Добавьте к первому заданию поток, генерирующий набор чисел Фибоначчи.
//Числа должны отображаться в оконном интерфейсе.

namespace Sys3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public bool isClosing = false;
        public ThreadParam threadParam;
        private void buttonStart_Click(object sender, EventArgs e)
        {
            int start = 1, end = int.MaxValue;
            if (tbStart.Text != string.Empty && !int.TryParse(tbStart.Text, out start))
            {
                tbStart.Focus();
                tbStart.SelectAll();
                MessageBox.Show("wrong input! type number.");
                return;
            }
            if (tbEnd.Text != string.Empty && !int.TryParse(tbEnd.Text, out end))
            {
                tbEnd.Focus();
                tbEnd.SelectAll();
                MessageBox.Show("wrong input! type number.");
                return;
            }
            tbLog.Text= string.Empty;
            ThreadParam threadParam = new ThreadParam() { start = start, end = end, form = this };
            this.threadParam = threadParam;
            Thread thread1 = new Thread(ThreadCulc);
            buttonStart.Enabled = false;
            thread1.IsBackground = true;
            thread1.Start(threadParam);
        }

        private void ThreadCulc(object parameters)
        {
            ThreadParam param = parameters as ThreadParam;
            Form1 form = param.form as Form1;
            param.thread = Thread.CurrentThread;
            for (int i = param.start; i < param.end; i++)
            {
                if (isPrime(i))
                {
                    if (form.isClosing) break;
                    form.Invoke(new Action(() =>
                    {
                        form.tbLog.Text += i.ToString()+" || ";
                    }));
                }
            }
            form.Invoke(new Action(() =>
            {
                form.buttonStart.Enabled = true;
            }));
            if (form.isClosing)
                form.Invoke(new Action(() =>
                {
                    form.Close();
                }));
            form.threadParam = null;
        }

        static bool isPrime(int number)
        {
            if (number == 1) return false;
            if (number == 2 || number == 3 || number == 5) return true;
            if (number % 2 == 0 || number % 3 == 0 || number % 5 == 0) return false;

            var boundary = (int)Math.Floor(Math.Sqrt(number));

            int i = 6;

            while (i <= boundary)
            {
                if (number % (i + 1) == 0 || number % (i + 5) == 0)
                    return false;

                i += 6;
            }

            return true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadParam?.thread != null)
                if (isClosing)
                {
                    e.Cancel = false;
                }
                else
                {
                    isClosing = true;
                    e.Cancel = true;
                }
        }

        private void buttonStartFibonacci_Click(object sender, EventArgs e)
        {
            int start = 1, end = int.MaxValue;
            if (tbFibStart.Text != string.Empty && !int.TryParse(tbFibStart.Text, out start))
            {
                tbFibStart.Focus();
                tbFibStart.SelectAll();
                MessageBox.Show("wrong input! type number.");
                return;
            }
            if (tbFibEnd.Text != string.Empty && !int.TryParse(tbFibEnd.Text, out end))
            {
                tbFibEnd.Focus();
                tbFibEnd.SelectAll();
                MessageBox.Show("wrong input! type number.");
                return;
            }
            Form2 form2 = new Form2();
            form2.Owner = this;
            form2.Show();
            ThreadParam threadParam = new ThreadParam() { start = start, end = end, form = form2 };
            form2.threadParam = threadParam;
            Thread thread1 = new Thread(ThreadCalcFibonacci);
            thread1.IsBackground = true;
            thread1.Start(threadParam);
        }
        public void ThreadCalcFibonacci(object parameter)
        {
            ThreadParam param = parameter as ThreadParam;
            Form2 form = param.form as Form2;
            param.thread = Thread.CurrentThread;
            int old = param.start, cur = param.start;
            if(cur < param.end)
            form.Invoke(new Action(() =>
            {
                form.Log(cur.ToString());
            }));
            for (int i = cur; i< param.end; i+=old, old = cur, cur = i)
            {
                if (form.isClosing) break;
                if (int.MaxValue - old < i) break;
                form.Invoke(new Action(() =>
                {
                    form.Log(i.ToString());
                }));
            }
            if (form.isClosing) form.Invoke(new Action(()=>{ form.Close(); }));
            form.threadParam = null;
        }
    }
    public class ThreadParam
    {
        public int start = 1, end = int.MaxValue;
        public Form form;
        public Thread thread;
    }

}
