﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sys3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public ThreadParam threadParam = null;
        public bool isClosing = false;

        public void Log(string message)
        {
            textBoxMain.Text += message + "\r\n";
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadParam?.thread != null)
                if (isClosing)
                {
                    e.Cancel = false;
                }
                else
                {
                    isClosing = true;
                    e.Cancel = true;
                }
        }
    }
}
