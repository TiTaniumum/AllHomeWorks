﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Компьютер\HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
//Компьютер\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
//"D:\Compleete programms\Открытка\Открытка.exe"

namespace Sys8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitList();
        }
        //public string Path = "Компьютер\\HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";
        public string Path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";
        RegistryKey key;
        private void InitList()
        {
            key = Registry.CurrentUser.OpenSubKey(Path);
            string[] valueNames = key.GetValueNames();
            //textBoxLog.Text += valueNames.Length +"\r\n";
            foreach (string item in valueNames)
            {
                //textBoxLog.Text += item+"\r\n";
                ListViewItem i = listViewMain.Items.Add(item);
                string valueType;
                string value = ValueKeyToString(key, item, out valueType);
                i.SubItems.Add(valueType);
                i.SubItems.Add(value);
            }
        }
        string ValueKeyToString(RegistryKey key, string valueName, out string typeName)
        {
            RegistryValueKind type = key.GetValueKind(valueName);
            object value = key.GetValue(valueName);
            string result = "unknown";
            typeName = "unknown type";
            switch (type)
            {
                case RegistryValueKind.String:
                    typeName = "REG_SZ";
                    result = value as string;
                    break;
                case RegistryValueKind.ExpandString:
                    typeName = "REG_EXPAND_SZ";
                    result = valueName as string;
                    break;
                case RegistryValueKind.MultiString:
                    string[] temp = value as string[];
                    result = "";
                    foreach (var t in temp)
                    {
                        result += t+";";
                    }
                    typeName = "REG_MULTI_SZ";
                    break;
                case RegistryValueKind.DWord:
                    typeName = "REG_DWORD";
                    result = ((int)value).ToString();
                    break;
                case RegistryValueKind.QWord:
                    typeName = "REG_QWORD";
                    result = ((long)value).ToString();
                    break;
                case RegistryValueKind.Binary:
                    typeName = "REG_BIRARY";
                    byte[] btemp = value as byte[];
                    result = "";
                    foreach (byte b in btemp)
                    {
                        result += b.ToString("X2") + " ";
                    }
                    break;
            }
            return result;
        }
        //у меня не получается удалить значение из ключа, не знаю почему.
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            try
            {
                List<ListViewItem> forDeletion = new List<ListViewItem>();
                for (int i = 0; i < listViewMain.SelectedItems.Count; i++)
                {
                    textBoxLog.Text +="Deleting: " + listViewMain.SelectedItems[i].Text +"\r\n";
                    key.DeleteValue(listViewMain.SelectedItems[i].Text,false);
                    forDeletion.Add(listViewMain.SelectedItems[i]);
                }
                foreach (ListViewItem item in forDeletion)
                {
                    listViewMain.Items.Remove(item);
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string name = textBoxName.Text;
            string type = "REG_SZ";
            string value = textBoxPath.Text;
            if (isExists(name, value))
            {
                //key.SetValue(name, value);
                Registry.SetValue(key.Name, name, value);
                updateItem(name, value);
            }
            else
            {
                Registry.SetValue(key.Name, name, value);
                //key.SetValue(name, value);
                ListViewItem i = listViewMain.Items.Add(name);
                i.SubItems.Add(type);
                i.SubItems.Add(value);
            }
        }
        private bool isExists(string name, string value)
        {
            for (int i = 0; i < listViewMain.Items.Count; i++)
            {
                if (listViewMain.Items[i].Text == name && listViewMain.Items[i].SubItems[2].Text == value) return true;
            }
            return false;
        }
        private void updateItem(string name, string value)
        {
            for (int i = 0; i < listViewMain.Items.Count; i++)
            {
                if (listViewMain.Items[i].Text == name)
                {
                    listViewMain.Items[i].SubItems[2].Text = value;
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            key?.Close();
        }
    }
}
