﻿namespace winforms3
{
    partial class frmGame
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnStatTotal = new System.Windows.Forms.Panel();
            this.pnStatCur = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnGame = new System.Windows.Forms.Panel();
            this.pnPole22 = new System.Windows.Forms.Panel();
            this.pnPole21 = new System.Windows.Forms.Panel();
            this.pnPole20 = new System.Windows.Forms.Panel();
            this.pnPole12 = new System.Windows.Forms.Panel();
            this.pnPole11 = new System.Windows.Forms.Panel();
            this.pnPole10 = new System.Windows.Forms.Panel();
            this.pnPole02 = new System.Windows.Forms.Panel();
            this.pnPole01 = new System.Windows.Forms.Panel();
            this.pnPole00 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.mMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miNewGame = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.miSaveGame = new System.Windows.Forms.ToolStripMenuItem();
            this.miLoadGame = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.miExit = new System.Windows.Forms.ToolStripMenuItem();
            this.окноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.свернутьВТрейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.развернутьНаВесьЭкранToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.первымиХодятXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.первымиХодятОToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miFont = new System.Windows.Forms.ToolStripMenuItem();
            this.miColor = new System.Windows.Forms.ToolStripMenuItem();
            this.статистикаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stMainBar = new System.Windows.Forms.StatusStrip();
            this.stStepXO = new System.Windows.Forms.ToolStripStatusLabel();
            this.stTimeProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.stCurTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tmCurTime = new System.Windows.Forms.Timer(this.components);
            this.tmGameTimer = new System.Windows.Forms.Timer(this.components);
            this.fdFont = new System.Windows.Forms.FontDialog();
            this.lXCount = new System.Windows.Forms.Label();
            this.lOCount = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnStatCur.SuspendLayout();
            this.pnGame.SuspendLayout();
            this.mMain.SuspendLayout();
            this.stMainBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pnGame);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1099, 508);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.pnStatTotal);
            this.panel3.Controls.Add(this.pnStatCur);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(635, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(464, 508);
            this.panel3.TabIndex = 1;
            // 
            // pnStatTotal
            // 
            this.pnStatTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnStatTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnStatTotal.Location = new System.Drawing.Point(0, 245);
            this.pnStatTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnStatTotal.Name = "pnStatTotal";
            this.pnStatTotal.Size = new System.Drawing.Size(460, 259);
            this.pnStatTotal.TabIndex = 1;
            // 
            // pnStatCur
            // 
            this.pnStatCur.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnStatCur.Controls.Add(this.lOCount);
            this.pnStatCur.Controls.Add(this.lXCount);
            this.pnStatCur.Controls.Add(this.label1);
            this.pnStatCur.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnStatCur.Location = new System.Drawing.Point(0, 0);
            this.pnStatCur.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnStatCur.Name = "pnStatCur";
            this.pnStatCur.Size = new System.Drawing.Size(460, 245);
            this.pnStatCur.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 0;
            // 
            // pnGame
            // 
            this.pnGame.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnGame.Controls.Add(this.pnPole22);
            this.pnGame.Controls.Add(this.pnPole21);
            this.pnGame.Controls.Add(this.pnPole20);
            this.pnGame.Controls.Add(this.pnPole12);
            this.pnGame.Controls.Add(this.pnPole11);
            this.pnGame.Controls.Add(this.pnPole10);
            this.pnGame.Controls.Add(this.pnPole02);
            this.pnGame.Controls.Add(this.pnPole01);
            this.pnGame.Controls.Add(this.pnPole00);
            this.pnGame.Controls.Add(this.panel6);
            this.pnGame.Controls.Add(this.panel5);
            this.pnGame.Controls.Add(this.panel4);
            this.pnGame.Controls.Add(this.panel2);
            this.pnGame.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnGame.Location = new System.Drawing.Point(0, 0);
            this.pnGame.Margin = new System.Windows.Forms.Padding(0);
            this.pnGame.Name = "pnGame";
            this.pnGame.Size = new System.Drawing.Size(635, 508);
            this.pnGame.TabIndex = 0;
            // 
            // pnPole22
            // 
            this.pnPole22.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole22.Location = new System.Drawing.Point(419, 338);
            this.pnPole22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole22.Name = "pnPole22";
            this.pnPole22.Size = new System.Drawing.Size(137, 118);
            this.pnPole22.TabIndex = 12;
            this.pnPole22.Tag = "2;2;0";
            this.pnPole22.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole22.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole21
            // 
            this.pnPole21.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole21.Location = new System.Drawing.Point(252, 338);
            this.pnPole21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole21.Name = "pnPole21";
            this.pnPole21.Size = new System.Drawing.Size(137, 118);
            this.pnPole21.TabIndex = 11;
            this.pnPole21.Tag = "2;1;0";
            this.pnPole21.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole21.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole20
            // 
            this.pnPole20.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole20.Location = new System.Drawing.Point(84, 336);
            this.pnPole20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole20.Name = "pnPole20";
            this.pnPole20.Size = new System.Drawing.Size(137, 118);
            this.pnPole20.TabIndex = 10;
            this.pnPole20.Tag = "2;0;0";
            this.pnPole20.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole20.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole12
            // 
            this.pnPole12.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole12.Location = new System.Drawing.Point(419, 191);
            this.pnPole12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole12.Name = "pnPole12";
            this.pnPole12.Size = new System.Drawing.Size(137, 118);
            this.pnPole12.TabIndex = 9;
            this.pnPole12.Tag = "1;2;0";
            this.pnPole12.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole12.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole11
            // 
            this.pnPole11.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole11.Location = new System.Drawing.Point(252, 191);
            this.pnPole11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole11.Name = "pnPole11";
            this.pnPole11.Size = new System.Drawing.Size(137, 118);
            this.pnPole11.TabIndex = 8;
            this.pnPole11.Tag = "1;1;0";
            this.pnPole11.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole11.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole10
            // 
            this.pnPole10.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole10.Location = new System.Drawing.Point(84, 191);
            this.pnPole10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole10.Name = "pnPole10";
            this.pnPole10.Size = new System.Drawing.Size(137, 118);
            this.pnPole10.TabIndex = 7;
            this.pnPole10.Tag = "1;0;0";
            this.pnPole10.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole10.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole02
            // 
            this.pnPole02.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole02.Location = new System.Drawing.Point(419, 41);
            this.pnPole02.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole02.Name = "pnPole02";
            this.pnPole02.Size = new System.Drawing.Size(137, 118);
            this.pnPole02.TabIndex = 6;
            this.pnPole02.Tag = "0;2;0";
            this.pnPole02.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole02.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole01
            // 
            this.pnPole01.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole01.Location = new System.Drawing.Point(251, 41);
            this.pnPole01.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole01.Name = "pnPole01";
            this.pnPole01.Size = new System.Drawing.Size(137, 118);
            this.pnPole01.TabIndex = 5;
            this.pnPole01.Tag = "0;1;0";
            this.pnPole01.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole01.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // pnPole00
            // 
            this.pnPole00.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnPole00.Location = new System.Drawing.Point(84, 41);
            this.pnPole00.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnPole00.Name = "pnPole00";
            this.pnPole00.Size = new System.Drawing.Size(137, 118);
            this.pnPole00.TabIndex = 4;
            this.pnPole00.Tag = "0;0;0";
            this.pnPole00.Click += new System.EventHandler(this.pnPole00_Click);
            this.pnPole00.Paint += new System.Windows.Forms.PaintEventHandler(this.pnPole00_Paint);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel6.Location = new System.Drawing.Point(397, 41);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(13, 416);
            this.panel6.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel5.Location = new System.Drawing.Point(229, 41);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(13, 416);
            this.panel5.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Location = new System.Drawing.Point(84, 316);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(472, 12);
            this.panel4.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(84, 166);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(472, 12);
            this.panel2.TabIndex = 0;
            // 
            // mMain
            // 
            this.mMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.окноToolStripMenuItem,
            this.настройкиToolStripMenuItem,
            this.статистикаToolStripMenuItem,
            this.помощьToolStripMenuItem});
            this.mMain.Location = new System.Drawing.Point(0, 0);
            this.mMain.Name = "mMain";
            this.mMain.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.mMain.Size = new System.Drawing.Size(1099, 28);
            this.mMain.TabIndex = 1;
            this.mMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miNewGame,
            this.toolStripMenuItem1,
            this.miSaveGame,
            this.miLoadGame,
            this.toolStripMenuItem2,
            this.miExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 26);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // miNewGame
            // 
            this.miNewGame.Name = "miNewGame";
            this.miNewGame.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.miNewGame.Size = new System.Drawing.Size(278, 26);
            this.miNewGame.Text = "&Начать новую игру";
            this.miNewGame.ToolTipText = "При нажатии начинается новая игра.\r\nСтарая игра потеряется.";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(275, 6);
            // 
            // miSaveGame
            // 
            this.miSaveGame.Name = "miSaveGame";
            this.miSaveGame.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.miSaveGame.Size = new System.Drawing.Size(278, 26);
            this.miSaveGame.Text = "&Сохранить игру";
            // 
            // miLoadGame
            // 
            this.miLoadGame.Name = "miLoadGame";
            this.miLoadGame.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.miLoadGame.Size = new System.Drawing.Size(278, 26);
            this.miLoadGame.Text = "&Загрузить игру";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(275, 6);
            // 
            // miExit
            // 
            this.miExit.Name = "miExit";
            this.miExit.Size = new System.Drawing.Size(278, 26);
            this.miExit.Text = "&Выход";
            // 
            // окноToolStripMenuItem
            // 
            this.окноToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.свернутьВТрейToolStripMenuItem,
            this.развернутьНаВесьЭкранToolStripMenuItem});
            this.окноToolStripMenuItem.Name = "окноToolStripMenuItem";
            this.окноToolStripMenuItem.Size = new System.Drawing.Size(59, 26);
            this.окноToolStripMenuItem.Text = "Окно";
            // 
            // свернутьВТрейToolStripMenuItem
            // 
            this.свернутьВТрейToolStripMenuItem.Checked = true;
            this.свернутьВТрейToolStripMenuItem.CheckOnClick = true;
            this.свернутьВТрейToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.свернутьВТрейToolStripMenuItem.Name = "свернутьВТрейToolStripMenuItem";
            this.свернутьВТрейToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.свернутьВТрейToolStripMenuItem.Text = "Скрывать при сворачивании";
            // 
            // развернутьНаВесьЭкранToolStripMenuItem
            // 
            this.развернутьНаВесьЭкранToolStripMenuItem.Name = "развернутьНаВесьЭкранToolStripMenuItem";
            this.развернутьНаВесьЭкранToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.развернутьНаВесьЭкранToolStripMenuItem.Text = "Развернуть на весь экран";
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.первымиХодятXToolStripMenuItem,
            this.первымиХодятОToolStripMenuItem,
            this.miFont,
            this.miColor});
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(98, 26);
            this.настройкиToolStripMenuItem.Text = "Настройки";
            // 
            // первымиХодятXToolStripMenuItem
            // 
            this.первымиХодятXToolStripMenuItem.Checked = true;
            this.первымиХодятXToolStripMenuItem.CheckOnClick = true;
            this.первымиХодятXToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.первымиХодятXToolStripMenuItem.Name = "первымиХодятXToolStripMenuItem";
            this.первымиХодятXToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.первымиХодятXToolStripMenuItem.Text = "Первыми ходят X";
            // 
            // первымиХодятОToolStripMenuItem
            // 
            this.первымиХодятОToolStripMenuItem.CheckOnClick = true;
            this.первымиХодятОToolStripMenuItem.Name = "первымиХодятОToolStripMenuItem";
            this.первымиХодятОToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.первымиХодятОToolStripMenuItem.Text = "Первыми ходят О";
            // 
            // miFont
            // 
            this.miFont.Name = "miFont";
            this.miFont.Size = new System.Drawing.Size(224, 26);
            this.miFont.Text = "Font";
            this.miFont.Click += new System.EventHandler(this.miFont_Click);
            // 
            // miColor
            // 
            this.miColor.Name = "miColor";
            this.miColor.Size = new System.Drawing.Size(224, 26);
            this.miColor.Text = "Color";
            this.miColor.Click += new System.EventHandler(this.miColor_Click);
            // 
            // статистикаToolStripMenuItem
            // 
            this.статистикаToolStripMenuItem.Name = "статистикаToolStripMenuItem";
            this.статистикаToolStripMenuItem.Size = new System.Drawing.Size(98, 26);
            this.статистикаToolStripMenuItem.Text = "Статистика";
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(83, 26);
            this.помощьToolStripMenuItem.Text = "Помощь";
            // 
            // stMainBar
            // 
            this.stMainBar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.stMainBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stStepXO,
            this.stTimeProgress,
            this.stCurTime});
            this.stMainBar.Location = new System.Drawing.Point(0, 536);
            this.stMainBar.Name = "stMainBar";
            this.stMainBar.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.stMainBar.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.stMainBar.Size = new System.Drawing.Size(1099, 26);
            this.stMainBar.TabIndex = 2;
            this.stMainBar.Text = "statusStrip1";
            // 
            // stStepXO
            // 
            this.stStepXO.Name = "stStepXO";
            this.stStepXO.Size = new System.Drawing.Size(18, 20);
            this.stStepXO.Text = "X";
            this.stStepXO.ToolTipText = "Ход текущего игрока";
            // 
            // stTimeProgress
            // 
            this.stTimeProgress.Name = "stTimeProgress";
            this.stTimeProgress.Size = new System.Drawing.Size(200, 18);
            this.stTimeProgress.Step = 1;
            // 
            // stCurTime
            // 
            this.stCurTime.Name = "stCurTime";
            this.stCurTime.Size = new System.Drawing.Size(859, 20);
            this.stCurTime.Spring = true;
            this.stCurTime.Text = "00:00:00";
            this.stCurTime.ToolTipText = "CurrentTime";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // tmCurTime
            // 
            this.tmCurTime.Enabled = true;
            this.tmCurTime.Tick += new System.EventHandler(this.tmCurTime_Tick);
            // 
            // tmGameTimer
            // 
            this.tmGameTimer.Enabled = true;
            this.tmGameTimer.Tick += new System.EventHandler(this.tmGameTimer_Tick);
            // 
            // fdFont
            // 
            this.fdFont.ShowApply = true;
            this.fdFont.ShowColor = true;
            this.fdFont.ShowHelp = true;
            this.fdFont.Apply += new System.EventHandler(this.fdFont_Apply);
            // 
            // lXCount
            // 
            this.lXCount.AutoSize = true;
            this.lXCount.Location = new System.Drawing.Point(23, 101);
            this.lXCount.Name = "lXCount";
            this.lXCount.Size = new System.Drawing.Size(28, 16);
            this.lXCount.TabIndex = 1;
            this.lXCount.Text = "X: 0";
            // 
            // lOCount
            // 
            this.lOCount.AutoSize = true;
            this.lOCount.Location = new System.Drawing.Point(23, 140);
            this.lOCount.Name = "lOCount";
            this.lOCount.Size = new System.Drawing.Size(30, 16);
            this.lOCount.TabIndex = 2;
            this.lOCount.Text = "O: 0";
            // 
            // frmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1099, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mMain);
            this.Controls.Add(this.stMainBar);
            this.MainMenuStrip = this.mMain;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmGame";
            this.Text = "XO";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.pnStatCur.ResumeLayout(false);
            this.pnStatCur.PerformLayout();
            this.pnGame.ResumeLayout(false);
            this.mMain.ResumeLayout(false);
            this.mMain.PerformLayout();
            this.stMainBar.ResumeLayout(false);
            this.stMainBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnStatTotal;
        private System.Windows.Forms.Panel pnStatCur;
        private System.Windows.Forms.Panel pnGame;
        private System.Windows.Forms.MenuStrip mMain;
        private System.Windows.Forms.StatusStrip stMainBar;
        private System.Windows.Forms.Panel pnPole22;
        private System.Windows.Forms.Panel pnPole21;
        private System.Windows.Forms.Panel pnPole20;
        private System.Windows.Forms.Panel pnPole12;
        private System.Windows.Forms.Panel pnPole11;
        private System.Windows.Forms.Panel pnPole10;
        private System.Windows.Forms.Panel pnPole02;
        private System.Windows.Forms.Panel pnPole01;
        private System.Windows.Forms.Panel pnPole00;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miNewGame;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem miSaveGame;
        private System.Windows.Forms.ToolStripMenuItem miLoadGame;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem окноToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem статистикаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miExit;
        private System.Windows.Forms.ToolStripMenuItem свернутьВТрейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem развернутьНаВесьЭкранToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem первымиХодятXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem первымиХодятОToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel stStepXO;
        private System.Windows.Forms.ToolStripProgressBar stTimeProgress;
        private System.Windows.Forms.ToolStripStatusLabel stCurTime;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Timer tmCurTime;
        private System.Windows.Forms.Timer tmGameTimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem miFont;
        private System.Windows.Forms.ToolStripMenuItem miColor;
        private System.Windows.Forms.FontDialog fdFont;
        private System.Windows.Forms.Label lOCount;
        private System.Windows.Forms.Label lXCount;
    }
}

