﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace winforms3
{
    public partial class frmGame : Form
    {
        public frmGame()
        {
            InitializeComponent();
            UpdateCurrentStep();
            tmGameTimer.Stop();
        }
        private bool curStepX = true;
        private bool isStartGame = false;
        private Font fontXO = new Font("Arial", 30);
        private Color colorXO = Color.Black;
        private char[][] gridXO = new char[3][] { new char[]{ '-', '-','-'},new char[] { '-','-','-' },new char[]{'-','-','-' } };
        private int XWinCount = 0;
        private int OWinCount = 0;
        private void pnPole00_Click(object sender, EventArgs e)
        {
            Panel pn = sender as Panel;
            if (!isStartGame)
            {
                isStartGame = true;
                tmGameTimer.Start();
            }
            stTimeProgress.Value = 0;

            //Panel pn = (Panel)sender;
            string tag = pn.Tag as string;
            label1.Text = tag;
            int temp = int.Parse(tag.Split(';')[2]); //0, 1-X, 2-O
            switch (temp)
            {
                case 0:
                    temp = (curStepX ? 1 : 2);
                    string[] temp2 = tag.Split(';');
                    pn.Tag = temp2[0]+";"+temp2[1]+";"+temp.ToString();
                    gridXO[int.Parse(temp2[0])][int.Parse(temp2[1])] = curStepX ? 'X' : 'O';
                    curStepX = !curStepX;
                    UpdateCurrentStep();
                    pn.Invalidate(true);
                    pn.Update();
                    break;
                case 1: case 2: break;
            }
            if (IsGameOver())
            {
                tmGameTimer.Stop();
                MessageBox.Show("Победили " + (!curStepX ? "Крестики!" : "Нолики!"));
                if (!curStepX)
                {
                    XWinCount++;
                    lXCount.Text = "X: " + XWinCount.ToString();
                }
                else
                {
                    OWinCount++;
                    lOCount.Text = "O: " + OWinCount.ToString();
                }
                ClearPole();
                isStartGame = false;
            }
            if (IsTie())
            {
                tmGameTimer.Stop();
                MessageBox.Show("Ничья!");
                ClearPole();
                isStartGame = false;
            }
        }

        private bool IsGameOver()
        {
            if (gridXO[0][0] != '-' && gridXO[0][0] == gridXO[0][1] && gridXO[0][1] == gridXO[0][2] ||
                gridXO[0][0] != '-' && gridXO[0][0] == gridXO[1][1] && gridXO[1][1] == gridXO[2][2] ||
                gridXO[0][0] != '-' && gridXO[0][0] == gridXO[1][0] && gridXO[1][0] == gridXO[2][0] ||
                gridXO[0][1] != '-' && gridXO[0][1] == gridXO[1][1] && gridXO[1][1] == gridXO[2][1] ||
                gridXO[0][2] != '-' && gridXO[0][2] == gridXO[1][2] && gridXO[1][2] == gridXO[2][2] ||
                gridXO[1][0] != '-' && gridXO[1][0] == gridXO[1][1] && gridXO[1][1] == gridXO[1][2] ||
                gridXO[0][2] != '-' && gridXO[0][2] == gridXO[1][1] && gridXO[1][1] == gridXO[2][0] ||
                gridXO[2][0] != '-' && gridXO[2][0] == gridXO[2][1] && gridXO[2][1] == gridXO[2][2]) return true;
            return false;
        }

        private bool IsTie()
        {
            for (int i = 0; i < gridXO.Length; i++)
            {
                for (int j = 0; j < gridXO[i].Length; j++)
                {
                    if (gridXO[i][j] == '-') return false;
                }
            }
            return true;
        }
        private void UpdateCurrentStep()
        {
            stStepXO.Text = curStepX ? "X": "O";
        }
        private void pnPole00_Paint(object sender, PaintEventArgs e)
        {
            Panel pn = sender as Panel;
            int temp = int.Parse((pn.Tag as string).Split(';')[2]);
            string text = " ";
            switch (temp)
            {
                case 1: text = "X"; break;
                case 2: text = "O"; break;
            }
            //Font font = pn.Font;
            Font font = fontXO;
            Brush brush = new SolidBrush(colorXO);
            SizeF sz = e.Graphics.MeasureString(text, font);
            float x = (pn.Width - sz.Width)/2;
            float y = (pn.Height - sz.Height)/2;
            e.Graphics.DrawString(text, font, brush, x, y);
            e.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Black),5), x, y, sz.Width, sz.Height-10);
        }

        private void tmCurTime_Tick(object sender, EventArgs e)
        {
            //tmCurTime.Stop();
            stCurTime.Text = DateTime.Now.ToString("HH:mm:ss");
            //tmCurTime.Start();
        }

        private void tmGameTimer_Tick(object sender, EventArgs e)
        {
            stTimeProgress.PerformStep();
            if(stTimeProgress.Value >= 100)
            {
                tmGameTimer.Stop();
                MessageBox.Show("Time is up!\r\nYou Loose!", "Game over", MessageBoxButtons.OK);
                ClearPole();
                isStartGame = false;
            }
        }

        private void ClearPole()
        {
            for (int i = 0; i < gridXO.Length; i++)
            {
                for (int j = 0; j < gridXO[i].Length; j++)
                {
                    gridXO[i][j] = '-';
                }
            }
            foreach(Control item in pnGame.Controls)
            {
                if (item.Tag is null) { continue; }
                string str = item.Tag as string;
                if (str.Length >0 && str.Split(';').Length==3)
                {
                    string[] strArr = str.Split(';');
                    strArr[2] = "0";
                    item.Tag = string.Join(";", strArr);
                    item.Invalidate(true);
                    item.Update();
                }
            }
        }
        private void miFont_Click(object sender, EventArgs e)
        {
            tmGameTimer.Stop();
            fdFont.Color = colorXO;
            if(fdFont.ShowDialog(this) == DialogResult.OK)
            {
                fdFont_Apply(sender, e);
            }
            tmGameTimer.Start();
        }

        private void fdFont_Apply(object sender, EventArgs e)
        {
            fontXO = fdFont.Font;
            colorXO = fdFont.Color;
            Invalidate(true);
            Update();
        }

        private void miColor_Click(object sender, EventArgs e)
        {
            bool isTimer = tmGameTimer.Enabled;
            if(isTimer) tmGameTimer.Stop();
            ColorDialog cdColor = new ColorDialog();
            cdColor.AllowFullOpen = true;
            cdColor.FullOpen = false;
            cdColor.AnyColor = true;
            cdColor.Color = colorXO;
            if(cdColor.ShowDialog(this) == DialogResult.OK)
            {
                colorXO = cdColor.Color;
                Invalidate(true);
                Update();
            }
            if(isTimer) tmGameTimer.Start();
        }
    }
}
