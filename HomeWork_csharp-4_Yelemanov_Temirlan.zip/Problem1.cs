﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

//Разработать абстрактный класс «Геометрическая Фигура» с методами «Площадь Фигуры» и «Периметр Фигуры».
//Разработать классы-наследники: Треугольник, Квадрат, 
//Ромб, Прямоугольник, Параллелограмм, Трапеция, Круг, 
//Эллипс.Реализовать конструкторы, которые однозначно 
//определяют объекты данных классов.
//Реализовать класс «Составная Фигура», который 
//может состоять из любого количества «Геометрических 
//Фигур». Для данного класса определить метод нахождения 
//площади фигуры. Создать диаграмму взаимоотношений 
//классов.

namespace csharp4
{
    public interface iFigure
    {
        public abstract float Area();
        public abstract float Perimeter();
    }
    public abstract class Figure : iFigure
    {
        protected List<float> sides;
        public abstract float Area();
        public virtual float Perimeter()
        {
            float perimeter = 0;
            foreach (var side in sides)
            {
                perimeter+=side;
            }
            return perimeter;
        }
    }
    
    public class Triangle : Figure
    {
        public Triangle(float a,float b,float c) 
        {
            sides= new List<float>();
            sides.Add(a);
            sides.Add(b);
            sides.Add(c);
        }      
        public override float Area()
        {
            float perimeter = Perimeter();
            return (float)Math.Sqrt(perimeter*(perimeter-sides[0])*(perimeter-sides[1])*(perimeter-sides[2]));
        }
    }
    public class Square : Figure
    {
        public Square(float side)
        {
            sides= new List<float>();
            sides.Add(side);
        }
        public override float Area()
        {
            return sides[0]*sides[0];
        }
        public override float Perimeter()
        {
            return sides[0]*4;
        }
    }
    public class Rectangle : Figure
    {
        public Rectangle(float width, float height)
        {
            sides= new List<float>();
            sides.Add(width);
            sides.Add(height);
        }
        public override float Area()
        {
            return sides[0]*sides[1];
        }
        public override float Perimeter()
        {
            return sides[0]*2+sides[1]*2;
        }
    }
    public class Circle : Figure
    {
        public Circle(float radius)
        {
            sides= new List<float>();
            sides.Add(radius);
        }
        public override float Area()
        {
            return (float)Math.PI*sides[0]*sides[0];
        }
        public override float Perimeter()
        {
            return 2*(float)Math.PI*sides[0];
        }
    }
    public class CompositeFigure : iFigure
    {
        private List<Figure> figures;
        public CompositeFigure()
        {
            figures= new List<Figure>();
        }
        public CompositeFigure(List<Figure> figures)
        {
            this.figures = figures;
        }
        public void AddFigure(Figure f)
        {
            figures.Add(f);
        }
        public float Area()
        {
            float area = 0;
            foreach (var item in figures)
            {
                area += item.Area();
            }
            return area;
        }
        public float Perimeter()
        {
            float area = 0;
            foreach (var item in figures)
            {
                area += item.Perimeter();
            }
            return area;
        }
    }
}
