﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

//Разработать архитектуру классов иерархии товаров 
//при разработке системы управления потоками товаров для 
//дистрибьюторской компании. Прописать члены классов.
//Создать диаграммы взаимоотношений классов.
//Должны быть предусмотрены разные типы товаров,
//в том числе:
//• бытовая химия;
//• продукты питания.
//Предусмотреть классы управления потоком товаров
//(пришло, реализовано, списано, передано)

namespace csharp4
{
    public enum ProductType
    {
        HouseholdChemicals,
        Food,
        Tools,
        BuildingMaterials,
        Cloth,
        CitchenStuff,
    }
    public enum ProductState
    {
        Shipped,
        Implemented,
        Scrapped,
        Transfered,
    }
    public class Product
    {
        public int ID { get; protected set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Cost { get; set; }
        public ProductType Type { get; set; }
        public ProductState State { get; set; }
        public int Count { get; set; }

        public Product(int id, string name, string description, int cost, ProductType type, ProductState state, int count)
        {
            ID = id;
            Name = name;
            Description = description;
            Cost=cost;
            Type=type;
            State=state;
            Count=count;
        }
        public Product(Product product) {
            this.ID = product.ID;
            this.Name = product.Name;
            this.Description = product.Description;
            this.Cost = product.Cost;
            this.Type = product.Type;
            this.State = product.State;
            this.Count = product.Count;
        }
        public static Product GetRandomProduct(int id)
        {
            Random random= new Random();
            string name = string.Empty;
            string description = string.Empty;
            name+=(char)(random.Next('A', 'Z'));
            description += (char)random.Next('A', 'Z');
            for (int i = 0; i < 10; i++)
            {
                name += (char)random.Next('a', 'z');
                description += (char)random.Next('a', 'z');
            }
            int cost = random.Next(1000,100000);

            int length = Enum.GetNames(typeof(ProductType)).Length;
            ProductType temp = (ProductType)random.Next(0, length);

            int length1 = Enum.GetNames(typeof(ProductState)).Length;
            ProductState tempstate = (ProductState)random.Next(0,length1);

            int count = random.Next(1, 100);

            return new Product(id, name, description, cost, temp,tempstate, count);
        }
    }

    public class ProductController
    {
        private List<Product> shippedProducts;
        private List<Product> implementedproducts;
        private List<Product> scrappedProducts;
        private List<Product> transferedProducts;
        public ProductController()
        {
            shippedProducts = new List<Product>();
            implementedproducts = new List<Product>();
            scrappedProducts = new List<Product>();
            transferedProducts = new List<Product>();
        }
        //вставка продукта в поток
        public void AddProduct(Product product)
        {
            switch (product.State)
            {
                case ProductState.Shipped: shippedProducts.Add(product); break;
                case ProductState.Implemented: implementedproducts.Add(product); break;
                case ProductState.Scrapped: scrappedProducts.Add(product); break;
                case ProductState.Transfered: transferedProducts.Add(product); break;
                default: throw new Exception("ProductController.AddProduct():error");
            }
        }
        //получение в поток продукта
        public void AcceptProduct(Product product)
        {
            product.State = ProductState.Shipped;
            shippedProducts.Add(product);
        }
        private void Promotion(int id, ref List<Product> from, ref List<Product> to)
        {
            Product temp;
            List<Product> deletionList = new List<Product>();
            foreach (var item in from)
            {
                if (item.ID == id)
                {
                    temp = new Product(item);

                    //продвижение статуса
                    temp.State = (ProductState)(((int)temp.State+1) >= Enum.GetNames(typeof(ProductState)).Length ?
                        (Enum.GetNames(typeof(ProductState)).Length-1) : ((int)temp.State+1));
                    to.Add(temp);
                    deletionList.Add(item);
                }
            }
            foreach (var item in deletionList)
            {
                from.Remove(item);
            }
            deletionList.Clear();
        }
        //продвижение товара по статусу
        public void PromoteState(int id)
        {
            Promotion(id,ref scrappedProducts,ref transferedProducts);
            Promotion(id,ref implementedproducts,ref scrappedProducts);
            Promotion(id,ref shippedProducts,ref implementedproducts);
        }
        public void ClearTransferedProducts()
        {
            transferedProducts.Clear();
        }
        public override string ToString()
        {
            return $"shipped Products({shippedProducts.Count})\nImplemented Products({implementedproducts.Count})\nScrapped Products({scrappedProducts.Count})\nTransfered Products({transferedProducts.Count})";
        }
    }
}
