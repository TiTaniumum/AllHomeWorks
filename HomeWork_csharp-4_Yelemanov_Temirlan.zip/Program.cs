﻿using System;
using System.Security.AccessControl;
using csharp4;

namespace HomeWork4
{
    public class MainClass
    {
        public static void ProblemReview1()
        {
            List<Figure> figures = new List<Figure>();
            figures.Add(new Circle(5));
            figures.Add(new Square(5));
            figures.Add(new Rectangle(5, 10));
            figures.Add(new Triangle(4, 5, 6));
            CompositeFigure composite = new CompositeFigure(figures);

            foreach (var item in figures)
            {
                Console.WriteLine(item +" Area: " + item.Area());
                Console.WriteLine(item + " Perimeter: " + item.Perimeter());
            }
            Console.WriteLine("Composite Area: " + composite.Area());
            Console.WriteLine("Composite Perimeter: " + composite.Perimeter());
        }

        public static void ProblemReview2()
        {
            ProductController controller = new ProductController();
            int id = 0;
            for (int i = 0; i < 10; i++)
            {
                controller.AddProduct(Product.GetRandomProduct(id++));
            }
            Console.WriteLine(controller);
            for (int i = 0; i < 10; i++)
            {
                controller.PromoteState(i);
            }
            Console.WriteLine();
            Console.WriteLine(controller);
            for (int i = 0; i < 5; i++)
            {
                controller.AcceptProduct(Product.GetRandomProduct(id++));
            }
            Console.WriteLine();    
            Console.WriteLine(controller);
            for (int i = 0; i < id; i++)
            {
                controller.PromoteState(i);
            }
            Console.WriteLine();
            Console.WriteLine(controller);
        }
        public static void Main(string[] args)
        {
            ProblemReview1();
            ProblemReview2();
        }
    }
}