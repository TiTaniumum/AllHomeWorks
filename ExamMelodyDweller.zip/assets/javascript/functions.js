async function getJson(url) {
    let response = await fetch(url,{"method": "post", body:`{"apikey": "${key}"}`,headers: {
        "Content-type": "application/json; charset=utf-8"
    }});
    let promise = await response.json();
    return promise
}

async function sendForm(url, method = "get", formData) {
    let response = await fetch(url, {
        "method": method,
        body: JSON.stringify(formData),
        headers: {
            "Content-type": "application/json; charset=utf-8"
        }
    });
    let promise = await response.json();
    return promise;
}

function submitForm(form, redirectURL = "") {
    let formData = new FormData(form);
    let formObj = Object.fromEntries(formData.entries());
    formObj.apikey = key;
    sendForm(form.action, form.method, formObj).then(response => {
        console.log(response);
        if (handleResponse(response) == true) {
            if (redirectURL !== "") redirect(redirectURL);
        }
    });
}


function redirect(redirectURL) {
    window.location.href = redirectURL;
}

function handleResponse(response) {
    if (response.code == 200 && response.message == "success") {
        responseSuccess();
        return true;
    }
    else {
        responseError();
        return false;
    }
}

function responseSuccess() {
    alert("SUCCESS!");
}

function responseError() {
    alert("ERROR!");
}

function unsetCookie(cookieName) {
    document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}

async function submitAddMusicForm(form, selectedartists, selectedgenres) {
    let formData = new FormData(form);
    formData.append("selectedartists", JSON.stringify(selectedartists));
    formData.append("selectedgenres", JSON.stringify(selectedgenres));
    formData.append("apikey", key);
    let response = await fetch(form.action, {
        method: 'POST',
        body: formData
    });
    promise = await response.json();
    console.log(promise);
}

function creatCardBySelect(select, container, arr) {
    if (select.value == 0) return;
    let str = select.options[select.selectedIndex].text;
    let value = select.value;
    let genrecard = document.createElement("div");
    genrecard.classList.add("card");
    let p = document.createElement("p");
    p.innerText = str;
    let button = document.createElement("button");
    button.innerText = "X";
    button.addEventListener("click", e => {
        e.preventDefault();
        genrecard.remove();
        removeByData(arr, value);
    });
    arr.push(value);
    genrecard.append(p);
    genrecard.append(button);
    container.append(genrecard);
}

function removeByData(arr, d) {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] == d) {
            arr.splice(i, 1);
            return;
        }
    }
}

function updatemusiclist(musiclisttag, musiclist){
    musiclist.forEach(element => {
        
    });
}