let selectedgenres = [];
let selectedartists = [];


window.onload = event => {
    let form = document.querySelector("#addmusic");
    let select = document.querySelector("#genre");
    let select2 = document.querySelector("#artist");
    let addgenrebutton = document.querySelector("#addgenre");
    let genres  = document.querySelector(".genres");
    let addartistbutton = document.querySelector("#addartist");
    let artists = document.querySelector(".artists");

    getJson("api/getartists").then(artists=>{
        console.log(artists);
        artists.forEach(artist=>{
            let option = document.createElement("option");
            option.value = artist.id;
            option.innerText = artist.name;
            select2.append(option);
        });
    });

    getJson("api/getgenres").then(genres=>{
        console.log(genres);
        genres.forEach(genre => {
            let option = document.createElement("option");
            option.value = genre.id;
            option.innerText = genre.name;
            select.append(option);
        });
    });

    addartistbutton.addEventListener("click",e=>{
        e.preventDefault();
        creatCardBySelect(select2, artists, selectedartists);
    });

    addgenrebutton.addEventListener("click",e=>{
        e.preventDefault();
        creatCardBySelect(select, genres, selectedgenres);
    });

    form.addEventListener("submit", e => {
        e.preventDefault();
        submitAddMusicForm(form,selectedartists, selectedgenres);
        alert("success");
    });
}