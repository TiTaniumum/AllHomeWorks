let unsignbutton = document.querySelector("#unsetcookiecurrentuser");

if(unsignbutton !== null)
unsignbutton.addEventListener("click", e=>{
    e.preventDefault();
    unsetCookie("currentuser");
    redirect(unsignbutton.href);
});