window.onload = event => {
    let form = document.querySelector("#addartist");
    
    form.addEventListener("submit", e => {
        e.preventDefault();
        if(form.elements["name"].value =="") return;
        submitAddMusicForm(form);
        alert("success");
    });
}