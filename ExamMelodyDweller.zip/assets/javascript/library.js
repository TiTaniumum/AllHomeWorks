const selectedgenres = [];
window.onload = event => {
    let select = document.querySelector("#genre");
    let addgenrebutton = document.querySelector("#addgenre");
    let genres = document.querySelector(".genres");

    let filterbutton = document.querySelector("#filterbutton");

    let musicsection = document.querySelector("#musicsection");

    getJson("api/getgenres").then(genres => {
        console.log(genres);
        genres.forEach(genre => {
            let option = document.createElement("option");
            option.value = genre.id;
            option.innerText = genre.name;
            select.append(option);
        });
    });

    addgenrebutton.addEventListener("click", e => {
        e.preventDefault();
        creatCardBySelect(select, genres, selectedgenres);
    });

    filterbutton.addEventListener("click", e => {
        let data = {};
        data.selectedgenres = selectedgenres;
        data.apikey = key;
        sendForm("api/getfilteredmusiclist", "post", data).then(musiclist => {
            musicsection.innerHTML = "";
            let p = document.createElement("p");
            p.innerText = "Music list:";
            musicsection.append(p);
            musiclist.forEach(music=>{
                let img = document.createElement("img");
                img.src = music.photo_url;
                let label = document.createElement("label");
                label.innerText = music.name;
                let buttonplay = document.createElement("button");
                buttonplay.classList.add("playmusic");
                buttonplay.value = music.file_url;
                buttonplay.innerText = "play";
                label.append(buttonplay);
                let divmusic = document.createElement("div");
                divmusic.classList.add("music");
                divmusic.append(label);
                let musiccard = document.createElement("div");
                musiccard.classList.add("musiccard");
                musiccard.append(img);
                musiccard.append(divmusic);
                musicsection.append(musiccard);
                buttonaddevent(buttonplay);
            })
            console.log(musiclist);
        });
        //musiclistupdated();
    });

    musiclistupdated();
    hidevisualizerbuttonupdate();
}