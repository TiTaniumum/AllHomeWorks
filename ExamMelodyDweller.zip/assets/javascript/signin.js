let form = document.querySelector("#signin");
const redirectURL = "http://localhost/Temirlan/PHP/ExamMelodyDweller/home";

form.addEventListener("submit", e=>{
    e.preventDefault();
    submitForm(form, redirectURL);
});