let form = document.querySelector("#signup");
const redirectURL = "http://localhost/Temirlan/PHP/ExamMelodyDweller/signin";

form.addEventListener("submit", e=>{
    e.preventDefault();
    if(form.elements["login"].value == "" || form.elements["password"].value == ""){
        alert("login or password are empty!");
        return;
    }
    submitForm(form, redirectURL);
});