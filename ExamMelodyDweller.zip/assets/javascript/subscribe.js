const redirecturl = "home";
window.onload = event =>{
    let form = document.querySelector("#subscribe");
    console.log(form);
    form.addEventListener("submit", e=>{
        e.preventDefault();
        getJson(form.action).then(response=>{
            console.log(response);
            if(response.message == "notsuccess")
                alert("something went wrong!");
            else{
                alert("You have purchased subscribtion!");
                redirect(redirecturl);
            }
        });
    });
};