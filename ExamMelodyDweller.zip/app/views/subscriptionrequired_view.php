<section>
    <p>You need to have subscription to our service in order to see the content!</p>
    <?php if(!isset($_COOKIE["currentuser"])):?>
    <p>Authorization also required!</p>
    <?php endif?>
</section>