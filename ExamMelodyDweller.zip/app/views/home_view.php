<?php 
include "model_musiclist.php";
include "controller_10randommusic.php";
?>