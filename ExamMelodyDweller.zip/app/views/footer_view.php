<footer>
    <p>&copy; 2023 Melody Dweller. All rights reserved.</p>
    <p>Made by Yelemanov Temirlan</p>
</footer>