<div id="content">
    <!-- <input type="file" id="thefile"> -->
    <canvas id="canvas"></canvas>
</div>
<button id="hidevisualizer">Hide Visualizer</button>
<audio id="audio" controls></audio>

<script src="assets/javascript/visualizer.js"></script>