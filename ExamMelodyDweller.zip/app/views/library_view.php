<link rel="stylesheet" href="assets/css/genrecard.css">
<link rel="stylesheet" href="assets/css/musiclist.css">

<section>
    <div>
        <label>Genre:
            <select name="genre" id="genre">
                <option value=0>Not selected</option>
            </select>
        </label>
        <button id="addgenre">Add</button>
        <div class="genres">
        </div>
        <button id="filterbutton">Search by Filter</button>
    </div>
</section>

<section id="musicsection">
    <p>Music list:</p>
    <?php foreach ($data as $music): ?>
        <div class="musiccard">
            <img src="<?= $music['photo_url']; ?>" alt="">
            <div class="music">
                <label>
                    <?= $music["name"]; ?>
                    <button class="playmusic" value="<?= $music['file_url'] ?>">play</button>
                </label>
            </div>
        </div>
    <?php endforeach; ?>
</section>

<?php include("app/views/visualizer_view.php");?>

<script src="assets/javascript/library.js"></script>