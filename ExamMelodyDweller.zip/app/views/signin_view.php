<form action="api/signin" method="post" name="signin" id="signin">
    <input type="text" placeholder="login" name="login">
    <input type="password" placeholder="password" name="password">
    <button type="submit">Sign in</button>
</form>

<script src="assets/javascript/signin.js"></script>