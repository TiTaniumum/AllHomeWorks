<?php require_once("app/controllers/controller_api.php")?>
<header>
    <h1>Melody Dweller</h1>
    <nav>
        <ul>
            <li><a href="home">Home</a></li>
            <?php if(Controller_api::checkUser()&& Controller_api::isSubscribed()):?>
            <li><a href="addartist">Add Artist</a></li>
            <li><a href="addmusic">Add Music</a></li>
            <li><a href="library">Library</a></li>
            <?php endif;?>
            <!-- <li><a href="">Profile</a></li> -->
            <?php if(Controller_api::checkUser()&&!Controller_api::isSubscribed()):?>
            <li><a href="subscribe">Subscribe</a></li>
            <?php endif;?>
            <?php if (isset($_COOKIE["currentuser"])): ?>
                <li><a href="home" id="unsetcookiecurrentuser">Unsign</a></li>
            <?php else: ?>
                <li><a href="signin">Sign in</a></li>
                <li><a href="signup">Sign up</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
<script src="assets/javascript/requests.js"></script>
<script src="assets/javascript/functions.js"></script>
<script src="assets/javascript/unsign.js"></script>