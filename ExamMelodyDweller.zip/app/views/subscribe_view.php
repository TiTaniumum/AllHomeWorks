<form action="api/subscribe" method="post" name="subscribe" id="subscribe">
    <p>Subscribtion Price: 1$</p>
    <label>
        Bank card:
        <input type="text">
    </label>
    <label>
        Full name:
        <input type="text">
    </label>
    <label>
        SVC:
        <input type="text">
    </label>
    <button type="submit">Subscribe</button>
</form>

<script src="assets/javascript/subscribe.js"></script>