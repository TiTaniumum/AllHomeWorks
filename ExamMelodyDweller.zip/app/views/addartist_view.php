<form action="api/addartist" method="post" name="addartist" id="addartist" enctype="multipart/form-data">
    <label>
        Band or musicion name:
        <input type="text" placeholder="..." name="name">
    </label>
    <label>
        Photo:
        <input type="file" accept=".jpeg, .jpg, .png, .gif, .webp, .svg, .bmp" name="photo">
    </label>
    <label>
        Biography:
        <textarea name="bio" id="bio" cols="30" rows="10" placeholder="..."></textarea>
    </label>
    <button type="submit">Add Artist</button>
</form>

<script src="assets/javascript/addartist.js"></script>