<link rel="stylesheet" href="assets/css/genrecard.css">
<form action="api/addmusic" method="post" name="addmusic" id="addmusic" enctype="multipart/form-data">
    <label >Music: 
        <input type="file" name="music" accept=".mp3, .wav, .ogg, aac">
    </label>
    <label>ArtWork:
            <input type="file" name="artwork" accept=".jpeg, .jpg, .png, .gif, .webp, .svg, .bmp">
    </label>
    <div>
        <label>
            Artist:
            <select name="artist" id="artist">
                <option value=0>Not selected</option>
            </select>
        </label>
        <button id="addartist">Add</button>
        <div class="artists">
        </div>
    </div>
    <div>
        <label>Genre:
            <select name="genre" id="genre">
                <option value=0>Not selected</option>
            </select>
        </label>
        <button id="addgenre">Add</button>
        <div class="genres">
        </div>
    </div>
    <label>
        Release Date:
        <input type="date" name="release_date">
    </label>
    <button type="submit">Add Music</button>
</form>

<script src="assets/javascript/addmusic.js"></script>