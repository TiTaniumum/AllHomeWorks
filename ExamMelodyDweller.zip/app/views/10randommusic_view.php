<link rel="stylesheet" href="assets/css/musiclist.css">
<section>
    
        <p>10 Random Music:</p>
        <?php $count = 10; ?>
        <?php foreach ($data as $music): ?>
            <div class="musiccard">
                <img src="<?=$music['photo_url'];?>" alt="">
                <div class="music">
                    <label>
                        <?= $music["name"]; ?>
                        <!-- <audio controls>
                            <source src="< $music['file_url'] >" type="audio/mpeg">
                            Your browser does not support the audio element.
                        </audio> -->
                        <button class="playmusic" value="<?=$music['file_url']?>">play</button>
                    </label>
                </div>
            </div>
            <?php $count--; ?>
            <?php if ($count == 0)
                break; ?>
        <?php endforeach; ?>
    
</section>

<?php include("app/views/visualizer_view.php");?>