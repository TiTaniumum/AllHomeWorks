<form action="api/signup" name="signup" id="signup" method="post">
    <input type="text" placeholder="name" name="name">
    <input type="text" placeholder="login" name="login">
    <input type="email" placeholder="email" name="email">
    <input type="password" placeholder="password" name="password">
    <button type="submit">Sign Up</button>
</form>

<script src="assets/javascript/signup.js"></script>