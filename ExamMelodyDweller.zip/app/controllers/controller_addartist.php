<?php 
class Controller_addartist extends Controller{
    public function __construct(){
        parent::__construct();
    }
    public function action_index()
    {
        $this->view->generate("addartist_view.php","template_view.php");
    }
}
?>