<?php 
class Controller_subscribe extends Controller{
    public function __construct(){
        parent::__construct();
    }
    public function action_index()
    {
        $this->view->generate("subscribe_view.php", "template_view.php");
    }
}
?>