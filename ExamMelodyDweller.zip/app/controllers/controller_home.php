<?php 
class Controller_home extends Controller{
    public function __construct(){
        require_once("app/models/model_musiclist.php");
        require_once("app/controllers/controller_api.php");
        $this->model = new Model_Home;
        parent::__construct();
    }
    public function action_index(){
        $musiclist = new Model_musiclist();
        $data = $musiclist->getData();
        $data = Model_musiclist::shuffle($data);
        if(Controller_api::checkUser() && Controller_api::isSubscribed())
            $this->view->generate("10randommusic_view.php", "template_view.php",$data);
        else 
            $this->view->generate("subscriptionrequired_view.php", "template_view.php");
    }
}
?>