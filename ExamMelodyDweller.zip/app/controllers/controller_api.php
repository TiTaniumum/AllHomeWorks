<?php
class Controller_api extends Controller
{
    public function __construct()
    {
        parent::__construct();
        header("Content-type: application/json;charset=utf-8");
    }
    public function action_index()
    {

    }

    public function action_signup()
    {
        $data = $this->getData();
        if (!$this->AccessAPI($data))
            return;

        $sql = "insert into users(name, login, email, password) values (:name,:login,:email,:password);";
        $arr = [];
        $arr["name"] = $data->name;
        $arr["login"] = $data->login;
        $arr["email"] = $data->email;
        $arr["password"] = $data->password;

        if (Database::insert($sql, $arr) == 0)
            echo json_encode($this->notsuccess());
        else
            echo json_encode($this->success());
    }

    public function action_signin()
    {
        $data = $this->getData();
        if (!$this->AccessAPI($data))
            return;

        $sql = "call is_valid_user_login_password(:login, :password)";
        $arr = [];
        $arr["login"] = $data->login;
        $arr["password"] = $data->password;

        if (Database::getRow($sql, $arr)->is_valid == 0) {
            echo json_encode($this->notsuccess());
        } else {
            echo json_encode($this->authtoken($data));
        }
    }
    public function action_addmusic()
    {
        $data = new stdClass;
        $data->files = $_FILES;
        $data->post = $_POST;
        $data->get = $_GET;

        if (!$this->AccessAPI2())
            return;

        $targetartworkfile = "";
        $targetaudiofile = "";

        if (isset($_FILES) && $_FILES["music"]["error"] == 0) {
            $filename1 = $_FILES["music"]["name"];
            $targetdir = $this->createMusicDir($filename1);
            $targetaudiofile = $targetdir . "/" . $filename1;
            move_uploaded_file($_FILES["music"]["tmp_name"], $targetaudiofile);
            if ($_FILES["artwork"]["error"] != 0) {
                $filename2 = $_FILES["artwork"]["name"];
                $targetartworkfile = $targetdir . "/" . $filename2;
                move_uploaded_file($_FILES["artwork"]["tmp_name"], $targetartworkfile);
            }
            $genres = json_decode($_POST["selectedgenres"]);
            $artists = json_decode($_POST["selectedartists"]);
            $releasedate = $_POST["release_date"] == "" ? null : $_POST["release_date"];
            $sql = "insert into musics(name, file_url,artwork_url, release_date) values(?,?,?,?)";
            $arr1 = array($filename1, $targetaudiofile, $targetartworkfile, $releasedate);
            $musicid = Database::insert($sql, $arr1);

            $sqlgenresrelation = "insert into genre_relations(id_music,id_genre) values(?,?)";
            foreach ($genres as $id) {
                $arr2 = array($musicid, $id);
                Database::insert($sqlgenresrelation, $arr2);
            }

            $sqlartistmusicrelation = "insert into artist_music_relations(id_artist, id_music) values(?,?)";
            foreach ($artists as $id) {
                $arr3 = array($id, $musicid);
                Database::insert($sqlartistmusicrelation, $arr3);
            }
        }

        $data->targetaudiofile = $targetaudiofile;
        $data->targetartworkfile = $targetartworkfile;

        echo json_encode($data);
    }

    public function action_addartist()
    {
        $data = new stdClass;
        $data->files = $_FILES;
        $data->post = $_POST;
        $data->get = $_GET;

        if (!$this->AccessAPI2())
            return;

        $targetfile = "";
        if (isset($_FILES) && $_FILES["photo"]["error"] == 0 && isset($_POST["name"])) {
            $filename = $_FILES["photo"]["name"];
            $targetdir = $this->createArtistDir($filename);
            $targetfile = $targetdir . "/" . $filename;
            move_uploaded_file($_FILES["photo"]["tmp_name"], $targetfile);
            $bio = isset($_POST["bio"]) ? $_POST["bio"] : "";
            $sql = "insert into artists(name, photo_url, bio) values (?,?,?);";
            $arr = array($_POST["name"], $targetfile, $bio);
            $data->lastid = Database::insert($sql, $arr);
        }

        $data->targetfile = $targetfile;


        echo json_encode($data);
    }

    public function action_getgenres()
    {
        if (!$this->AccessAPI3())
            return;
        require_once("app/models/model_genres.php");
        $this->model = new Model_genres();
        $data = $this->model->getData();
        echo json_encode($data);
    }
    public function action_getartists()
    {
        if (!$this->AccessAPI3())
            return;
        require_once("app/models/model_artists.php");
        $this->model = new Model_artists();
        $data = $this->model->getData();
        echo json_encode($data);
    }

    public function action_subscribe()
    {
        if (!$this->AccessAPI3())
            return;
        if (!Controller_api::checkUser()) {
            echo json_encode($this->notsuccess());
            return;
        }
        $sql = "call subscribe(?);";
        $arr = array($_COOKIE["currentuser"]);
        $lastid = Database::insert($sql, $arr);

        // if($lastid == 0) 
        //     echo json_encode($this->notsuccess());
        // else 
        //     echo json_encode($this->success());
        echo json_encode($this->success());
    }

    public function action_getfilteredmusiclist()
    {
        if (!$this->AccessAPI3())
            return;
        if (!Controller_api::checkUser()) {
            echo json_encode($this->notsuccess());
            return;
        }
        $data =$this->getData();
        $sql = "call get_musics_with_genres();";
        $musiclist = Database::getAll($sql); 
        
        $selectedgenres = $data->selectedgenres;

        $resultmusiclist = [];

        foreach($musiclist as $music){
            if(array_intersect(explode(",",$music->genres), $selectedgenres)){
                $resultmusiclist[] = $music;
            }
        }

        echo json_encode($resultmusiclist);
    }

    private function AccessAPI($data)
    {
        if (!isset($data->apikey) || $data->apikey == "") {
            echo json_encode($this->NoApiKey());
            return false;
        }
        if ($this->CheckAPIKey($data)->is_valid == 0) {
            echo json_encode($this->InvalidApiKey());
            return false;
        }
        return true;
    }
    private function AccessAPI3()
    {
        $data = $this->getData();
        return $this->AccessAPI($data);
    }
    private function AccessAPI2()
    {
        if (!isset($_POST["apikey"]) || $_POST["apikey"] == "") {
            echo json_encode($this->gatherinfo());
            return false;
        }
        if ($this->CheckKey($_POST["apikey"])->is_valid == 0) {
            echo json_encode($this->gatherinfo());
            return false;
        }
        return true;
    }
    private function gatherinfo()
    {
        $data = new stdClass;
        $data->post = $_POST;
        $data->get = $_GET;
        $data->files = $_FILES;
        $data->additional = $this->getData();
        return $data;
    }
    private function encode()
    {
        return json_encode($this->model);
    }
    private function NoApiKey()
    {
        return new Model_api("No ApiKey", 401);
    }
    private function InvalidApiKey()
    {
        return new Model_api("No valid ApiKey", 403);
    }
    private function success()
    {
        return new Model_api("success", 200);
    }
    private function notsuccess()
    {
        return new Model_api("nutsuccess", 200);
    }
    private function authtoken($data)
    {
        $model = new Model_api("success", 200);
        $salt = base64_encode(random_bytes(512));
        $token = base64_encode(random_bytes(512));
        $token = sha1($salt . $token);
        setcookie("currentuser", $token, time() + 7 * 24 * 60 * 60, '/');

        $sql = "call set_user_token (?,?)";
        $arr = array($data->login, $token);
        Database::getRow($sql, $arr);
        return $model;
    }

    private function CheckAPIKey($data)
    {
        $sql = "CALL is_valid_api_key(?);";
        $arr = array($data->apikey);
        return Database::getRow($sql, $arr);
    }

    private function CheckKey($key)
    {
        $sql = "CALL is_valid_api_key(?);";
        $arr = array($key);
        return Database::getRow($sql, $arr);
    }

    private function getData()
    {
        return json_decode(file_get_contents("php://input"));
    }
    private function createArtistDir($name)
    {
        $dir = "assets/artists/";
        $salt = base64_encode(random_bytes(64));
        $dir .= sha1("$salt$name");
        if (!file_exists($dir)) {
            if (mkdir($dir, 0777, true)) {

            } else {

            }
        }
        return $dir;
    }

    private function createMusicDir($name)
    {
        $dir = "assets/music/";
        $salt = base64_encode(random_bytes(64));
        $dir .= sha1("$salt$name");
        if (!file_exists($dir)) {
            if (mkdir($dir, 0777, true)) {

            } else {

            }
        }
        return $dir;
    }
    public static function checkUser()
    {
        if (isset($_COOKIE["currentuser"])) {
            setcookie("currentuser", $_COOKIE["currentuser"], time() + 7 * 24 * 60 * 60, '/');
            return true;
        } else {
            return false;
        }
    }
    public static function isSubscribed()
    {
        $sql = "call subscription_check(?);";
        $arr = array($_COOKIE["currentuser"]);
        $data = Database::getRow($sql, $arr);
        return $data->hadSubscriptions != 0 && $data->isValid = 1;
    }
}

?>