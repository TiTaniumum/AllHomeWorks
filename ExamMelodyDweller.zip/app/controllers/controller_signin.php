<?php 
class Controller_signin extends Controller{
    public function __construct(){
        parent::__construct();
    }

    public function action_index(){
        $this->view->generate("signin_view.php","template_view.php");
    }
}
?>