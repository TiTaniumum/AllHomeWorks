<?php 
class Controller_signup extends Controller{
    public function __construct(){
        parent::__construct();
    }
    public function action_index()
    {
        $this->view->generate("signup_view.php","template_view.php");
    }
}
?>
