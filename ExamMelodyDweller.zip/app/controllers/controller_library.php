<?php 
class Controller_library extends Controller{
    public function __construct(){
        require_once("app/models/model_musiclist.php");
        $this->model = new Model_musiclist();
        parent::__construct();
    }
    public function action_index()
    {
        $data = $this->model->getData();
        $this->view->generate("library_view.php", "template_view.php", $data);
    }
}
?>