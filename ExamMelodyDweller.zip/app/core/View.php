<?php
class View{
    public function generate($view, $template, $data = null){
        include("app/views/$template");
    }
    public function generateAll($data,$template, ...$views){
        include("app/view/$template");
    }
}
?>