<?php 
class Model_musiclist implements Model{
    public function getData()
    {
        $sql = "select m.name as name, m.file_url as file_url, a.photo_url from musics m
        left join artist_music_relations amr
        on m.id = amr.id_music
        left join artists a
        on a.id = amr.id_artist;";
        return Database::getAllArr($sql);
    }
    public function insertData()
    {
        
    }
    public static function shuffle($arr){
        $length = count($arr)-1;
        for($i = 0; $i<100; $i++){
            $index1 = rand(0,$length);
            $index2 = rand(0,$length);
            $temp = $arr[$index1];
            $arr[$index1] = $arr[$index2];
            $arr[$index2] = $temp;            
        }
        return $arr;
    }
}
?>