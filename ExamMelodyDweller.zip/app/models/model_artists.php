<?php 
class Model_artists implements Model{
    public function getData()
    {
        $sql = "select * from artists;";
        return Database::getAll($sql);
    }
    public function insertData()
    {
        
    }
}
?>