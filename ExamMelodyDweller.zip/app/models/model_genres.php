<?php 
class Model_genres implements Model{
    public function getData()
    {
        $sql = "select * from genres;";
        return Database::getAll($sql);
    }
    public function insertData()
    {
    }
}
?>