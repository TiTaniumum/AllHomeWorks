<?php 
class Model_home implements Model{
    public function getData()
    {
        
    }
    public function insertData(){
        
    }
}
?>