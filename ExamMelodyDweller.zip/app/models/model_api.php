<?php 
class Model_api implements Model{
    public string $message;
    public int $code;
    public $data = null;

    public function __construct($message, $code, $data = null){
        $this->message = $message;
        $this->code = $code;
        $this->data = $data;
    }
    function getData()
    {
        
    }

    function insertData()
    {
        
    }
}
?>