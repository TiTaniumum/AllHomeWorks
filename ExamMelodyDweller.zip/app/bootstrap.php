<?php 
//require_once "core/ICreatable.php";
require_once "core/Model.php";
require_once "core/View.php";
require_once "core/Controller.php";
require_once "core/DataBase.php";
require_once "core/Route.php";
Route::start();
?>