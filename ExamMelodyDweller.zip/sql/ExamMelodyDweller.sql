create database melody_dweller;
use melody_dweller;

create table users(
id int auto_increment,
name varchar(32),
login varchar(32),
email varchar(32),
salt varchar(128),
password varchar(128),
registration_date date default now(),
photo_url text,
token varchar(40),
constraint pk_users_id primary key(id),
constraint u_users_login unique(login),
constraint u_users_token unique(token)
);

create table artists(
id int auto_increment,
name varchar(64),
photo_url text,
bio varchar(2048),
constraint pk_artists_id primary key(id)
);

create table genres(
id int auto_increment,
name varchar(32),
constraint pk_genres_id primary key(id)
);

create table subscription_types(
id int auto_increment,
name varchar(32),
constraint pk_subscription_types_id primary key(id),
constraint u_genres_name unique(name)
);

create table albums(
id int auto_increment,
artwork_url text,
description varchar(1024),
-- characteristics varchar(64), -- excluded column
id_subscription_type int,
rating int,
release_date date,
constraint pk_albums_id primary key(id),
constraint fk_albums_id_subscription_type foreign key(id_subscription_type) references subscription_types(id)
);

create table musics(
id int auto_increment,
name varchar(64),
file_url text unique,
artwork_url text,
release_date date,
constraint pk_musics_id primary key(id)
);	

create table genre_relations(
id int auto_increment,
id_album int,
id_music int,
id_genre int,
constraint pk_genre_relations_id primary key(id),
constraint fk_genre_relations_id_album foreign key(id_album) references albums(id),
constraint fk_genre_relations_id_music foreign key(id_music) references musics(id),
constraint fk_genre_relations_id_genre foreign key(id_genre) references genres(id)
);

create table artist_album_relations(
id int auto_increment,
id_artist int,
id_album int,
constraint pk_artist_album_relations_id primary key(id),
constraint fk_artist_album_relations_id_artist foreign key(id_artist) references artists(id),
constraint fk_artist_album_relations_id_album foreign key(id_album) references albums(id)
);

create table artist_music_relations(
id int auto_increment,
id_artist int,
id_music int,
constraint pk_artist_music_relations_id primary key(id),
constraint fk_artist_music_relations_id_artist foreign key(id_artist) references artists(id),
constraint fk_artist_music_relations_id_music foreign key(id_music) references musics(id)
);

create table playlists(
id int auto_increment,
id_user int,
constraint pk_playlists_id primary key(id),
constraint fk_playlists_id_user foreign key(id_user) references users(id)
);

create table playlist_music_relations(
id int auto_increment,
id_playlist int,
id_music int,
constraint pk_playlist_music_relations_id primary key(id),
constraint fk_playlist_music_relations_id_playlist foreign key(id_playlist) references playlists(id),
constraint fk_playlist_music_relations_id_music foreign key(id_music) references musics(id)
);

create table favorites(
id int auto_increment,
id_user int,
id_artist int,
id_album int,
id_music int,
id_user_follow int,
id_playlist int,
constraint pk_favorites_id primary key(id),
constraint fk_favorites_id_user foreign key(id_user) references users(id),
constraint fk_favorites_id_artist foreign key(id_artist) references artists(id),
constraint fk_favorites_id_album foreign key(id_album) references albums(id),
constraint fk_favorites_id_music foreign key(id_music) references musics(id),
constraint fk_favorites_id_user_follow foreign key(id_user_follow) references users(id),
constraint fk_faborites_id_playlist foreign key(id_playlist) references playlists(id)
);

create table api_keys(
id int auto_increment,
api_key varchar(128),
constraint pk_apikeys_id primary key(id),
constraint u_api_keys_api_key unique(api_key)
);

create table subscriptions(
id int auto_increment,
id_user int,
date_purchase date default now(),
date_expire date,
constraint pk_subscriptions_id primary key(id),
constraint fk_subscriptions_id_user foreign key(id_user) references users(id)
);

delimiter //
create trigger insert_users before insert on users
for each row
begin
	set new.salt = sha2(rand(), 512);
    set new.password = _hash(new.salt, new.password);
end//
delimiter ;

delimiter //
create trigger insert_subscription before insert on subscriptions 
for each row 
begin 
	set new.date_expire = date_add(new.date_purchase, interval 1 month);
end //
delimiter ;

delimiter //
create procedure is_valid_api_key (in _api_key varchar(128))
begin
	select count(*)>0 as is_valid from api_keys where _api_key = api_key;
end//
delimiter ;

delimiter //
create function _hash(salt varchar(128), value varchar(128))
returns varchar(128)
begin
return SHA2(concat(salt, value),512);
end//
delimiter ;

DROP TRIGGER IF EXISTS update_user_info;
DELIMITER //
CREATE TRIGGER update_user_info BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
    SET NEW.salt = OLD.salt;
    IF (OLD.password <=> NEW.password) THEN
		SET NEW.password = OLD.password;
	ELSEIF (NEW.password IS NOT NULL AND NEW.password != '') THEN
        SET NEW.password = _hash(OLD.salt, NEW.password);
    END IF;
END //
DELIMITER ;


delimiter //
create procedure update_user_password (in id_user int,in new_password varchar(128), out is_success bool)
begin 
	update users
    set password = new_password
    where id = id_user;
end //
delimiter ;

delimiter //
create procedure is_valid_user_login_password (in login_user varchar(32),in password_user varchar(128))
begin
	select count(*)>0 as is_valid from users where login = login_user and password = _hash(salt, password_user);
end//
delimiter ;

drop procedure if exists set_user_token;
delimiter //
create procedure set_user_token (in user_login varchar(32),in user_token varchar(40))
begin
	update users
    set token = user_token
    where login = user_login;
end //
delimiter ;

insert into genres(name) values
("Classical"),
("Neo classical"),
("Experimental"),
("Blues"),
("Country"),
("Electronic"),
("Ambient"),
("Bass"),
("Hard bass"),
("Chill-out"),
("Disco"),
("Drum and bass"),
("Dub"),
("EDM"),
("Electronic rock"),
("Post rock"),
("Wave"),
("Synth wave"),
("Space wave"),
("Space rock"),
("Funk"),
("Hardcore"),
("Lofi"),
("Lofi hip hop"),
("Trap"),
("House"),
("Bass house"),
("Deep house"),
("Electro house"),
("Electro swing"),
("Future house"),
("Progressive house"),
("Glitch"),
("Techno"),
("Ambient techno"),
("Dubstep"),
("Video game music"),
("Folk"),
("Folk rock"),
("Indie rock"),
("Indie"),
("Raggae"),
("Hip hop"),
("Beatboxing"),
("Rap"),
("Gangsta rap"),
("Phonk"),
("Bebop"),
("Swing"),
("Jazz"),
("Pop"),
("K-pop"),
("R&B & Soul"),
("Rock"),
("Ambient rock"),
("Depressive rock"),
("Classic rock"),
("Electronic rock"),
("Experimental rock"),
("Industrial rock"),
("Post-metal"),
("Rock and roll"),
("Metal"),
("Depressive suicidal black metal"),
("Death metal"),
("Industrial metal"),
("Electronic metal"),
("Metalcore"),
("Punk"),
("Electropunk"),
("Cyberpunk"),
("Fantasy"),
("Meditation"),
("Melodic house"),
("Cover"),
("Hard Rock"),
("Instrumental");

insert into subscription_types(name) values
("Free to listen"),
("Needs payed subscribtion"),
("Purchasable");

insert into api_keys(api_key) values('5c7f0ee1e5de3cde9aa915745684f3480013959b867253e0c07619514cddad7479006b488a66e023d956cdd311d25001f4194235d6728653232f6f9846b00de6');

select m.name as name, m.file_url as file_url, a.photo_url from musics m
left join artist_music_relations amr
on m.id = amr.id_music
left join artists a
on a.id = amr.id_artist;

drop procedure if exists subscription_check;
delimiter //
create procedure subscription_check(in _token varchar(40))
begin
select count(date_expire)>0 as hadSubscriptions, now()<=date_expire as isValid from users u 
join subscriptions s 
on s.id_user = u.id 
where token = _token
order by date_expire desc
limit 1;
end//
delimiter ;

drop procedure if exists subscribe;
delimiter //
create procedure subscribe(in _token varchar(40))
begin
declare _id int;
set _id = (select id from users 
where token = _token);

if(_id is not null) then
insert into subscriptions(id_user) values (_id);
end if;
end//
delimiter ;

drop procedure if exists get_musics_with_genres;
delimiter //
create procedure get_musics_with_genres()
begin
select m.id,m.name as name, m.file_url as file_url, a.photo_url, group_concat(gr.id_genre separator ",") as genres from musics m
left join artist_music_relations amr
on m.id = amr.id_music
left join artists a
on a.id = amr.id_artist
left join genre_relations gr 
on m.id = gr.id_music
group by m.id;
end //
delimiter ;