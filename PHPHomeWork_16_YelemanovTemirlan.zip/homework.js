async function getJson(url) {
    let response = await fetch(url);
    let promise = await response.json();
    return promise
}

async function sendForm(url, method = "get", formData) {
    let response = await fetch(url, {
        "method": method,
        body: JSON.stringify(formData),
        headers: {
            "Content-type": "application/json; charset=utf-8"
        }
    });
    let promise = await response.json();
    return promise;
}

window.onload = event => {
    let customerid = document.querySelector("#customerId");
    let customersForm = document.querySelector("#customersform")
    getJson("getCustomers.php").then(customers => {
        customers.forEach(customer => {
            let option = document.createElement("option");
            option.value = customer.customerId;
            option.innerText = `${customer.contactLastName} ${customer.contactFirstName}`;
            customerid.append(option);
        });
    });
    customerid.addEventListener("change", event => {
        if (customerid.value == 0) return;
        getJson(`getCustomers.php?id=${customerid.value}`).then(customer => {
            customersForm.elements["customerName"].value = customer.customerName ? customer.customerName : "";
            customersForm.elements["contactLastName"].value = customer.contactLastName ? customer.contactLastName : "";
            customersForm.elements["contactFirstName"].value = customer.contactFirstName ? customer.contactFirstName : "";
            customersForm.elements["phone"].value = customer.phone ? customer.phone : "";
            customersForm.elements["addressLine1"].value = customer.addressLine1 ? customer.addressLine1 : "";
            customersForm.elements["addressLine2"].value = customer.addressLine2 ? customer.addressLine2 : "";
            customersForm.elements["city"].value = customer.city ? customer.city : "";
            customersForm.elements["state"].value = customer.state ? customer.state : "";
            customersForm.elements["postalCode"].value = customer.postalCode ? customer.postalCode : "";
            customersForm.elements["country"].value = customer.country ? customer.country : "";
            customersForm.elements["salesRepemployeeId"].value = customer.salesRepemployeeId ? customer.salesRepemployeeId : "";
            customersForm.elements["creditLimit"].value = customer.creditLimit ? customer.creditLimit : "";
        })
    })
    customersForm.addEventListener("submit", e => {
        e.preventDefault();
        let formData = new FormData(customersForm);
        let formObj = Object.fromEntries(formData.entries());
        console.log(formObj);
        sendForm(customersForm.action, customersForm.method, formObj).then(response => {
            alert(response.message);
        });
    });

    // employeeId
    // lastName
    // firstName
    // extension
    // email
    // officeId
    // reportsTo
    // jobTitle
    let employeeid = document.querySelector("#employeeId");
    let employeesForm = document.querySelector("#employeesform");
    getJson("getEmployees.php").then(employees => {
        employees.forEach(employee => {
            let option = document.createElement("option");
            option.value = employee.employeeId;
            option.innerText = `${employee.lastName} ${employee.firstName}`;
            employeeid.append(option);
        });
    });
    employeeid.addEventListener("change", e => {
        if (employeeid.value == 0) return;
        getJson(`getEmployees.php?id=${employeeid.value}`).then(employee => {
            employeesForm.elements["lastName"].value = employee.lastName;
            employeesForm.elements["firstName"].value = employee.firstName;
            employeesForm.elements["extension"].value = employee.extension;
            employeesForm.elements["email"].value = employee.email;
            employeesForm.elements["officeId"].value = employee.officeId;
            employeesForm.elements["reportsTo"].value = employee.reportsTo;
            employeesForm.elements["jobTitle"].value = employee.jobTitle;
        });
    });
    employeesForm.addEventListener("submit", e => {
        e.preventDefault();
        let formData = new FormData(employeesForm);
        let formObj = Object.fromEntries(formData.entries());
        console.log(formObj);
        sendForm(employeesForm.action, employeesForm.method, formObj).then(response => {
            alert(response.message);
        });
    })


    // officeId
    // city
    // phone
    // addressLine1
    // addressLine2
    // state
    // country
    // postalCode
    // territory

    let officeId = document.querySelector("#officeId");
    let officesForm = document.querySelector("#officesform");
    getJson("getOffices.php").then(offices=>{
        offices.forEach(office=>{
            let option = document.createElement("option");
            option.value = office.officeId;
            option.innerText = `${office.country} ${office.city} ${office.addressLine1}`;
            officeId.append(option);
        });
    });
    officeId.addEventListener("change", e=>{
        getJson(`getOffices.php?id=${officeId.value}`).then(office=>{
            officesForm.elements["city"].value = office.city;
            officesForm.elements["phone"].value = office.phone;
            officesForm.elements["addressLine1"].value = office.addressLine1;
            officesForm.elements["addressLine2"].value = office.addressLine2;
            officesForm.elements["state"].value = office.state;
            officesForm.elements["country"].value = office.country;
            officesForm.elements["postalCode"].value = office.postalCode;
            officesForm.elements["territory"].value = office.territory;
        });
    });
    officesForm.addEventListener("submit", e=>{
        e.preventDefault();
        let formData = new FormData(officesForm);
        let formObj = Object.fromEntries(formData.entries());
        console.log(formObj);
        sendForm(officesForm.action, officesForm.method, formObj).then(response => {
            alert(response.message);
        });
    })
}