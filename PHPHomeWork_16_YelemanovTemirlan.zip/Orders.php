<?php 
class Orders{
    public int $orderId; 
    public DateTime $orderDate; 
    public DateTime $requiredDate; 
    public DateTime $shippedDate; 
    public string $status; 
    public string $comments;
    public int $customerId;
    
    public function getOrderId(){
        return $this->orderId;
    }
    public function getOrderDate(){
        return $this->orderDate;
    }

    public function getRequiredDate(){
        return $this->requiredDate;
    }
    public function getShippedDate(){
        return $this->shippedDate;
    }
    public function getStatus(){
        return $this->status;
    }
    public function getComments(){
        return $this->comments;
    }
    public function getCustomerId(){
        return $this->customerId;
    }    
    public function Create($row){
        $this->orderId = $row->orderId;
        $this->orderDate = $row->orderDate;
        $this->requiredDate = $row->requiredDate;
        $this->shippedDate = $row->shippedDate;
        $this->status = $row->status;
        $this->comments = $row->comments;
        $this->customerId = $row->customerId;
    }
}
?>