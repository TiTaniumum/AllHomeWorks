<?php 
class Employees{
    public $employeeId;
    public $name;
    public $jobtitle;
    public function getEmployeeId(){
        return $this->employeeId;
    }
    public function getName(){
        return $this->name;
    }
    public function getJobTitle(){
        return $this->jobtitle;
    }
}
?>