<?php
require_once("Database.php");
class API
{
    public static function getCustomers()
    {
        require_once("Customer.php");
        header("Content-type: application/json; charset=utf-8");
        if (isset($_GET["id"])) {
            $sql = "SELECT * FROM customers WHERE customerId = ?;";
            $customer = Database::getRow($sql, $_GET["id"]);
            echo json_encode($customer, JSON_PRETTY_PRINT);
        } else {
            $sql = "SELECT * FROM customers;";
            $customers = Database::getAll($sql);
            echo json_encode($customers, JSON_PRETTY_PRINT);
        }
    }
    public static function getEmployees()
    {
        require_once("Employees.php");
        header("Content-type: application/json; charset=utf-8");
        if (isset($_GET["id"])) {
            $sql = "SELECT * FROM employees WHERE employeeId = ?;";
            $employee = Database::getRow($sql, $_GET["id"]);
            echo json_encode($employee, JSON_PRETTY_PRINT);
        } else {
            $sql = "SELECT * FROM employees";
            $employees = Database::getAll($sql);
            echo json_encode($employees, JSON_PRETTY_PRINT);
        }
    }

    public static function getProductLines()
    {
        $sql = "SELECT * FROM productLines";
        $employees = Database::getAll($sql);
        header("Content-type: application/json; charset=utf-8");
        echo json_encode($employees, JSON_PRETTY_PRINT);
    }

    public static function getOrders()
    {
        require_once("Orders.php");
        if (isset($_GET["id"])) {
            $sql = "SELECT * FROM orders WHERE orderId = ?;";
            $order = Database::getRow($sql, $_GET["id"]);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($order, JSON_PRETTY_PRINT);
        } else {
            $sql = "SELECT * FROM orders;";
            $orders = Database::getAll($sql);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($orders, JSON_PRETTY_PRINT);
        }
    }
    public static function getPayments()
    {
        require_once("Payments.php");
        if (isset($_GET["id"])) {
            $sql = "SELECT * FROM payments WHERE customerId = ?;";
            $payment = Database::getRow($sql, $_GET["id"]);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($payment, JSON_PRETTY_PRINT);
        } else {
            $sql = "SELECT * FROM payments;";
            $payments = Database::getAll($sql);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($payments, JSON_PRETTY_PRINT);
        }
    }
    public static function getOffices(){
        //require_once("Offices.php");
        header("Content-type: application/json; charset=utf-8");
        if (isset($_GET["id"])){
            $sql = "SELECT * FROM offices WHERE officeId = ?";
            $office = Database::getRow($sql, $_GET["id"]);
            echo json_encode($office, JSON_PRETTY_PRINT);
        }else{
            $sql = "SELECT * FROM offices;";
            $offices = Database::getAll($sql);
            echo json_encode($offices, JSON_PRETTY_PRINT);
        }
    }
    public static function insertCustomer()
    {
        $data = json_decode(file_get_contents("php://input"));

        $sql = "INSERT INTO customers(
            addressLine1,
            addressLine2,
            city,
            contactFirstName,
            contactLastName,
            country,
            customerName,
            phone,
            postalCode,
            salesRepemployeeId,
            state) values(:addressLine1,:addressLine2,:city,:contactFirstName,:contactLastName,:country,:customerName,:phone,:postalCode,:salesRepemployeeId,:state);";

        $array = [];
        $array["addressLine1"] = $data->addressLine1;
        $array["addressLine2"] = $data->addressLine2;
        $array["city"] = $data->city;
        $array["contactFirstName"] = $data->contactFirstName;
        $array["contactLastName"] = $data->contactLastName;
        $array["country"] = $data->country;
        $array["customerName"] = $data->customerName;
        $array["phone"] = $data->phone;
        $array["postalCode"] = $data->postalCode;
        $array["salesRepemployeeId"] = $data->salesRepemployeeId !== "0" ? (int) $data->salesRepemployeeId : null;
        $array["state"] = $data->state;

        Database::insert($sql, $array);

        header("Content-type: application/json; charset=utf-8");
        echo "[]";
    }
    public static function insertOffice()
    {
        $data = json_decode(file_get_contents("php://input"));

        $sql = "INSERT INTO offices(
        officeId,
        city,
        phone,
        addressLine1,
        addressLine2,
        state,
        country,
        postalCode,
        territory) VALUES(
        :officeId,
        :city,
        :phone,
        :addressLine1,
        :addressLine2,
        :state,
        :country,
        :postalCode,
        :territory)";

        $array = [];
        $array["officeId"] = $data->officeId;
        $array["city"] = $data->city;
        $array["phone"] = $data->phone;
        $array["addressLine1"] = $data->addressLine1;
        $array["addressLine2"] = $data->addressLine2;
        $array["state"] = $data->state;
        $array["country"] = $data->country;
        $array["postalCode"] = $data->postalCode;
        $array["territory"] = $data->territory;

        Database::insert($sql, $array);
        header("Content-type: application/json; charset=utf-8");
        echo "[]";
    }
    public static function insertProduct()
    {
        $data = json_decode(file_get_contents("php://input"));
        $sql = "INSERT INTO products(
        productId,
        productName,
        productLine,
        productScale,
        productVendor,
        productDescription,
        quantityInStock,
        buyPrice,
        MSRP)
        values
        (
        :productId,
        :productName,
        :productLine,
        :productScale,
        :productVendor,
        :productDescription,
        :quantityInStock,
        :buyPrice,
        :MSRP
        )";
        $array = [];
        $array["productId"] = $data->productId;
        $array["productName"] = $data->productName;
        $array["productLine"] = $data->productLine;
        $array["productScale"] = $data->productScale;
        $array["productVendor"] = $data->productVendor;
        $array["productDescription"] = $data->productDescription;
        $array["quantityInStock"] = $data->quantityInStock;
        $array["buyPrice"] = $data->buyPrice;
        $array["MSRP"] = $data->MSRP;
        Database::insert($sql, $array);
        header("Content-type: application/json; charset=utf-8");
        echo "[]";
    }

    public static function updateCustomers()
    {
        $data = json_decode(file_get_contents("php://input"));
        $sql = "update customers
        set customerName = :customerName,
        contactLastName = :contactLastName,
        contactFirstName = :contactFirstName,
        phone = :phone,
        addressLine1 = :addressLine1,
        addressLine2 = :addressLine2,
        city = :city,
        state = :state,
        postalCode = :postalCode, 
        country = :country,
        salesRepemployeeId = :salesRepemployeeId,
        creditLimit = :creditLimit
        where customerId = :customerId;";

        // customerId
// customerName
// contactLastName
// contactFirstName
// phone
// addressLine1
// addressLine2
// city
// state
// postalCode
// country
// salesRepemployeeId
// creditLimit

        $arr = [];
        $arr["customerId"] = $data->customerId;
        $arr["customerName"] = $data->customerName == "" ? null : $data->customerName;
        $arr["contactLastName"] = $data->contactLastName == "" ? null : $data->contactLastName;
        $arr["contactFirstName"] = $data->contactFirstName == "" ? null : $data->contactFirstName;
        $arr["phone"] = $data->phone == "" ? null : $data->phone;
        $arr["addressLine1"] = $data->addressLine1 == "" ? null : $data->addressLine1;
        $arr["addressLine2"] = $data->addressLine2 == "" ? null : $data->addressLine2;
        $arr["city"] = $data->city == "" ? null : $data->city;
        $arr["state"] = $data->state == "" ? null : $data->state;
        $arr["postalCode"] = $data->postalCode == "" ? null : $data->postalCode;
        $arr["country"] = $data->country == "" ? null : $data->country;
        $arr["salesRepemployeeId"] = $data->salesRepemployeeId == "" ? null : $data->salesRepemployeeId;
        $arr["creditLimit"] = $data->creditLimit == "" ? null : $data->creditLimit;

        Database::update($sql, $arr);

        header("Content-type: application/json; charset=utf-8");
        echo '{"message": "success"}';
    }

    public static function updateEmployees()
    {
        $data = json_decode(file_get_contents("php://input"));
        $sql = "
        UPDATE employees
        set
lastName = :lastName,
firstName = :firstName,
extension = :extension,
email = :email,
officeId = :officeId,
reportsTo = :reportsTo,
jobTitle = :jobTitle
where employeeId = :employeeId;
        ";
        $arr = [];
        $arr["employeeId"] = $data->employeeId == "" ? null : $data->employeeId;
        $arr["lastName"] = $data->lastName == "" ? null : $data->lastName;
        $arr["firstName"] = $data->firstName == "" ? null : $data->firstName;
        $arr["extension"] = $data->extension == "" ? null : $data->extension;
        $arr["email"] = $data->email == "" ? null : $data->email;
        $arr["officeId"] = $data->officeId == "" ? null : $data->officeId;
        $arr["reportsTo"] = $data->reportsTo == "" ? null : $data->reportsTo;
        $arr["jobTitle"] = $data->jobTitle == "" ? null : $data->jobTitle;

        Database::update($sql, $arr);

        header("Content-type: application/json; charset=utf-8");
        echo '{"message": "success"}';
    }
    public static function updateOffices()
    {
        $data = json_decode(file_get_contents("php://input"));
        $sql = "
        UPDATE offices
        set
        city = :city,
        phone = :phone,
        addressLine1 = :addressLine1,
        addressLine2 = :addressLine2,
        state = :state,
        country = :country,
        postalCode = :postalCode,
        territory = :territory
        WHERE officeId = :officeId
        ";
        $arr = [];
        $arr["officeId"] = $data->officeId == "" ? null: $data->officeId;
        $arr["city"] = $data->city == "" ? null: $data->city;
        $arr["phone"] = $data->phone == "" ? null: $data->phone;
        $arr["addressLine1"] = $data->addressLine1 == "" ? null: $data->addressLine1;
        $arr["addressLine2"] = $data->addressLine2 == "" ? null: $data->addressLine2;
        $arr["state"] = $data->state == "" ? null: $data->state;
        $arr["country"] = $data->country == "" ? null: $data->country;
        $arr["postalCode"] = $data->postalCode == "" ? null: $data->postalCode;
        $arr["territory"] = $data->territory == "" ? null: $data->territory;

        Database::update($sql, $arr);

        header("Content-type: application/json; charset=utf-8");
        echo '{"message": "success"}';
    }
}
?>