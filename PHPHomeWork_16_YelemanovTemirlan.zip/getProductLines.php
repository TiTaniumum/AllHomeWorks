<?php 
require_once("API.php");
API::getProductLines();
?>