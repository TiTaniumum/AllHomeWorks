import java.util.Random;
import java.util.Scanner;

public class Array<T>{
    private Object[] arr;
    private int count;
    public static Scanner scanner = new Scanner(System.in);
    public Array(){
        arr = new Object[10];
        count = 0;
    }
    public Array(int length){
        arr = new Object[length];
        count = 0;
    }
    public Array(T... items){
        arr = new Object[items.length];
        count = 0;
        Add(items);
    }
    // returns initial arr length
    public int Size(){
        return arr.length;
    }
    // returns items count
    public int Count(){
        return count;
    }
    public T Get(int idx) throws IndexOutOfBoundsException{
        if(idx >= arr.length || idx < 0){
            throw new IndexOutOfBoundsException("Array<T> exception: " + idx + " out of bounds! length = " + arr.length);
        }
        return (T)arr[idx];
    }
    public Array<T> Set(T item, int idx)throws IndexOutOfBoundsException{
        if(idx >= count || idx < 0)
            throw new IndexOutOfBoundsException();
        arr[idx] = item;
        return this;
    }
    public Array<T> Add(T... items){
        if(count+items.length> arr.length){
            this.Expand(count+items.length);
        }
        for(int i = 0, j = count;i < items.length && j<arr.length; i++, j++){
            arr[j] = items[i];
            count++;
        }
        return this;
    }
    public Array<T> Add(T item){
        if(count+1 > arr.length)
            this.Expand();
        arr[count] = item;
        count++;
        return this;
    }
    public Array<T> FillByHand(Constructor<T> constructor, Filler<T> filler){
        System.out.println("Type in length: ");
        int length = Integer.parseInt(scanner.nextLine());
        for(int i = 0; i < length; i++){
            System.out.println("[" + i + "]:");
            T item = filler.Fill(constructor.Construct());
            this.Add(item);
        }
        return this;
    }
    // этот метод по сути разрешает наполнить массив как угодно. даже рандомными значениями.
    public Array<T> FillByPattern(Constructor<T> constructor, Filler<T> filler){
        for(int i = count; i < arr.length; i++){
            T item = filler.Fill(constructor.Construct());
            this.Add(item);
        }
        return this;
    }
    //сделал парочку методов которые заполняют на прямую типом Integer
    public static Array<Integer> FillRandom(Array<Integer> arr, int min, int max){
        if(min > max){
            int temp = min;
            min = max;
            max = temp;
        }
        Random random = new Random();
        for(int i = 0; i < arr.Size(); i++){
            int value = random.nextInt(max - min) + min;
            arr.SetItem(value, i);
        }
        arr.SetCount(arr.Size());
        return arr;
    }
    public static Array<Integer> GetRandom(int length, int min,int max)throws Exception{
        if(length<0){
            throw new Exception("length was negative");
        }
        Array<Integer> arr = new Array<Integer>(length);
        if(min > max){
            int temp = min;
            min = max;
            max = temp;
        }
        Random random = new Random();
        for(int i = 0; i < arr.Size(); i++){
            int value = random.nextInt(max - min) + min;
            arr.Add(value);
        }
        return arr;
    }

    public T Min(Comparator<T> comparator){
        T min = (T)arr[0];
        for(int i = 1; i< count; i++){
            if(comparator.Bigger(min, (T)arr[i])){
                min = (T)arr[i];
            }
        }
        return min;
    }
    public T Max(Comparator<T> comparator){
        T max = (T)arr[0];
        for(int i = 1; i< count; i++){
            if(comparator.Lesser(max, (T)arr[i])){
                max = (T)arr[i];
            }
        }
        return max;
    }
    public Array<T> Sort(Comparator<T> comparator, boolean desc){
        if(desc == false){
            for(int i = 0;  i < count ;i++){
                for(int j = 0; j < count-i-1; j++){
                    if(comparator.Bigger((T)arr[j], (T)arr[j+1])){
                        T temp = (T)arr[j];
                        arr[j] = arr[j+1];
                        arr[j+1] = temp; 
                    }
                }
            }
        }else{
            for(int i = 0;  i< count ;i++){
                for(int j = 0; j < count-i-1; j++){
                    if(comparator.Lesser((T)arr[j], (T)arr[j+1])){
                        T temp = (T)arr[j];
                        arr[j] = arr[j+1];
                        arr[j+1] = temp;
                    }
                }
            }
        }
        return this;
    }
    public int BinarySearch(Comparator<T> comparator,Validator<T> validator, T value){
        Sort(comparator, false);
        int left = 0;
        int right = count-1;
        int mid = right/2;
        while(!validator.Validate((T)arr[mid], value)){
            if(left+1 == right || left == right){
                if(validator.Validate((T)arr[left], value)){
                    return left;
                }else if(validator.Validate((T)arr[right], value)){
                    return right;
                }
                else{
                    return -1;
                }
            }
            if(comparator.Bigger((T)arr[mid], value)){
                right = mid - 1;
            }else{
                left = mid + 1;
            }
            mid = (left+right)/2;
        }
        return mid;
    }
    private Array<T> Resize(int length){
        Object[] newArr = new Object[length];
        if(length > arr.length)
            length = arr.length;
        for(int i = 0; i < length; i++){
            newArr[i] = arr[i];
        }
        arr = newArr;
        return this;
    }
    private Array<T> Expand(){
        int newLength = (int)(arr.length*1.6f);
        return this.Resize(newLength);
    }
    private Array<T> Expand(int itemCount){
        int newLength = (int)(itemCount*1.6f);
        return this.Resize(newLength);
    }
    private Array<T> SetItem(T item, int idx)throws IndexOutOfBoundsException{
        if(idx >= arr.length || idx < 0){
            throw new IndexOutOfBoundsException("Array<T> exception: " + idx + " out of bounds! length = " + arr.length);
        }
        arr[idx] = item;
        return this;
    }
    private Array<T> SetCount(int count){
        this.count = count;
        return this;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < count; i++){
            sb.append("[");
            sb.append(i);
            sb.append("]:");
            sb.append(((T)arr[i]).toString());
            sb.append("\n");
        }
        return sb.toString();
    }
}
