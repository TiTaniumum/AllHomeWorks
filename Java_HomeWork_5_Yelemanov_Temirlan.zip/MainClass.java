import java.util.Random;

public class MainClass{
    public static void main(String[] args)throws Exception {
        Demo5();
    }
    // Min() Sort()
    public static void Demo1()throws Exception{
        Array<Integer> arr = Array.GetRandom(10, -1000, 1000);
        System.out.println(arr);
        Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public boolean Bigger(Integer item1,Integer item2) {
                return item1 > item2;
            }
            @Override
            public boolean Lesser(Integer item1, Integer item2) {
                return item1 < item2;
            }
        };
        int min = arr.Min(comparator);
        System.out.println("min: " + min); 

        arr.Sort(comparator, false);
        System.out.println(arr);
    }
    // заполнение с воодом
    public static void Demo2()throws Exception{
        Array<Integer> arr = new Array<>();
        Constructor<Integer> constructor = new Constructor<Integer>() {
            @Override
            public Integer Construct() {
                return 0;
            }
        };
        Filler<Integer> filler = new Filler<Integer>() {
            @Override
            public Integer Fill(Integer item) {
                return Integer.parseInt(Array.scanner.nextLine());
            }
        };
        arr.FillByHand(constructor, filler);
        System.out.println(arr);
    }
    // заполнение с воодом
    public static void Demo3()throws Exception{
        Array<Person> arr = new Array<>();
        Constructor<Person> constructor = new Constructor<Person>() {
            @Override
            public Person Construct() {
                return new Person(0, "");
            }
        };
        Filler<Person> filler = new Filler<Person>() {
            @Override
            public Person Fill(Person item) {
                System.out.print("Type in Name: ");
                item.Name = Array.scanner.nextLine();
                System.out.print("Type in Age: ");
                item.Age = Integer.parseInt(Array.scanner.nextLine());
                return item;
            }
        };
        arr.FillByHand(constructor, filler);
        System.out.println(arr);
    }
    // заполнение рандомными числами
    public static void Demo4()throws Exception{
        Array<Person> arr = new Array<>();
        Constructor<Person> constructor = new Constructor<Person>() {
            @Override
            public Person Construct() {
                return new Person();
            }
        };
        Filler<Person> filler = new Filler<Person>() {
            @Override
            public Person Fill(Person item) {
                Random random = new Random();
                item.Age = random.nextInt(100);
                item.Name = GenerateString(random.nextInt(12)+3);
                return item;
            }
        };
        arr.FillByPattern(constructor, filler);
        System.out.println(arr);
    }
    //binary search
    public static void Demo5()throws Exception{
        Array<Integer> arr = new Array<>();
        arr.Add(1);
        arr.Add(2);
        arr.Add(3);
        arr.Add(4);
        arr.Add(5);
        System.out.println(arr);
        Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public boolean Bigger(Integer item1,Integer item2) {
                return item1 > item2;
            }
            @Override
            public boolean Lesser(Integer item1, Integer item2) {
                return item1 < item2;
            }
        };
        Validator<Integer> validator = new Validator<Integer>() {
            @Override
            public boolean Validate(Integer item1, Integer item2) {
                return item1 == item2;
            }
        };
        int value = 2;
        int idx = arr.BinarySearch(comparator, validator, value);
        System.out.println("INDEX OF " + value + " is  " + idx);


        arr = Array.GetRandom(20, 0, 20);
        value = 13;
        idx = arr.BinarySearch(comparator, validator, value);
        System.out.println(arr);
        System.out.println("INDEX OF " + value + " is  " + idx);
    }
    public static String GenerateString(int length){
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        int min = 97;
        int max = 122;
        for(int i = 0; i<length ;i++){
            sb.append((char)(random.nextInt(max - min) + min));
        }
        return sb.toString();
    }
    public static void Chars(){
        for(char i = 0; i< 256; i++){
            System.out.println("["+(int)i+"]: "+i);
        }
    }
}