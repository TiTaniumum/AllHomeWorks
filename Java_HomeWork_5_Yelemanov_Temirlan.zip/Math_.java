public interface Math_<T> {
    T Plus(T item1, T item2);
    T Minus(T item1, T item2);
    T Multiply(T item1, T item2);
    T Divide(T item1, T item2);
    T Divide(T item1, int item2);
}
