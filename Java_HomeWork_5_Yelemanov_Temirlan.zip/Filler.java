public interface Filler<T> {
    T Fill(T item);
}
