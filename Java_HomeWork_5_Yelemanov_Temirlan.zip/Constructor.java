public interface Constructor<T> {
    T Construct();
}
