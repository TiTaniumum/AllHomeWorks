public class Person {
    public int Age;
    public String Name;
    public Person(){
        Age = 0;
        Name = "";
    }
    public Person(int Age, String Name){
        this.Age = Age;
        this.Name = Name;
    }
    @Override
    public String toString() {
        return "(Person) => Name: " + Name + " Age: " + Age;
    }
}
