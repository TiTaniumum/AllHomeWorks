public interface Comparator<T> {
    boolean Bigger(T item1,T item2);
    boolean Lesser(T item1,T item2);
}
