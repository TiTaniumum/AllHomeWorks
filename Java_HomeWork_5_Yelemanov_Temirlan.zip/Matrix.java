public class Matrix<T> {
    private Object[][] arr;
    public Matrix(int lengthx, int lengthy){
        arr = new Object[lengthy][];
        for(int i = 0; i< lengthy; i++){
            arr[i] = new Object[lengthx];
        }
    }
    public Matrix<T> FillByPattern(Constructor<T> constructor, Filler<T> filler){
        for(int i = 0; i < arr.length; i++){
            for(int j = 0; i <arr[0].length; i++){
                T item = filler.Fill(constructor.Construct());
                arr[i][j] = item;
            }
        }
        return this;
    }
    public T Min(Comparator<T> comparator){
        T min = (T)arr[0][0];
        for(int i = 0; i< arr.length; i++){
            for(int j = 0; j < arr[0].length; i++){
                if(comparator.Bigger(min, (T)arr[i][j])){
                    min = (T)arr[i][j];
                }
            }
        }
        return min;
    }
    public T Max(Comparator<T> comparator){
        T max = (T)arr[0][0];
        for(int i = 0; i< arr.length; i++){
            for(int j = 0; j < arr[0].length; j++){
                if(comparator.Lesser(max, (T)arr[i][j])){
                    max = (T)arr[i][j];
                }
            }
        }
        return max;
    }
    public Matrix<T> Plus(Matrix<T> matrix, Math_<T> math){
        if(matrix.arr.length != arr.length || matrix.arr[0].length != arr[0].length){
            return null;
        }
        Matrix<T> newMatrix = new Matrix<T>(arr.length, arr[0].length);
        for(int i = 0; i < arr.length; i++){
            for(int j = 0; j < arr[0].length; j++){
                newMatrix.arr[i][j] = math.Plus((T)arr[i][j], (T)matrix.arr[i][j]);
            }
        }
        return newMatrix;
    }
    public Matrix<T> Multiply(Matrix<T> matrix, Math_<T> math){
        if(arr[0].length != matrix.arr.length){
            return null;
        }
        Matrix<T> newMatrix = new Matrix<>(arr.length, matrix.arr[0].length);
        for(int i = 0; i < newMatrix.arr.length; i++){
            for(int j = 0; j < newMatrix.arr[0].length; i++){
                Object[] elements =  new Object[matrix.arr.length];
                for(int k = 0; k < matrix.arr.length; k++){
                    elements[k] = math.Multiply((T)arr[i][k], (T)matrix.arr[k][j]);
                }
                T element = (T)elements[0];
                for(int k = 1; k < elements.length; k++){
                    element = math.Plus(element, (T)elements[k]);
                }
                newMatrix.arr[i][j] = element;
            }
        }
        return newMatrix;
    }
    public T Avg(Math_<T> math){
        T element = (T)arr[0][0];
        for(int i = 1; i < arr[0].length; i++){
            element = math.Plus(element, (T)arr[0][i]);
        }
        for(int i = 1; i < arr.length; i++){
            for(int j = 0; j < arr[0].length; j++){
                element = math.Plus(element, (T)arr[i][j]);
            }
        }
        element = math.Divide(element, arr.length*arr[0].length);
        return element;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i = 0; i< arr.length; i++){
            sb.append("[");
            for(int j = 0; j < arr[0].length;j++){
                sb.append(((T)arr[i][j]).toString());
                sb.append(",");
            }
            sb.deleteCharAt(sb.length()-1);
            sb.append("]\n");
        }
        sb.append("]");
        return sb.toString();
    }
}
