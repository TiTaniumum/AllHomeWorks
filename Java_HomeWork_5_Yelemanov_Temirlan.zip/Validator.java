public interface Validator<T> {
    boolean Validate(T item1, T item2);
}
