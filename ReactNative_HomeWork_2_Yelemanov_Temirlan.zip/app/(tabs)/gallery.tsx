import { View, Text,StyleSheet, Image} from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
import { ImageBackground } from 'react-native';
import { useState } from 'react';
import { Dimensions } from 'react-native';

const images = [
    {uri: 'https://cdnb.artstation.com/p/assets/images/images/076/135/173/large/philipp-a-urlich-cpncept659-b.jpg?1716276169'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/076/135/014/large/philipp-a-urlich-cpncept658-2d.jpg?1716275856'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/075/839/256/large/philipp-a-urlich-cpncept655.jpg?1715585752'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/075/672/798/large/philipp-a-urlich-cpncept654.jpg?1715152169'},
    {uri: 'https://cdnb.artstation.com/p/assets/images/images/075/596/807/large/philipp-a-urlich-cpncept653d.jpg?1714987431'},
    {uri: 'https://cdnb.artstation.com/p/assets/images/images/075/101/301/large/philipp-a-urlich-cpncept650-11.jpg?1713772714'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/075/076/954/large/philipp-a-urlich-cpncept649.jpg?1713706583'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/075/045/122/large/philipp-a-urlich-cpncept648-2.jpg?1713606469'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/074/975/310/large/philipp-a-urlich-cpncept647.jpg?1713425721'},
    {uri: 'https://cdna.artstation.com/p/assets/images/images/074/901/310/large/philipp-a-urlich-cpncept619-pass.jpg?1713259711'},
];

const WindowSize = Dimensions.get('window');

function ForEachImage(item:{uri: string}){
    const [imgSize, setImgSize] = useState({width:0, height:0});

    Image.getSize(item.uri, (width,height)=>{setImgSize({width,height})}, (error)=>{console.error("couldn't load image!")})

    let propotion = imgSize.width / (WindowSize.width*0.9)
    imgSize.height /= propotion;

    return <><ImageBackground source={item} style={[{ height: imgSize.height },styles.picture]} resizeMode='stretch' /> <View style={styles.space}></View></>
}

export default function Gallery() {
    return <ScrollView style={styles.gallery}>
        {images.map(ForEachImage)}
    </ScrollView>
}

const styles = StyleSheet.create({
    gallery:{
        width: '100%',
        padding: '5%',
    },
    picture:{
        width:'100%',
    },
    space: {
        width: '100%',
        height: 10,
    }
});