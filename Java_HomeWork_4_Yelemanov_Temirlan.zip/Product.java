public class Product extends Money{
    private String productName;
    private int discount;
    public Product(int dolor, int cents, String productName, int discount) {
        super(dolor,cents);
        this.productName = productName;
        this.discount = discount;
    }
    public String getProductName() {
        return productName;
    }
    public int getDiscount() {
        return discount;
    }
    public void setDiscount(int discount) {
        this.discount = discount;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    @Override
    public int getDolor() {
        return super.getDolor()*discount;
    }
    @Override
    public int getCents() {
        return super.getCents()*discount;
    }
}
