
public class MainClass{
    public static void main(String[] args) {
        IMath math = new IMath() {
            public int Max(int[] arr){
                int max = arr[0];
                for(int num : arr){
                    if(num>max){
                        max = num;
                    } 
                }
                return max;
            }
            public int Min(int[]arr){
                int min = arr[0];
                for(int num : arr){
                    if(num<min){
                        min = num;
                    } 
                }
                return min;
            }
            public float Avg(int[]arr){
                float sum = 0;
                for(int num: arr){
                    sum+=num;
                }
                return sum/arr.length;
            }
        };
        int[] arr = {1,2,3,4,5,5,6,7};
        System.out.println(math.Avg(arr));
    }
}