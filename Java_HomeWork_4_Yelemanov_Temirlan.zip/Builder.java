public class Builder extends Human {
    private boolean isBuilding;
    
    public Builder() {
        super();
    }
    public Builder(String name, int age, boolean isBuilding){
        super(name, age);
        this.isBuilding = isBuilding;
    }
    public boolean getIsBuilding(){
        return isBuilding;
    }
    public void setIsBuilding(boolean isBuilding){
        this.isBuilding = isBuilding;
    }
    public void Build(){
        System.out.println("Building building");
    }
}
