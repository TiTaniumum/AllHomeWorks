public class Sailor extends Human {
    private int vitaminCLevel;
    public Sailor() {
        super();
    }
    public Sailor(String name, int age, int vitaminCLevel){
        super(name, age);
        this.vitaminCLevel = vitaminCLevel;
    }
    public int getVitaminCLevel() {
        return vitaminCLevel;
    }
    public void setVitaminCLevel(int vitaminCLevel) {
        this.vitaminCLevel = vitaminCLevel;
    }

    public void SailAway(){
        System.out.println("On the boat");
    }
    public void GoOnLand(){
        System.out.println("YOHOHO");
    }
}

