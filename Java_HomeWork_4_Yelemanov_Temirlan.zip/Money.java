// апрограммируйте класс Money (объект класса оперирует одной валютой) для работы с деньгами.
// В классе должны быть предусмотрены поле для хранения целой части денег (доллары, евро, гривны и т.д.) и поле 
// для хранения копеек (центы, евроценты, копейки и т.д.).
// Реализовать методы для вывода суммы на экран, задания значений для частей. 
// На базе класса Money создать класс Product для работы 
// с продуктом или товаром. Реализовать метод, позволяющий уменьшить цену на заданное число.
// Для каждого из классов реализовать необходимые 
// методы и поля.
public class Money {
    private int dolor;
    private int cents;
    public Money(){
        
    }
    public Money(int dolor, int cents){
        this.dolor = dolor;
        this.cents = cents;
    }
    public int getCents() {
        return cents;
    }
    public int getDolor() {
        return dolor;
    }
    public void setCents(int cents) {
        this.cents = cents;
    }
    public void setDolor(int dolor) {
        this.dolor = dolor;
    }
    public void Display(){
        System.out.println("Dolors: "+dolor + " Cents: " + cents);
    }
}
