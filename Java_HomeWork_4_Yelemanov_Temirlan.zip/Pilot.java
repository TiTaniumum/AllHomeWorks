public class Pilot extends Human {
    private int flightExperience;
    public Pilot() {
        super();
    }
    public Pilot(String name, int age, int flightExperience){
        super(name, age);
        this.flightExperience = flightExperience;
    }
    public int getFlightExperience() {
        return flightExperience;
    }
    public void setFlightExperience(int flightExperience) {
        this.flightExperience = flightExperience;
    }
    public void Fly(){
        System.out.println("Flying in the skys");
    }
    public void Land(){
        System.err.println("Landing on earth");
    }
}
