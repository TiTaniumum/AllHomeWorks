﻿#pragma once
using namespace std;



int knightMovesWithOccupied(int x, int y, int arr[]) {
  int cnt = 0;
  if (arr[y + (x * 10)] == -1) return -1;

  if (x + 2 < 8 && y + 1 < 8 && arr[y + 1 + (x * 10) + 20] != -1) cnt++;
  if (x + 2 < 8 && y - 1 >= 0 && arr[y - 1 + (x * 10) + 20] != -1) cnt++;
  if (x - 2 >= 0 && y + 1 < 8 && arr[y + 1 + (x * 10) - 20] != -1) cnt++;
  if (x - 2 >= 0 && y - 1 >= 0 && arr[y - 1 + (x * 10) - 20] != -1) cnt++;
  if (y + 2 < 8 && x + 1 < 8 && arr[y + 2 + (x * 10) + 10] != -1) cnt++;
  if (y + 2 < 8 && x - 1 >= 0 && arr[y + 2 + (x * 10) - 10] != -1) cnt++;
  if (y - 2 >= 0 && x + 1 < 8 && arr[y - 2 + (x * 10) + 10] != -1) cnt++;
  if (y - 2 >= 0 && x - 1 >= 0 && arr[y - 2 + (x * 10) - 10] != -1) cnt++;
  return cnt;
}
// ▓ 178
// ░ 176
void printLine(int i, int length) {
  if (i % 2 == 1)
    for (size_t j = 1; j <= length; j++)
    {
      if (j % 2 == 1) cout << char(178) << char(178) << char(178) << char(178) << char(178) << char(178);
      else cout << char(176) << char(176) << char(176) << char(176) << char(176) << char(176);
    }
  else
    for (size_t j = 1; j <= length; j++)
    {
      if (j % 2 == 1)cout << char(176) << char(176) << char(176) << char(176) << char(176) << char(176);
      else cout << char(178) << char(178) << char(178) << char(178) << char(178) << char(178);
    }
  cout << "\n";
}

void print(int i, int x, int y) {
  if (x % 2 == 1)
    if (y % 2 == 1) cout << char(178) << char(178) << setw(2) << i << char(178) << char(178);
    else cout << char(176) << char(176) << setw(2) << i << char(176) << char(176);
  else
    if (y % 2 == 1) cout << char(176) << char(176) << setw(2) << i << char(176) << char(176);
    else cout << char(178) << char(178) << setw(2) << i << char(178) << char(178);
}

void problem1() {
  auto t1 = chrono::high_resolution_clock::now();
  const int length = 8;
  const int length1 = 78;
  int arr[length1]{};

  for (size_t i = 0, j = 0; i < length; i++, j++)
  {
    arr[j + (i * 10)] = -1;
  }

  for (size_t i = 0; i < length; i++)
  {
    for (size_t j = 0; j < length; j++)
    {
      arr[j + (i * 10)] = knightMovesWithOccupied(i, j, arr);
    }
  }
  auto t2 = chrono::high_resolution_clock::now();
  cout << fixed;
  cout << "duration: " << (double)(t2 - t1).count() / 1'000'000'000 << " sec\n";
  cout << endl;
  for (size_t i = 0; i < length; i++)
  {
    printLine(i + 1, length);
    for (size_t j = 0; j < length; j++)
    {
      print(arr[j + (i * 10)], i + 1, j + 1);
    }
    cout << "\n";
    printLine(i + 1, length);
  }
}