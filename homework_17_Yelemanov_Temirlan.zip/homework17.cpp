﻿#include <iostream>
#include <chrono>
#include <iomanip>
#include "problem1.h"
using namespace std;

int main()
{
  problem1(); // knight moves with occupied
  cout << "\nend! . . . . . . . . ..\n";
}