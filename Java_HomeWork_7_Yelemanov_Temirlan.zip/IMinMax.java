import java.util.ArrayList;

@FunctionalInterface
public interface IMinMax<T> {
    T minmax(ArrayList<T> list);
}