import java.time.LocalDate;

@FunctionalInterface
public interface IDayOfWeek {
    String dayofweek(LocalDate date);   
}
