import java.util.ArrayList;

@FunctionalInterface
public interface IListManipulations<T, J> {
    T calc(ArrayList<J> list, J obj);
}
