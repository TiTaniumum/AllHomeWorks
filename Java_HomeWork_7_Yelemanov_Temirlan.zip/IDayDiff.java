import java.time.LocalDate;

@FunctionalInterface
public interface IDayDiff {
    long dayDiff(LocalDate date1, LocalDate date2);
}
