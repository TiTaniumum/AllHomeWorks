import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;

public class MainClass{
    public static void main(String[] args) {
        Demo1();
        Demo2();
        Demo3();
        Demo4();
    }
    @SuppressWarnings("deprecation")
    public static void Demo1(){
        Task1((date)->{int year = date.getYear(); return year % 4 == 0 && year % 100 != 0 || year % 400 == 0;}, Date.valueOf("2024-04-28"));
        Task2((date1,date2)->ChronoUnit.DAYS.between(date1, date2),LocalDate.of(2024, 3, 4), LocalDate.of(2024,04,28));
        Task3((date1,date2)->ChronoUnit.DAYS.between(date1, date2),LocalDate.of(2024, 3, 4), LocalDate.of(2024,04,28));
        Task4(date->date.getDayOfWeek().toString(),LocalDate.of(2024, 4, 28));
    }
    public static void Demo2(){
        Task5((f1, f2)->{
            Fraction result;
            if(f1.denominator != f2.denominator){
                result = new Fraction(f1.numerator * f2.denominator + f1.denominator * f2.numerator, f1.denominator * f2.denominator);
            }else{
                result = new Fraction(f1.numerator + f2.numerator, f1.denominator);
            }
            return result;
        },new Fraction(5, 3),new Fraction(6, 5));

        Task6((f1, f2)-> {
            Fraction result;
            if(f1.denominator != f2.denominator){
                result = new Fraction(f1.numerator * f2.denominator - f1.denominator * f2.numerator, f1.denominator * f2.denominator);
            }else{
                result = new Fraction(f1.numerator - f2.numerator, f1.denominator);
            }
            return result;
        },new Fraction(1, 2), new Fraction(2, 2));

        Task7((f1, f2)->{
            return new Fraction(f1.numerator * f2.numerator, f1.denominator * f2.denominator);
        },new Fraction(3,4), new Fraction(5, 8));

        Task8((f1,f2)->{
            return new Fraction(f1.numerator * f2.denominator, f1.denominator * f2.numerator);
        },new Fraction(5,6),new Fraction(6,5));
    }

    public static void Demo3(){
        Task9((list)->{int n = list.get(0); for(Integer num : list){n = n<num ? num: n;} return n;}, new ArrayList<>(Arrays.asList(1,2,8,4,5,6)));
    }

    public static void Demo4(){
        Task10((list, num)->{
            for(Integer n : list){
                if(n == num) return true;
            }
            return false;
        },new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6)), 3);

        // мне дальше лень было делать :(
    }

    public static void Task1(ILeapYearCalculatable leap, Date date){
        System.out.println(date +" is leap year: " + leap.IsLeapYear(date));
    }
    public static void Task2(IDayDiff iDayDiff, LocalDate date1, LocalDate date2){
        System.out.println( "Difference between "+date1+" and "+ date2+" = "+ iDayDiff.dayDiff(date1, date2) + " days");
    }
    public static void Task3(IDayDiff iDayDiff, LocalDate date1, LocalDate date2){
        System.out.println( "Difference between "+date1+" and "+ date2+" = "+ iDayDiff.dayDiff(date1, date2)/7 + " weeks");
    }
    public static void Task4(IDayOfWeek iDayOfWeek, LocalDate date1){
        System.out.println(date1+" -> "+iDayOfWeek.dayofweek(date1));
    }
    public static void Task5(ICalculatableFraction Icalculatable, Fraction f1, Fraction f2){
        System.out.println(f1+" + "+ f2 + " = " + Icalculatable.calc(f1, f2));
    }
    public static void Task6(ICalculatableFraction Icalculatable, Fraction f1, Fraction f2){
        System.out.println(f1+" - "+ f2 + " = " + Icalculatable.calc(f1, f2));
    }
    public static void Task7(ICalculatableFraction Icalculatable, Fraction f1, Fraction f2){
        System.out.println(f1+" * "+ f2 + " = " + Icalculatable.calc(f1, f2));
    }
    public static void Task8(ICalculatableFraction Icalculatable, Fraction f1, Fraction f2){
        System.out.println(f1+" / "+ f2 + " = " + Icalculatable.calc(f1, f2));
    }
    public static void Task9(IMinMax<Integer> iMinMax, ArrayList<Integer> list){
        System.out.println(iMinMax.minmax(list));
    }
    public static void Task10(IListManipulations<Boolean, Integer> manipulations, ArrayList<Integer> list, Integer num){
        System.out.println(manipulations.calc(list, num));
    }
}