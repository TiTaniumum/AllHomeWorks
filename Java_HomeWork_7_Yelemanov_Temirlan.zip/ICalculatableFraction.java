@FunctionalInterface
public interface ICalculatableFraction {
    Fraction calc(Fraction f1, Fraction f2);
}
