import java.sql.Date;

@FunctionalInterface
public interface ILeapYearCalculatable {
    boolean IsLeapYear(Date date);
}
