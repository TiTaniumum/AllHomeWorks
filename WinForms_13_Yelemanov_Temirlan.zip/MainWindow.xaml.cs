﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace winformsWPF13
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        enum Direction
        {
            Down = 0,
            Left = 1,
            Right = 2,
            Up = 3,
        }
        private Timer timer;
        public MainWindow()
        {
            InitializeComponent();
            CreateField();
            CreateHero();
            timer = new Timer(HeroAnimation);
            timer.Change(100, 100);
            //this.WindowState = WindowState.Maximized;
            //this.WindowStyle = WindowStyle.None;
        }

        // для подложки
        private Image image;
        private ImageBrush imageBrush;
        private double ScaleX, ScaleY;  // масштабные коэффициенты
                                        // для игрока
        private string heroFileImg = "5DU3U.png";
        private ImageBrush heroImgBrush;
        private Rectangle heroImg;
        //private Image      heroImg;
        private Direction heroDir = Direction.Down;
        private int heroAnimFrame = 0;
        // для противника


        private double stepX = 0, stepY = 0;
        private int stepCount = 0;
        private void CreateField()
        {
            /*
            //string filename =
            //  @"C:\Users\Касеновж\source\repos\First\TopDown\bin\Debug\clipart-field.png";
            BitmapImage bmp = new BitmapImage();
            bmp.BeginInit();
            //bmp.UriSource = new Uri(filename);
            bmp.UriSource = new Uri("clipart-field.png", UriKind.Relative);
            bmp.EndInit();
            image = new Image();
            image.Source = bmp;

            ImageBrush imageBrush = new ImageBrush(bmp);
            //imageBrush.ImageSource = bmp;
            canvas.Background = imageBrush;
            */
            image = new Image
            {
                Source =
              new BitmapImage(
                new Uri("clipart-field.png", UriKind.Relative)
              )
            };
            imageBrush = new ImageBrush();
            imageBrush.Stretch = Stretch.None;
            imageBrush.ImageSource = image.Source; // bmp
            imageBrush.AlignmentX = AlignmentX.Left;
            imageBrush.AlignmentY = AlignmentY.Top;

            //Viewbox vb = new Viewbox();
            double x = 0, y = 0;
            ScaleX = 1.0 / imageBrush.ImageSource.Width;
            ScaleY = 1.0 / imageBrush.ImageSource.Height;
            //double width = canvas.ActualWidth * ScaleX;
            //double height = canvas.ActualHeight * ScaleY;
            //imageBrush.Viewbox = new Rect(x,y,width,height);
            //canvas.Background = imageBrush;
            Scrolling(x, y);
        }

        private void CreateHero()
        {
            heroImgBrush = new ImageBrush
            {
                ImageSource = new BitmapImage(
                new Uri(heroFileImg, UriKind.Relative)
              )
            };
            heroImgBrush.Stretch = Stretch.None;
            heroImgBrush.Viewbox =
              new Rect(0.0, 0.0, 0.25, 0.25);

            heroImg = new Rectangle
            {
                Width  = heroImgBrush.ImageSource.Width / 4,
                Height = heroImgBrush.ImageSource.Height / 4,
                Fill   = heroImgBrush,
            };

            //heroImg.Fill = heroImgBrush;
            canvas.Children.Add(heroImg); // добавляем в контейнер Canvas
                                          // центрирование героя в главном окне
            Canvas.SetLeft(heroImg,
              (this.Width - heroImg.Width) / 2);
            Canvas.SetTop(heroImg,
              (this.Height - heroImg.Height) / 2);

        } // void CreateHero()

        private void HeroAnimation(object state)
        {
            Timer tm = state as Timer;
            // приостановить таймер
            //tm.Change(0, 0);
            tm.Change(Timeout.Infinite, 0);

            // 1 вариант
            //heroAnimFrame++;
            //if (heroAnimFrame >= 4) heroAnimFrame = 0;
            // 2 вариант
            //heroAnimFrame = (heroAnimFrame + 1) % 4;
            // 3 вариант
            heroAnimFrame = (heroAnimFrame + 1) & 3; // битовое макирование, & - побитовое И (AND)

            //Dispatcher.Invoke ( () => { HeroSetFrame(); } );
            Dispatcher.Invoke(
                new Action<MainWindow>(
                  delegate (MainWindow x)
                  {
                      x.HeroSetFrame();
                      MoveHero(); ///////////////////////////////////////////////////////////////// главное изменение тут
                  }
                ),
                this // x = this
              );
            tm.Change(200, 100); // запуск таймера
        }


        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            double x = imageBrush.Viewbox.X;
            double y = imageBrush.Viewbox.Y;
            double dx = ScaleX * 10; // на 10 пикселов по X
            double dy = ScaleY * 10; // на 10 пикселов по Y
            if (e.Key == Key.Up) { y -= dy; }
            else if (e.Key == Key.Down) { y += dy; }
            else if (e.Key == Key.Left) { x -= dx; }
            else if (e.Key == Key.Right) { x += dx; }
            if (x >= 0 && y >= 0 &&
              x < 1.0 - imageBrush.Viewbox.Width &&
              y < 1.0 - imageBrush.Viewbox.Height)
            {
                Scrolling(x, y);
            }
        }

        private void canvas_MouseMove(object sender,
          MouseEventArgs e)
        {
            Point pt = e.GetPosition(sender as Canvas);
            double x = Canvas.GetLeft(heroImg) + heroImg.Width/2;
            double y = Canvas.GetTop(heroImg)  + heroImg.Height/2;
            Direction dir;
            if (Math.Abs(pt.X - x) < Math.Abs(pt.Y - y))
            { // по вертикали
                if (pt.Y < y) { dir = Direction.Up; } // вверх
                else { dir = Direction.Down; } // вниз
            }
            else
            { // по горизонтали
                if (pt.X < x) { dir = Direction.Left; } // влево
                else { dir = Direction.Right; } // вправо
            }
            if (dir != heroDir)
            {
                heroDir = dir;
                heroAnimFrame = 0;
                HeroSetFrame();
            }
        }
        private void HeroSetFrame()
        {
            heroImgBrush.Viewbox = new Rect(
              (double)heroAnimFrame * 0.25,
              (double)heroDir  * 0.25,
              0.25, 0.25);
        }

        private void canvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Point mousePoint = e.GetPosition(canvas);
            double dx, dy;
            dx = (mousePoint.X-Canvas.GetLeft(heroImg))/10;
            dy = (mousePoint.Y-Canvas.GetTop(heroImg))/10;
            //MessageBox.Show(mousePoint.ToString() + " " + Canvas.GetLeft(heroImg) + " " + Canvas.GetTop(heroImg));
            //MessageBox.Show((mousePoint.X - Canvas.GetLdeft(heroImg)).ToString() +" "+ (mousePoint.Y - Canvas.GetTop(heroImg)).ToString());
            //MessageBox.Show(dx + " " + dy);
            stepCount = 0;
            stepX = dx;
            stepY = dy;
        }

        private void Scrolling(double x, double y)
        {
            double width = canvas.ActualWidth * ScaleX;
            double height = canvas.ActualHeight * ScaleY;
            imageBrush.Viewbox = new Rect(x, y, width, height);
            canvas.Background = imageBrush;
        }
        private void Scrolling()
        {
            double heroX = Canvas.GetLeft(heroImg); 
            double heroY = Canvas.GetTop(heroImg);
            double left = canvas.ActualWidth/5;
            double top = canvas.ActualHeight/5;
            double right = left*4;
            double bottom = top*4;
            double backgroundX = imageBrush.Viewbox.X;
            double backgroundY = imageBrush.Viewbox.Y;
            
            bool isChanged = false;
            if(heroX < left)
            {
                backgroundX += (heroX - left)*ScaleX;
                Canvas.SetLeft(heroImg, left);
                isChanged = true;
            }
            if(heroX > right)
            {
                backgroundX += (heroX - right) * ScaleX;
                Canvas.SetLeft(heroImg, right);
                isChanged = true;
            }
            if (heroY < top)
            {
                backgroundY += (heroY - top)* ScaleY;
                Canvas.SetTop(heroImg, top);
                isChanged = true;
            }
            if (heroY > bottom)
            {
                backgroundY += (heroY - bottom)*ScaleY;
                Canvas.SetTop(heroImg, bottom);
                isChanged = true;
            }
            if (isChanged) Scrolling(backgroundX, backgroundY);
        }

        private void MoveHero()
        {
            double heroX = Canvas.GetLeft(heroImg);
            double heroY = Canvas.GetTop(heroImg);
            if (stepCount <10)
            {
                Canvas.SetLeft(heroImg, heroX + stepX);
                Canvas.SetTop(heroImg, heroY + stepY);
                stepCount++;
                Scrolling();
            }
        }
    }
}
