﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace winformsWPF9
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private List<Color> colors = new List<Color>
            {
                Colors.Navy,
                Colors.Blue,
                Colors.Aqua,
                Colors.Teal,
                Colors.Olive,
                Colors.Green,
                Colors.Lime,
                Colors.Yellow,
                Colors.Purple,
                Colors.Red,
                Colors.Orange,
                Colors.Maroon,
                Colors.Fuchsia,
                Colors.Silver,
                Colors.Gray,
                Colors.White,
                Colors.Black,
            };
        private List<string> colorNames = new List<string>
        {
            "Navy",
            "Blue",
            "Aqua",
            "Teal",
            "Olive",
            "Green",
            "Lime",
            "Yellow",
            "Purple",
            "Red",
            "Orange",
            "Maroon",
            "Fuchsia",
            "Silver",
            "Gray",
            "White",
            "Black",
        };
        private void Window_Initialized(object sender, EventArgs e)
        {
            for (int i = 0; i<colors.Count; i++)
            {
                Button btn = new Button();
                btn.Foreground = new SolidColorBrush(colors[i]);
                btn.Margin = new Thickness(5, 5, 5, 5);
                btn.Content = colorNames[i].ToString();
                wrapPanelButtons.Children.Add(btn);
            }
        }
    }
}
