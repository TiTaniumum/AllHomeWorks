export interface Post{
    id: number
    title: string,
    body: string,
    author: string,
    time: string,
}