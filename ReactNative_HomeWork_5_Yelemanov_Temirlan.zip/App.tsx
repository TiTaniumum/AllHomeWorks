import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";

import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Auth from "./pages/Auth";
import Home from "./pages/Home";
import Details from "./pages/Details";
import { ContextProvider } from "./ContextProvider";

const RootStack = createNativeStackNavigator();

export default function App() {
  return (
    <ContextProvider>
      <NavigationContainer>
        <RootStack.Navigator>
          <RootStack.Group>
            <RootStack.Screen
              name="Auth"
              component={Auth}
              options={({ navigation }) => ({})}
            />
            <RootStack.Screen
              name="Home"
              component={Home}
              options={({ navigation }) => ({})}
            />
          </RootStack.Group>
          <RootStack.Group screenOptions={{ presentation: "modal" }}>
            <RootStack.Screen
              name="Details"
              component={Details}
              options={({ navigation }) => ({})}
            />
          </RootStack.Group>
        </RootStack.Navigator>
      </NavigationContainer>
    </ContextProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
