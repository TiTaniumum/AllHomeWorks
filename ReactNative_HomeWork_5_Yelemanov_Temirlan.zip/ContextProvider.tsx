import React, { createContext, useState, useContext, ReactNode } from "react";
import { Post } from "./interfaces";

export const mocks: Post[] = [{
    id: 0,
    title: "First Post",
    body: "This is body of the first post. And it has more letters than the title of the First Post.",
    author: "Temirlan",
    time: "14:03 29.06.2024",
}, {
    id: 1,
    title: "Second Post",
    body: "This post made for mocking posts",
    author: "Temirlan",
    time: "14:04 29.06.2024",
}];

type GlobalContext = {
  selectedPost: Post;
  posts: Post[];
  SelectPost: (id: number) => void;
};

const Context = createContext<GlobalContext>({} as GlobalContext);

export function ContextProvider({ children }: { children: ReactNode }) {
  const [selectedPost, setSelectedPost] = useState<Post>(mocks[0]);
  const [posts, setPosts] = useState<Post[]>(mocks);

  function SelectPost(id: number) {
    let item = posts.find((item) => item.id == id);
    if (item) setSelectedPost(item);
  }

  return (
    <Context.Provider value={{ selectedPost, posts, SelectPost }}>
      {children}
    </Context.Provider>
  );
}

export function useGlobalContext() {
  const context = useContext(Context);
  if (context === undefined) {
    throw new Error("useFinances должен использовать FinanceProvider");
  }
  return context;
}
