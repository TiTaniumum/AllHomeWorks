import { View, Text, FlatList, StyleSheet, Button } from "react-native";
import { useGlobalContext } from "../ContextProvider";

export default function Home({ navigation }: any) {
  const { posts, SelectPost } = useGlobalContext();

  function Inspect(id: number) {
    SelectPost(id);
    navigation.navigate("Details");
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={posts}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.title}</Text>
            <Button
              title="inspect"
              onPress={() => {
                Inspect(item.id);
              }}
            />
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    padding: 5,
  },
  item: {
    flexDirection: "row",
    gap: 5,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "black",
    borderRadius: 10,
    marginBottom: 5,
    padding: 10,
  },
});
