import { useState } from "react";
import { Text, StyleSheet, Button, View } from "react-native";
import { TextInput } from "react-native";

export default function Auth({ navigation }: any) {
  const [login, setLogin] = useState("admin");
  const [password, setPassword] = useState("admin");
  function Login() {
    if (login == "admin" && password == "admin") {
      navigation.navigate("Home");
    }
  }

  return (
    <View style={styles.container}>
      <Text>Login:</Text>
      <TextInput style={styles.input} value={login} onChangeText={setLogin} />
      <Text>Password:</Text>
      <TextInput style={styles.input} value={password} onChangeText={setPassword} />
      <Button title="Log in" onPress={Login} />
      <Text>Hint:</Text>
      <Text>Login = admin & password = admin</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height:'100%',
    width: '100%',
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    gap: 10,
  },
  input:{
    borderWidth: 1,
    borderColor: 'Black',
    borderRadius: 10,
    padding: 5,
  }
});
