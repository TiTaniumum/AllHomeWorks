import { View, Text, StyleSheet } from "react-native";
import { useGlobalContext } from "../ContextProvider";

export default function Details({ navigation }: any) {
  const { selectedPost } = useGlobalContext();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text>{selectedPost.title}</Text>
        <Text>Author: {selectedPost.author}</Text>
      </View>
      <Text>{selectedPost.body}</Text>
      <Text style={styles.footer}>{selectedPost.time}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: "100%",
    width: "100%",
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    padding: 30
  },
  header: {
    width: '100%',
    flexDirection: "row",
    justifyContent: "space-between",
    paddingBottom: 10,
    borderBottomColor: "black",
    borderBottomWidth: 1,
    borderRadius: 10,
    marginBottom: 10,
    padding: 5,
},
footer: {
    width:'100%',
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: 10,
    borderRadius: 10,
    borderTopColor: "black",
    borderTopWidth: 1,
    marginTop: 10,
    padding: 5,
},
});
