﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

//Тема: Mutex.Semaphore


//Задание 1

//Создайте приложение, использующее механизм мьютексов.
//Создайте в коде приложения несколько потоков.
//Первый поток генерирует набор случайных чисел и записывает их в файл.
//Второй поток ожидает, когда первый закончит своё исполнение,
//после чего анализирует содержимое файла и создаёт новый файл,
//в котором должны быть собраны только простые числа из первого файла.
//Третий поток ожидает, когда закончится второй поток, после чего создаёт новый файл,
//в котором должны быть собраны все простые числа из второго файла у которых последняя цифра равна 7.
//Выбор типа приложения (консольное или оконное, остаётся за вами).
//Используйте механизм многопоточности.

namespace Sys5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public Mutex mutex = new Mutex();
        public Random random = new Random();
        public int order = 1;
        //public ManualResetEvent threadOrder = new ManualResetEvent(false);
        public EventWaitHandle threadOrder = new AutoResetEvent(false);
        private void button2_Click(object sender, EventArgs e)
        {
            Prepare();
            Thread calculations = new Thread(StartOrder);
            calculations.IsBackground = true;
            calculations.Start();
        }
        public void Prepare()
        {
            order = 1;
            button2.Enabled = false;
            button3.Enabled = false;
            File.WriteAllText("randomNumbers.txt", string.Empty);
            File.WriteAllText("primeNumbers.txt", string.Empty);
            File.WriteAllText("numbersEndWith7.txt", string.Empty);
        }
        public void StartOrder(object parameter)
        {
            Thread first = new Thread(GenerateRandomNumbers);
            first.IsBackground = true;
            first.Start();
            threadOrder.WaitOne();
            Thread second = new Thread(ReadPrimeNumbers);
            second.IsBackground = true;
            second.Start();
            threadOrder.WaitOne();
            Thread third = new Thread(ReadEndingTo7);
            third.IsBackground = true;
            third.Start();
        }
        public void StartOrderWithoutWaitHandle(object parameter)
        {
            Thread first = new Thread(GenerateRandomNumbers);
            first.IsBackground = true;
            first.Start();
            //threadOrder.WaitOne();
            Thread second = new Thread(ReadPrimeNumbers);
            second.IsBackground = true;
            second.Start();
            //threadOrder.WaitOne();
            Thread third = new Thread(ReadEndingTo7);
            third.IsBackground = true;
            third.Start();
        }

        public void GenerateRandomNumbers(object parameter)
        {
            mutex.WaitOne();
            textBox1.Invoke((Action)delegate { textBox1.Clear(); textBox1.Text+=order++ +" - start id\r\n"; });
            int length = 100;
            int temp = 0;
            
            using (StreamWriter sw = new StreamWriter("randomNumbers.txt"))
            {
                for (int i = 0; i < length; i++)
                {
                    temp = random.Next(0, 100);
                    sw.WriteLine(temp);
                    textBox1.Invoke((Action)delegate { textBox1.Text += temp+"\r\n"; });
                }
                sw.Close();
            }
            threadOrder.Set();
            mutex.ReleaseMutex();
        }

        public void ReadPrimeNumbers(object parameter)
        {
            mutex.WaitOne();
            textBox2.Invoke((Action)delegate { textBox2.Clear(); textBox2.Text+=order++ +" - start id\r\n"; });
            int temp = 0;
            try
            {
                using (StreamReader sr = new StreamReader("randomNumbers.txt"))
                {
                    using (StreamWriter sw = new StreamWriter("primeNumbers.txt"))
                    {
                        while (!sr.EndOfStream)
                        {
                            temp = int.Parse(sr.ReadLine());
                            if (isPrime(temp))
                            {
                                sw.WriteLine(temp);
                                textBox2.Invoke((Action)delegate { textBox2.Text += temp+"\r\n"; });
                            }
                        }
                        sw.Close();
                    }
                    sr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            threadOrder.Set();
            mutex.ReleaseMutex();
        }

        public static bool isPrime(int num)
        {
            if (num<=1) return false;
            if (num==2 || num == 3 || num ==5) return true;
            if (num%2 == 0 || num%3==0 || num%5 == 0) return false;
            int boundery = (int)Math.Floor(Math.Sqrt(num));
            for (int i = 6; i <= boundery; i+=6)
            {
                if (num%(i+1) == 0 || num%(i+5) == 0) return false;
            }
            return true;
        }

        public void ReadEndingTo7()
        {
            mutex.WaitOne();
            textBox3.Invoke((Action)delegate { textBox3.Clear(); textBox3.Text+=order++ +" - start id\r\n"; });
            int temp = 0;
            try
            {
                using (StreamReader sr = new StreamReader("primeNumbers.txt"))
                {
                    using (StreamWriter sw = new StreamWriter("numbersEndWith7.txt"))
                    {
                        while (!sr.EndOfStream)
                        {
                            temp = int.Parse(sr.ReadLine());
                            if (temp%10 == 7)
                            {
                                sw.WriteLine(temp);
                                textBox3.Invoke((Action)delegate { textBox3.Text+=temp+"\r\n"; });
                                
                            }
                        }
                        sw.Close();
                    }
                    sr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            button2.Invoke((Action)delegate { button2.Enabled = true; });
            button3.Invoke((Action)delegate { button3.Enabled = true; });
            mutex.ReleaseMutex();
        }

        private void textBoxCheck_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            int result;
            if (int.TryParse(tb.Text, out result))
            {
                if (isPrime(result)) labelIsPrime.Text = "True";
                else labelIsPrime.Text = "False";
            }
            else
            {
                labelIsPrime.Text = "False";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Prepare();
            Thread calculations = new Thread(StartOrderWithoutWaitHandle);
            calculations.IsBackground = true;
            calculations.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Мютекс не гарантирует порядок выполнения потоков, поэтому вторая кнопка запускает код, который иногда делает не то что нужно. Первая кнопка ждет окончания выполнения потоков поэтому порядок соблюдается");
        }
    }
}
