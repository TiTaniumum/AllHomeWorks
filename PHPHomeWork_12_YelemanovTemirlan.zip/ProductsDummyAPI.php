<?php

// 1 четные
// 2 нечетные
// 3 самый дорогой 
// 4 самый дешевый

$json = json_decode(file_get_contents("https://dummyjson.com/products"));
$products = $json->products;
$result = [];
if (isset($_GET["select"])) {
    switch ($_GET["select"]) {
        case 1:
            $length = count($products);
            for($i = 1; $i < $length; $i+=2){
                $result[] = $products[$i];
            }
            break;
        case 2:
            $length = count($products);
            for($i = 0; $i <$length; $i+=2){
                $result[] = $products[$i];
            }
            break;
        case 3:
            $mostExpensive = $products[0];
            foreach($products as $product){
                if($mostExpensive->price < $product->price)$mostExpensive = $product;
            }
            $result[] = $mostExpensive;
            break;
        case 4:
            $leastExpensive = $products[0];
            foreach($products as $product){
                if($leastExpensive->price > $product->price)$leastExpensive = $product;
            }
            $result[] = $leastExpensive;
            break;
    }
}
header("Content-Type: application/json");
echo json_encode($result, JSON_PRETTY_PRINT);
?>