<?php
require_once("ProductController.php");
if (isset($_GET["category"])) {
    header("Content-Type: application/json");
    if ($_GET["category"] == "*")
        echo json_encode(ProductController::GetAllProducts());
    else
        echo json_encode(ProductController::GetProductsByCategoryName($_GET["category"]));
}else{
    echo "[]";
}
?>