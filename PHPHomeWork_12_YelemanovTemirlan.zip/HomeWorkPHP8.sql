create database shop2;
use shop2;

create table category(
id int primary key auto_increment not null,
name varchar(32)
);

create table product(
id int auto_increment primary key not null,
name varchar(32),
price int,
id_category int
);

select* from category;
select * from product;

INSERT INTO category(name) VALUES 
("Fish"),
("SeaFood"),
("VideoGames");


INSERT INTO product(name, price, id_category) VALUES
("Skyrim", 10000, 3),
("DeepRockGalactick", 5000, 3);

SELECT p.id, p.name,p.price, p.id_category as id_category FROM product AS p JOIN category AS c on p.id_category = c.id WHERE c.name = "VideoGames";