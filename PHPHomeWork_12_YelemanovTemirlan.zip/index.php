<?php
//echo "<code><pre>";
require_once("ProductController.php");
$categories = ProductController::GetAllCategories();
//echo "</pre></code>";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <form id="ProductsDummyAPI" action="ProductsDummyAPI.php" method=post>
        <select name="select" id="select">
            <option value="1">even</option>
            <option value="2">odd</option>
            <option value="3">most expensive</option>
            <option value="4">least expensive</option>
        </select>
        <button type=submit>Get Products</button>
    </form>
    <ol id="dummyProducts">

    </ol>
    <hr>
    <form action="index.php" method=post name=categories id=categories>
        <select name="category" id="category">
            <option value="*">Everything(no filter)</option>
            <?php foreach ($categories as $category): ?>
                <option value=<?= $category->name ?>>
                    <?= $category->name ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type=submit name=buttonClicked value=getProducts>Get Products</button>
    </form>
    <ol id="products">
        
    </ol>
    <hr>
    <form action="index.php" method=post name=task3 id=task3>
        <a href="" id=metka>1</a>
        <button type=submit>+</button>
    </form>
    <script src="main.js"></script>

</body>

</html>