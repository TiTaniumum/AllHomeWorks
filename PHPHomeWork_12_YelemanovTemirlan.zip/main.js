async function getJson(url) {
    let response = await fetch(url);
    let json = await response.json();
    return json;
};

let form1 = document.querySelector("#ProductsDummyAPI");
form1.addEventListener("submit", function(event){
    event.preventDefault();
    getJson(`${form1.action}?select=${form1.select.value}`).then(response =>{
        let ol = document.querySelector("#dummyProducts");
        ol.innerHTML = "";
        response.forEach(element=> {
            let li = document.createElement("li");
            li.textContent = `Name: ${element.title} | Price: ${element.price}`;
            ol.append(li);
        })
    })
})

let form2 = document.querySelector("#categories");
form2.addEventListener("submit", function (event) {
    event.preventDefault();
    let url = `getProducts.php?category=${form2.category.value}`;
    getJson(url).then(response => {
        let ol = document.querySelector("#products");
        ol.innerHTML = "";
        console.log(JSON.stringify(response));
        response.forEach(element => {
            let li = document.createElement("li");
            li.textContent = `Name: ${element.name} | Price: ${element.price}`;
            ol.append(li);
        });
    });
})


let a = document.querySelector("#metka");
a.addEventListener("click", function (event) {
    event.preventDefault();
    a.textContent = parseInt(a.textContent) + 1;
})
let form3 = document.querySelector("#task3");
form3.addEventListener("submit", function (event) {
    event.preventDefault();
    a.textContent = parseInt(a.textContent) + 1;
});


