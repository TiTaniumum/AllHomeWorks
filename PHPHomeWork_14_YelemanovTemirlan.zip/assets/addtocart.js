
let buttonlist = document.querySelectorAll(".addproduct");
let cart = document.getElementById("cartproductlist");

for (const element of buttonlist) {
    let parentElement = element.parentElement;
    //console.log(parentElement.children.namedItem("product").value);
    let p = JSON.parse(parentElement.children.namedItem("product").value);
    element.addEventListener("click", e=>{
        e.preventDefault();
        let product = document.createElement("div");
        product.classList.add("product");
        let name = document.createElement("p");
        name.innerText = "Product: " + p.name;
        let price = document.createElement("p");
        price.innerText = "Price: " + p.price;
        let quantity = document.createElement("p");
        p.quantity = parentElement.children.namedItem("quantity").value == 0? 1: parentElement.children.namedItem("quantity").value;
        quantity.innerText ="Quantity: "+ p.quantity;
        let productJson = document.createElement("input");
        productJson.value = JSON.stringify(p);
        productJson.type= "hidden";
        productJson.name = "product";
        productJson.classList.add("productinput");
        product.append(name);
        product.append(price);
        product.append(quantity);
        product.append(productJson);
        cart.append(product);
    })
}

let form = document.querySelector("#cart");
form.addEventListener("submit", e=>{
    e.preventDefault();
    let formobj = {};
    let customerid = form.querySelector("#customerList");
    formobj.customerid = customerid.value;
    formobj.productList = [];
    let inputlist = form.querySelectorAll(".productinput");
    for(const element of inputlist){
        formobj.productList.push(JSON.parse(element.value));
    }
    console.log(formobj);
    sendForm(form.action, form.method, formobj).then(response =>
        {
            if(response.message == "SUCCESS"){
                cart.innerHTML = "";
            } 
        });
});

async function sendForm(url, method = "post", formData) {
    let response = await fetch(url, {
        "method": method,
        body: JSON.stringify(formData),
        headers: {
            "Content-type": "application/json; charset=utf-8"
        }
    });
    let promise = await response.json();
    return promise;
}