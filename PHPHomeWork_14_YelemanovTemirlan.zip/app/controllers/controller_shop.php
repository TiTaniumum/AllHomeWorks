<?php
require_once("app/models/model_productList.php");
require_once("app/models/model_customerList.php");
class Controller_shop extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function action_index()
    {
        $this->render_cart();
        $this->render_productList();
    }
    private function render_productList()
    {
        $model = new Model_ProductList();
        $products = $model->getData();
        $this->view->generate("product_view.php", "productList_view.php", $products);
    }
    private function render_cart()
    {
        $customerList = new Model_customerList();
        $customerList = $customerList->getData();
        $this->view->generate("customerList_view.php", "cart_view.php", $customerList);
    }
    public function action_performTransaction()
    {
        $form = json_decode(file_get_contents("php://input"));
        if (count($form->productList) == 0) {
            header("Content-type: application/json");
            echo '{"message": "empty product list"}';
        }
        $sql1 =
            '
        insert into orders(orderDate, requiredDate, status, customerId) values
        (now(), date_add(now(), interval 7 day), "InProcess",:customerId);
        ';
        $arr = [];
        $arr["customerId"] = (int)$form->customerid;
        $orderId = Database::insert($sql1, $arr);
        $index = 1;
        foreach ($form->productList as $product) {
            $arr = [];
            $sql2 = 'insert into orderdetails(orderId,productId, quantityOrdered, priceEach, orderLineNumber) values ';
            $sql2 .= "(:orderId,:id,:quantity, :price, :index);";
            $arr["orderId"] = $orderId;
            $arr["id"] = $product->id;
            $arr["quantity"] = $product->quantity;
            $arr["price"] = $product->price;
            $arr["index"] = $index;
            Database::insert($sql2, $arr);
            $index++;
        }

        header("Content-type: application/json");
        echo '{"message": "SUCCESS"}';
    }
}
?>