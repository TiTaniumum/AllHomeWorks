<?php 
class Controller_Home extends Controller{
    public function __construct(){
        $this->model = new Model_Home;
        parent::__construct();
    }
    function action_index(){
        $this->view->generate("home_view.php","template_view.php", "Главная");
    }
}
?>