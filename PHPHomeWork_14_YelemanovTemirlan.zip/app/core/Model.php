<?php 
interface Model{
    public function getData();
}
?>