<?php 
interface ICreatable{
    public function Create($params);
}
?>