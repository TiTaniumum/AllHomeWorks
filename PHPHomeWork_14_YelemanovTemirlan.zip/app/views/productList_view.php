<div class="productlist">
    <p>Product List:</p>
    <?php foreach($data as $product):?>
        <div class="product" id=<?=$product->id?>>
            <?php include("app/views/$view");?>
            <input type="number" placeholder="quantity" name="quantity">
            <button class=addproduct>Add</button>
        </div>
    <?php endforeach?>
</div>
<script src="assets/addtocart.js"></script>