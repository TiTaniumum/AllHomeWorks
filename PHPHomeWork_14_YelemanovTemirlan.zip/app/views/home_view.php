<h1><?=$data?></h1>
<a href="http://localhost/Temirlan/PHP/HomeWork13/productList">Product List</a> <br>
<a href="http://localhost/Temirlan/PHP/HomeWork13/shop">Shop</a>