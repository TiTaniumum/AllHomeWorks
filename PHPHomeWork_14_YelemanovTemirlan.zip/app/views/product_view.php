<p>Product: <?=$product->name?></p>
<p>price: <?=$product->price?></p>
<input type="hidden" name="product" value='<?=json_encode($product)?>'>