<?php 
require_once("app/models/model_customer.php");
class Model_customerList implements Model{
    public function getData()
    {
        $sql = "select customerId, contactLastName, contactFirstName from customers;";
        $customers = Database::getAll($sql);
        return Model_customerList::GetList($customers);
    }
    public static function GetList($customers){
        $customerList = [];
        foreach($customers as $customer){
            $c = new Model_customer;
            $c->Create($customer);
            $customerList[] = $c;
        }
        return $customerList;
    }
}
?>