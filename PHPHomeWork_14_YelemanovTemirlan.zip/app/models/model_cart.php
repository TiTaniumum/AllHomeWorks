<?php 
class Model_cart implements Model{
    public function getData()
    {
    }
}
?>