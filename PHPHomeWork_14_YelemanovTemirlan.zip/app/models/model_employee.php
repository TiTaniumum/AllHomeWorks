<?php 
class Model_Employee implements ICreatable{
    public int $employeeId;
    public string $lastName;
    public string $firstName;
    public string $extension;
    public string $email;
    public int $officeId;
    public int $reportsTo;
    public string $jobTitle;
    public function Create($row){
        $this->employeeId = $row->employeeId;
        $this->lastName = $row->lastName;
        $this->firstName = $row->firstName;
        $this->extension = $row->extension;
        $this->email = $row->email;
        $this->officeId = $row->officeId;
        $this->reportsTo = $row->reportsTo;
        $this->jobTitle = $row->jobTitle;
    }
}
?>