<?php 
class Model_payment implements ICreatable{
    public int $customerId; 
    public string $checkNumber; 
    public DateTime $paymentDate; 
    public float $amount;
    public function Create($row){
        //code...
    }
}
?>