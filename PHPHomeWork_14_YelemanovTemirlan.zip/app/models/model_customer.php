<?php 
class Model_customer implements ICreatable{
    public int $id;
    public string $firstName;
    public string $lastName;
    public function Create($row){
        $this->id = (int)$row->customerId;
        $this->firstName = $row->contactFirstName;
        $this->lastName = $row->contactLastName;
    }
}
?>