<?php 
class Model_productLine implements ICreatable{
    public string $productLine; 
    public string $textDescription; 
    public string $htmlDescription; 
    public string $image;
    public function Create($row){
        //code.....
    }
}
?>