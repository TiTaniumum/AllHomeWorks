<?php 
class Model_Home implements Model{
    function getdata(){
        $acceptLang = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0,2);
        return array(
            "title" => match($acceptLang){
                "ru" => "Главная",
                default => "Home",
            },
        );
    } 
}
?>