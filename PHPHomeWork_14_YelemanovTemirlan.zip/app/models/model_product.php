<?php
class Model_Product implements ICreatable
{
    public $id;
    public $name;
    public $price;

    public function Create($row){
        $this->id = $row->productId;
        $this->name = $row->productName;
        $this->price = $row->buyPrice;
    }
}
?>