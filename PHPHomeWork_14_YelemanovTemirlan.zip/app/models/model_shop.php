<?php 
class Model_shop implements Model{
    public Controller_ProductList $productList;
    //public Controller_Cart $cart;
    public function getData()
    {
        
    }
}
?>