﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing.Drawing2D;

namespace winformsHW3_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            label1.Text = "Разница: " + (dateTimePicker1.Value - dateTimePicker2.Value).ToString("dd") + " дней";
        }

        //protected override void WndProc(ref Message m)
        //{
        //    const int WM_NCPAINT = 0x85;

        //    switch (m.Msg)
        //    {
        //        case WM_NCPAINT:
        //            IntPtr hRgn = Win32.CreateRoundRectRgn(0, 0, Width, Height, 20, 20);
        //            SetWindowRgn(Handle, hRgn, true);
        //            break;
        //    }

        //    base.WndProc(ref m);
        //}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            int borderRadius = 100; // Adjust this value to change the roundness of the corners

            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(0, 0, borderRadius, borderRadius, 180, 90);
                path.AddArc(Width - borderRadius, 0, borderRadius, borderRadius, 270, 90);
                path.AddArc(Width - borderRadius, Height - borderRadius, borderRadius, borderRadius, 0, 90);
                path.AddArc(0, Height - borderRadius, borderRadius, borderRadius, 90, 90);

                Region = new Region(path);
            }
        }
    }
}
