﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace winformsHW3
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    [Serializable]
    public class Anceta
    {
        public string firstName;
        public string lastName;
        public string otchestvo;
        public string gender;
        public DateTime birthDate;
        public string info;

        public Anceta()
        {
            firstName = string.Empty;
            lastName = string.Empty;
            otchestvo = string.Empty;
            gender = string.Empty;
            birthDate = DateTime.MinValue;
            info = string.Empty;
        }

        public Anceta(string firstName, string lastName, string otchestvo, string gender, DateTime birthDate, string info)
        {
            if (firstName == string.Empty) throw new Exception("Поле имени пустое");
            if (lastName == string.Empty) throw new Exception("Полe фамилии пустое");
            if (otchestvo == string.Empty) throw new Exception("Поле отчества пустое");
            if (gender ==string.Empty) throw new Exception("Поле пола пустое");
            if (birthDate == null) throw new Exception("Ошибка в дате рождения");
            this.firstName = firstName;
            this.lastName = lastName;
            this.otchestvo = otchestvo;
            this.gender = gender;
            this.birthDate = birthDate;
            this.info = info;
        }

        static string Path = "Anceta.xml";
        public static void WriteToXml(Anceta anceta)
        {
            File.Delete(Path);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Anceta));
            try
            {
                using (Stream fStream = File.OpenWrite(Path))
                {
                    xmlSerializer.Serialize(fStream, anceta);
                }
            }catch(Exception ex) { }
        }
    }
}
