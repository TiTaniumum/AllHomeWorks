﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

//Задание 1
//Создайте эмуляцию конных скачек.
//В гонке участвуют пять лошадей.
//Каждая лошадь - это отдельный прогресс-бар (элемент управления ProgressBar).
//При нажатии кнопки <Старт> начинается гонка.
//Скорость бега каждой лошади определяется в процессе гонки случайным образом.
//По итогам скачки нужно показать таблицу результатов.
//Используйте механизм многопоточности - все прогресс-бары обрабатываются в отдельных потоках.
//Для синхронизации используйте объект Event с ручным сбросом (ManualResetEvent)

namespace Sys4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            progressBar1.Tag = "1";
            progressBar2.Tag = "2"; 
            progressBar3.Tag = "3";
            progressBar4.Tag = "4";
            progressBar5.Tag = "5";
        }
        public Random random = new Random();
        public ManualResetEvent ready = new ManualResetEvent(false);
        public int count = 0;
        public void Race(object parameter)
        {
            ProgressBar pb = parameter as ProgressBar;
            Label label;
            switch (pb.Tag.ToString())
            {
                case "1": label = label1; break;
                case "2": label = label2; break;
                case "3": label = label3; break;
                case "4": label = label4; break;
                case "5": label = label5; break;
                default: label = label1; break;
            }
            int speed = 300;
            ready.WaitOne();
            int stepCount=0;
            while (pb.Maximum > pb.Value)
            {
                if (pb.Value+speed>pb.Maximum)
                {
                    speed = pb.Maximum - pb.Value;
                }
                stepCount++;

                //pb.Invoke(new Action(() =>
                //{
                //    pb.Value += speed;
                //}));
                label.Invoke((MethodInvoker)delegate { label.Text =speed.ToString(); });
                pb.Invoke((MethodInvoker)delegate { pb.Value+=speed;});
                Thread.Sleep(10);
                speed += random.Next(0, 2) == 0 ? -random.Next(0, 50) : random.Next(0, 50);
                if (speed<200) speed = 200;
                if (speed>900) speed = 900;
            }
            MessageBox.Show(pb.Tag.ToString() + " bar's average speed: " + pb.Maximum/stepCount);
            count++;
            if(count == 5)
            {
                buttonStart.Invoke((MethodInvoker)delegate { buttonStart.Enabled = true; });
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            count = 0;
            buttonStart.Enabled=false;
            ready.Reset();
            progressBar1.Value = 0;
            progressBar2.Value = 0;
            progressBar3.Value = 0;
            progressBar4.Value = 0;
            progressBar5.Value = 0;
            Thread thread1 = new Thread(Race);
            Thread thread2 = new Thread(Race);
            Thread thread3 = new Thread(Race);
            Thread thread4 = new Thread(Race);
            Thread thread5 = new Thread(Race);
            thread1.IsBackground = true;
            thread2.IsBackground = true;
            thread3.IsBackground = true;
            thread4.IsBackground = true;
            thread5.IsBackground = true;
            thread1.Start(progressBar1);
            thread2.Start(progressBar2);
            thread3.Start(progressBar3);
            thread4.Start(progressBar4);
            thread5.Start(progressBar5);
            Thread.Sleep(100);
            ready.Set();
            
        }
    }
}
