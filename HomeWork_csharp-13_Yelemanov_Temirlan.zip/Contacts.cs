﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonTools.ConsoleShortCuts;

namespace csharp13
{
    public class Contacts
    {
        public void Read()
        {
            FileStream fs;
            string fileName = "C:\\Users\\LEGION\\source\\repos\\csharp13\\Contacts.txt";
            StreamReader sr = new StreamReader(fileName);
            char[] buffer = new char[100];
            sr.Read(buffer, 0, buffer.Length);
           
            Console.Write(buffer);
            sr.Close();
        }

        public void Write()
        {
            StreamWriter sw;
            string fileName = "C:\\Users\\LEGION\\source\\repos\\csharp13\\Contacts.txt";
            sw = new StreamWriter(fileName, true);
            string str = string.Empty;
            C.In(ref str);
            sw.WriteLine(str);
            sw.Close();
        }
    }
}
