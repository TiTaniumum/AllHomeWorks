﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace csharp13
{
    [Serializable]
    public class Person
    {
        public string name;
        public string phone;
        public Person() : this("Jhon", "Doe") { }
        public Person(string _name, string _phone)
        {
            name = _name;
            phone = _phone;
        }

        public override string ToString()
        {
            return $"Name: {name}, Phone: {phone}";
        }
    };
}
