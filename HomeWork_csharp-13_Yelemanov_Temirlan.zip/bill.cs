﻿using CommonTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Разработать класс «Счет для оплаты». В классе предусмотреть следующие поля:
//■ оплата за день;
//■ количество дней;
//■ штраф за один день задержки оплаты;
//■ количество дней задержи оплаты;
//■ сумма к оплате без штрафа (вычисляемое поле);
//■ штраф(вычисляемое поле);
//■ общая сумма к оплате (вычисляемое поле).
//В классе объявить статическое свойство типа bool,
//значение которого влияет на процесс форматирования 
//объектов этого класса. Если значение этого свойства равно true, тогда сериализуются и десериализируются все 
//поля, если false — вычисляемые поля не сериализуются.
//Разработать приложение, в котором необходимо продемонстрировать использование этого класса, результаты 
//должны записываться и считываться из файла.

//namespace additionalPoles
//{
//    public partial class Bill
//    {
//        public int penaltylessPayment = 0;
//        public int totalPenalty = 0;
//        public int total = 0;

//        public void Init()
//        {

//        }
//    }
//}

namespace csharp13
{
    [Serializable]
    public partial class Bill
    {
        public int dailyPay;
        public int dayCount;
        public int penaltyADay;
        public int penaltyDays;
        public int PenaltylessPayment { get { return dailyPay*dayCount; } }
        public int TotalPenalty { get { return penaltyADay*penaltyDays; } }
        public int Total { get { return PenaltylessPayment + TotalPenalty; } }

        public static bool isAllSerialize = false;

        public class BillFull
        {
            public int dailyPay;
            public int dayCount;
            public int penaltyADay;
            public int penaltyDays;
            public int PenaltylessPayment;
            public int TotalPenalty;
            public int Total;

            public BillFull()
            {
                dailyPay = 0;
                dayCount = 0;
                penaltyADay = 0;
                penaltyDays = 0;
                PenaltylessPayment = 0;
                TotalPenalty = 0;
                Total = 0;
            }
            public BillFull(Bill bill)
            {
                dailyPay = bill.dailyPay;
                dayCount = bill.dayCount;
                penaltyADay = bill.penaltyADay;
                penaltyDays = bill.penaltyDays;
                TotalPenalty = bill.TotalPenalty;
                Total = bill.Total;
            }

            public override string ToString()
            {
                return $"dailyPay = {dailyPay}, dayCount = {dayCount}, penaltyADay = {penaltyADay}, penaltyDays = {penaltyDays}\n " +
                    $"payment without penalty = {PenaltylessPayment}, total penalty = {TotalPenalty}, Total = {Total}";
            }
        }
        public Bill()
        {
            dailyPay = 0;
            dayCount = 0;
            penaltyADay = 0;
            penaltyDays = 0;
        }
        public Bill(int dailyPay, int dayCount, int penaltyADay, int penaltyDays)
        {
            this.dailyPay=dailyPay;
            this.dayCount=dayCount;
            this.penaltyADay=penaltyADay;
            this.penaltyDays=penaltyDays;
        }

        public Bill(bool IsRandom) : base()
        {
            if (IsRandom)
            {
                dailyPay = Alg.RAND(2000, 25000);
                dayCount = Alg.RAND(0, 10);
                penaltyADay =Alg.RAND(200, 2500);
                penaltyDays = Alg.RAND(0, 10);
            }
        }
        public override string ToString()
        {
            return $"dailyPay = {dailyPay}, dayCount = {dayCount}, penaltyADay = {penaltyADay}, penaltyDays = {penaltyDays}\n " +
                $"payment without penalty = {PenaltylessPayment}, total penalty = {TotalPenalty}, Total = {Total}";
        }
    }
}
