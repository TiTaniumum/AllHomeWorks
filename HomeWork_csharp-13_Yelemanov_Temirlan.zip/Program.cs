﻿using System;
using System.Xml.Serialization;
using System.Xml.Linq;
using static System.Console;

namespace csharp13
{
    public class MainClass
    {
        public static string BillsPath = @"C:\Users\LEGION\source\repos\csharp13\Bills.xml";
        public static void Main(string[] args)
        {
            HomeWorkDemo();
        }

        public static void HomeWorkDemo()
        {
            //Bill.isAllSerialize = true;
            WriteBills();
            ReadBills();
        }

        public static void WriteBills()
        {
            List<Bill> bills = new List<Bill>();
            for (int i = 0; i < 5; i++)
            {
                bills.Add(new Bill(true));
            }

            WriteToXml(bills);
        }
        public static void ReadBills()
        {
            if (!Bill.isAllSerialize)
            {
                List<Bill> billsFromXml = ReadBillsFromXml();
                foreach (Bill bill in billsFromXml)
                {
                    WriteLine(bill.ToString());
                }
            }
            else
            {
                List<Bill.BillFull> fullBill = ReadFullBillsFromXml();
                foreach (Bill.BillFull bill in fullBill)
                {
                    WriteLine(bill.ToString());
                }
            }
        }
        static List<Bill.BillFull> ReadFullBillsFromXml()
        {
            List<Bill.BillFull> bills = null;
            using (Stream fstream = File.OpenRead(BillsPath))
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Bill.BillFull>));
                bills = (List<Bill.BillFull>)xmlSerializer.Deserialize(fstream);
            }

            return bills;
        }
        static List<Bill> ReadBillsFromXml()
        {
            List<Bill> bills = null;
            using (Stream fstream = File.OpenRead(BillsPath))
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Bill>));
                bills = (List<Bill>)xmlSerializer.Deserialize(fstream);
            }

            return bills;
        }

        static void WriteToXml(List<Bill> bills)
        {
            File.Delete(BillsPath);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Bill>));
            XmlSerializer xmlFull = new XmlSerializer(typeof(List<Bill.BillFull>));
            try
            {
                if (!Bill.isAllSerialize)
                {
                    using (Stream fStream = File.OpenWrite(BillsPath))
                    {
                        xmlSerializer.Serialize(fStream, bills);
                    }
                }
                else
                {
                    List<Bill.BillFull> fullBills = new List<Bill.BillFull>();
                    foreach (Bill bill in bills)
                    {
                        fullBills.Add(new Bill.BillFull(bill));
                    }
                    using (Stream fStream = File.OpenWrite(BillsPath))
                    {
                        xmlFull.Serialize(fStream, fullBills);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void Demo1()
        {
            Contacts contacts = new Contacts();
            contacts.Read();
            contacts.Write();
            contacts.Read();
        }
        public static void Demo2()
        {
            while (true)
            {
                WriteLine("Считать или записать? [r/w]");
                string cmd = ReadLine();

                switch (cmd)
                {
                    //case "rl":
                    //    ReadXmlLinq();
                    //break;
                    case "r":
                        List<Person> family = ReadFromXml();
                        foreach (Person person in family)
                        {
                            WriteLine(person.ToString());
                        }
                        break;
                    case "w":
                        {
                            WriteLine("ФИО:");
                            string fio = ReadLine();
                            WriteLine("Телефон:");
                            string phone = ReadLine();
                            Person p = new(fio, phone);
                            AppendToXml(p);
                        }
                        break;
                    case "rw":
                        {
                            WriteLine("ФИО:");
                            string fio = ReadLine();
                            WriteLine("Телефон:");
                            string phone = ReadLine();
                            Person p = new(fio, phone);
                            WriteXml(p);
                        }
                        break;
                }
            }
        }

        public static void Demo3()
        {
            XElement contacts =
            new XElement("Contacts",
            new XElement("Contact",
            new XElement("Name", "Patrick Hines"),
            new XElement("Phone", "206-555-0144",
            new XAttribute("Type", "Home")),
            new XElement("phone", "425-555-0145",
            new XAttribute("Type", "Work")),
            new XElement("Address",
            new XElement("Street1", "123 Main St"),
            new XElement("City", "Mercer Island"),
            new XElement("State", "WA"),
            new XElement("Postal", "68042")
            )
            )
            );
        }

        static List<Person> ReadFromXml()
        {
            List<Person> family = null;
            using (Stream fstream = File.OpenRead(@"C:\Users\LEGION\source\repos\csharp13\file.xml"))
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Person>));
                family = (List<Person>)xmlSerializer.Deserialize(fstream);
            }
            return family;
        }

        static void WriteToXml(List<Person> p)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Person>));
            try
            {
                using (Stream fStream = File.OpenWrite(@"C:\Users\LEGION\source\repos\csharp13\file.xml"))
                {
                    xmlSerializer.Serialize(fStream, p);
                }
            }
            catch (Exception ex) { }
        }
        static void WriteXml(Person p)
        {
            List<Person> family = new List<Person> { p };
            WriteToXml(family);
        }
        static void AppendToXml(Person p)
        {
            List<Person> family = ReadFromXml();
            family.Add(p);
            WriteToXml(family);
        }
    }
}