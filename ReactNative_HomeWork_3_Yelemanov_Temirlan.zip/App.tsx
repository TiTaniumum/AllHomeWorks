import { StatusBar } from 'expo-status-bar';
import { ScrollView, StyleSheet, Animated, Text, View, FlatList, SafeAreaView} from 'react-native';
import { Button, CheckBox, Input } from '@rneui/themed'
import { useEffect, useRef, useState } from 'react';

interface Todo {
  id: number,
  title: string,
  status: boolean,
  due: string | null,
  comment: string | null
}

const todoTemplate: Todo[] = [
  {
    id: 1,
    title: "Сходить в магазин",
    status: false,
    due: "2024-06-24",
    comment: null
  },
  {
    id: 2,
    title: "Вернуть долг",
    status: false,
    due: "2024-06-10",
    comment: null
  },
  {
    id: 3,
    title: "Проснуться",
    status: true,
    due: null,
    comment: null
  }
];


function AnimatedComponent(item: any){
  var isAnimated = false;
  const fontSizeAnim = useRef(new Animated.Value(10)).current;

  console.log(item);

  useEffect(() => {
    const interval = setInterval(() => {
      if(!isAnimated){
        Animated.timing(fontSizeAnim, {
          toValue: 20,
          duration: 1000,
          useNativeDriver: false
        }).start();
        isAnimated = !isAnimated;
      }
      else
      {
        Animated.timing(fontSizeAnim, {
          toValue: 10,
          duration: 1000,
          useNativeDriver: false
        }).start();
        isAnimated = !isAnimated
      }
    }, 1000);

    // Cleanup interval on component unmount
    return () => clearInterval(interval);
  }, []);

  return (
    <View>
      <Animated.Text style={(item.data.status) ? [styles.checked, styles.todo]: [styles.todo,{fontSize: fontSizeAnim}]}>{item.data.title}</Animated.Text>
    </View>
  );
}

export default function App() {
  
  const [todos, setTodos] = useState(todoTemplate);
  const [text, setText] = useState("");
  const toggleCheckBox = (id: number)=>
    setTodos((todoList)=>
      todoList.map((todo)=>
        todo.id == id ? {... todo, status: !todo.status} : todo
  )
  );
  
  function Todo(item: any) {

    return (
      <View style={styles.row}>
        <CheckBox checked={item.status} 
                  onPress={()=>toggleCheckBox(item.id)}
                  iconType='material-community'
                  checkedIcon="checkbox-marked"
                  uncheckedIcon="checkbox-blank-outline"
                  checkedColor='orange'/>
        {/* <Text style={(item.status) ? [styles.checked, styles.todo ]: styles.todo}>{item.title}</Text> */}
        <AnimatedComponent data={item}></AnimatedComponent>
      </View>
    )
  }

  function addTodo(){
    if(text.trim().length >0){
      const newTodo = {
        id: todos.length + 1,
        title: text, 
        status: false,
        due: null,
        comment: null,
      };
      todos.push(newTodo);
      setText('');
    }
  }

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.list}>
        <Input style={styles.input} value={text} onChangeText={setText} onSubmitEditing={addTodo}/>
        <FlatList data={todos}
          renderItem={({item})=>Todo(item)} />
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  list:{
    width: '100%',
    height: '100%',
  },
  row: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
    borderBottomColor: 'black'
  },
  todo: {
    fontSize: 16
  },
  checked:{
    textDecorationLine: 'line-through',
    textDecorationStyle: 'solid',
    color: 'gray'
  },
  input:{
    backgroundColor:'cyan'
  }
  
});
