﻿#include <iostream>
#include <iomanip>
#include <algorithm>
#include <stdlib.h>
#include <random>
#include <chrono>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
using namespace std;

int main()
{
  srand(time(NULL));
  //problem1();
  //problem2();
  //problem3();
  //problem4();
  //problem5();
  
  problem6(); // дополнительное задание
  cout << "\nend! . . . . . . . . . . . . . \n";
}