<?php 
require_once("Database.php");
$username = isset($_COOKIE["username"]) ? $_COOKIE["username"] : "";
if(isset($_POST["username"])){
    setcookie("username", $_POST["username"], time()+ 1*24*60*60);
}

if(isset($_POST["feedback"])){
    $sql = "insert into feedbacks(feedback, user_name) values (?,?)";
    $arr = array($username, $_POST["feedback"]);
    Database::insert($sql, $arr);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form action="index.php" name=feedbackform id=feedbackform>
        <input type="text" placeholder="your Name..." name=username value="<?=$username?>">
        <input type="text" placeholder="Your FeedBack... " name=feedback>
        <button type=submit>
            send
        </button>
    </form>
</body>
</html>