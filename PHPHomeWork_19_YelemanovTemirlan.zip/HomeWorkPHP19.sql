create database TempDataBase;

create table feedbacks(
id int primary key auto_increment,
feedback text,
user_name varchar(64)
);

insert into feedbacks(feedback, user_name) values 
(?,?);