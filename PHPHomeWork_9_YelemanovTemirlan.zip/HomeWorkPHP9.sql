create database shop3;
use shop3;

create table category(
id int primary key auto_increment not null,
name varchar(32)
);

INSERT INTO category(name) VALUES 
("SeaFood"),
("Candy"),
("VideoGames"),
("Cars"),
("Laptops");

create table product(
id int auto_increment primary key not null,
name varchar(32),
price int,
id_category int
);

INSERT INTO product(name, price, id_category) VALUES
("Skyrim", 10000, 3),
("DeepRockGalactick", 5000, 3),
("DragonAge Origins", 3500, 3),
("Darksiders", 7000, 3),
("Super Hot", 500, 3),
("Salmon", 5000, 1),
("Tilapia", 2000, 1),
("Swordfish", 8000,1),
("Sardine", 100, 1),
("Cod", 1200, 1),
("Snikers", 400, 2),
("Twiks", 350, 2),
("Yarche",200,2),
("Milka", 600, 2),
("Kazakhstan", 500, 2),
("Lambargini huricane",2500000, 4),
("Dodge Challanger", 900000, 4),
("Pagani Murcilago", 700000, 4),
("Marussia B2", 4000000, 4),
("Porche", 4530000, 4),
("Lenovo legion", 450000, 5),
("Asus Tuf gaming", 340000, 5),
("MacBook", 100000, 5),
("Dell", 200000, 5),
("Huawei", 143000, 5);

create table user(
id int primary key auto_increment not null,
name varchar(32)
);

insert into user(name) values
("Dima Gorshcov"),
("Kanishev Ilya"),
("Sapar Sayat"),
("Michail Ktototamovich"),
("Temirlan Yelemanov"),
("Vasya Pupkin"),
("Gerasim Grechnikov"),
("Slav Gagarin"),
("Tor Odinson"),
("Yorik Torkelson");

create table cart(
id int primary key auto_increment not null,
id_user int,
id_product int,
constraint fk_id_user_cart foreign key(id_user) references user(id),
constraint fk_id_product_cart foreign key(id_product) references product(id)
);

insert into cart(id_user, id_product) values 
(1,2),
(1,23),
(1,14),
(2,5),
(3,7),
(3,3),
(4,19),
(4,20),
(5,25),
(6,11),
(6,4),
(6,1),
(6,9),
(7,16),
(7,17),
(8,10),
(9,11),
(9,15),
(10,10),
(10,3),
(10,15),
(10,21);

-- ==================================================================== --

select * from user;


select u.name as UserName, p.name as ProductName, p.price, cat.name as CategoryName from cart c 
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
join user u on c.id_user = u.id
order by c.id;

select u.name as UserName, cat.name as CategoryName, p.name as ProductName from cart c 
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
join user u on c.id_user = u.id
order by c.id;

select u.name as UserName, p.name as ProductName, p.price, cat.name as CategoryName from cart c 
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
join user u on c.id_user = u.id
where u.id = 1
order by c.id;

select u.name as UserName, cat.name as CategoryName from cart c 
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
join user u on c.id_user = u.id
where u.id = 1
order by c.id;


select u.name as UserName, p.name as ProductName from cart c 
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
join user u on c.id_user = u.id
where p.id = 10
order by c.id;


-- with UserChosenCategories as (select cat.name as categoryName from cart c 
-- join product p on c.id_product = p.id
-- join category cat on p.id_category = cat.id
-- join user u on c.id_user = u.id
-- where u.id = 10
-- order by c.id)
-- почему то не работает это если написать так:
-- where name not in(UserChosenCategories.categoryName)

select name as "Missed Categories" from category 
where name not in(select cat.name as categoryName from cart c 
join product p on c.id_product = p.id
join category cat on p.id_category = cat.id
join user u on c.id_user = u.id
where u.id = 6
order by c.id);
