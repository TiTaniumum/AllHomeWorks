﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winforms7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public Form4 editWindow;
        public void UpdateData()
        {
            textBox1.Text = File.ReadAllText(Tag.ToString(), Encoding.UTF8);
            labelFileName.Text = "Name: " + Tag.ToString();
        }
        private void buttonCreate_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Owner = this;
            form2.ShowDialog();
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Owner = this;
            DialogResult result = form3.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox1.Text = File.ReadAllText(Tag.ToString(), Encoding.UTF8);
                labelFileName.Text = "Name: " + Tag.ToString();
                buttonEdit.Enabled = true;
            }
            if(editWindow != null) editWindow.acceptText(textBox1.Text);
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (editWindow != null)
            {
                editWindow.Show();
                editWindow.acceptText(textBox1.Text);
            }
            else
            {
                editWindow = new Form4();
                editWindow.Owner = this;
                editWindow.acceptText(textBox1.Text);
                editWindow.Show();
            }
        }
    }
}
