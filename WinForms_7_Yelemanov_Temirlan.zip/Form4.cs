﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace winforms7
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            
        }
        public void acceptText(string str)
        {
            textBox1.Text = str;
        }
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            File.WriteAllText(Owner.Tag.ToString(), string.Empty);
            using (StreamWriter sw = File.AppendText(Owner.Tag.ToString()))
            {
                sw.Write(textBox1.Text);
            }
            (Owner as Form1).UpdateData();
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            (Owner as Form1).editWindow = null;
        }
    }
}
