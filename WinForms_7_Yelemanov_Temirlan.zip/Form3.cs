﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace winforms7
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            InitFileColletion();
            button1.DialogResult = DialogResult.OK;
        }

        private void InitFileColletion()
        {
            string path = GetEXEPath();
            string[] files = Directory.GetFiles(path, "*.txt");
            foreach (string file in files)
            {
                comboBoxFileColletion.Items.Add(file);
            }
        }

        private string GetEXEPath()
        {
            string path = System.Reflection.Assembly.GetEntryAssembly().Location;
            for (int i = path.Length - 1; i >= 0; i--)
            {
                if (path[i] == '\\')
                {
                    path = path.Remove(i+1, path.Length-1-i);
                    break;
                }
            }
            return path;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBoxFileColletion.SelectedItem == null)
            {
                MessageBox.Show("You didn't select any file!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(comboBoxFileColletion.SelectedItem.ToString() == "" || comboBoxFileColletion.SelectedItem.ToString() == "None")
            {
                MessageBox.Show("You didn't select any file!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            this.Owner.Tag = comboBoxFileColletion.SelectedItem.ToString();
            this.Close();
        }
    }
}