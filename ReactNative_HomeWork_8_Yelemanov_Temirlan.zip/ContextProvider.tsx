import React, { createContext, useState, useContext, ReactNode } from "react";
import { Film } from "./interfaces";

export const mocks: Film[] = [
  {
    Title: "X-Men Origins: Wolverine",
    Year: "2009",
    imdbID: "tt0458525",
    Type: "movie",
    Poster:
      "https://m.media-amazon.com/images/M/MV5BZWRhMzdhMzEtZTViNy00YWYyLTgxZmUtMTMwMWM0NTEyMjk3XkEyXkFqcGdeQXVyNTIzOTk5ODM@._V1_SX300.jpg",
  },
  {
    Title: "The Wolverine",
    Year: "2013",
    imdbID: "tt1430132",
    Type: "movie",
    Poster:
      "https://m.media-amazon.com/images/M/MV5BNzg1MDQxMTQ2OF5BMl5BanBnXkFtZTcwMTk3MjAzOQ@@._V1_SX300.jpg",
  },
];

type GlobalContext = {
  currentFilm: Film;
  films: Film[];
  setCurrentFilm: (film: Film) => void;
  setFilms: (films: Film[]) => void;
};

const Context = createContext<GlobalContext>({} as GlobalContext);

export function ContextProvider({ children }: { children: ReactNode }) {
  const [currentFilm, setCurrentFilm] = useState<Film>(mocks[0]);
  const [films, setFilms] = useState<Film[]>(mocks);

  return (
    <Context.Provider value={{ currentFilm, films, setCurrentFilm, setFilms }}>
      {children}
    </Context.Provider>
  );
}

export function useGlobalContext() {
  const context = useContext(Context);
  if (context === undefined) {
    throw new Error("useFinances должен использовать FinanceProvider");
  }
  return context;
}
