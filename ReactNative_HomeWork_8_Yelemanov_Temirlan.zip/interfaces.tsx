// http://www.omdbapi.com/?s={name}&apikey=8d529efc
// http://www.omdbapi.com/?i={ttid}&apikey=8d529efc
export interface Film {
  Title: string;
  Year: string;
  imdbID: string;
  Type: string;
  Poster: string;
};

export interface Ratings{
    Source: string;
    Value: string;
}

export interface FilmDetail {
  Title: string;
  Year: string;
  Rated: string;
  Released: string;
  Runtime: string;
  Genre: string;
  Director: string;
  Writer: string;
  Actors: string;
  Plot: string;
  Language: string;
  Country: string;
  Awards: string;
  Poster: string;
  Ratings: Ratings[];
  Metascore: string;
  imdbRating: string;
  imdbVotes: string;
  imdbID: string;
  Type: string;
  DVD: string;
  BoxOffice: string;
  Production: string;
  Website: string;
  Response: string;
}

export interface OmdbapiResult {
  Search: Film[];
  totalResults: string;
  Response: string;
}
