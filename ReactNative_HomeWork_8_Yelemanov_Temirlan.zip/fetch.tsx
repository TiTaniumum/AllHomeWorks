export async function fetchFilms<Type>(
  searchString: string,
  api: string = "8d529efc"
): Promise<Awaited<Type | null>> {
  try {
    const url = `http://www.omdbapi.com/?s=${searchString}&apikey=${api}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("404");
    }
    const data = await response.json();
    console.info(data);
    return data;
  } catch (ex) {
    console.error("Ошибка при загрузки API: ", ex);
  }
  return null;
}

export async function fetchFilmDetail<Type>(
  searchString: string,
  api: string = "8d529efc"
): Promise<Awaited<Type | null>> {
  try {
    const url = `http://www.omdbapi.com/?i=${searchString}&apikey=${api}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("404");
    }
    const data = await response.json();
    console.info(data);
    return data;
  } catch (ex) {
    console.error("Ошибка при загрузки API: ", ex);
  }
  return null;
}
