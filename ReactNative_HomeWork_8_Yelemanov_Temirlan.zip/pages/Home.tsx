import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Image,
  Button,
  TextInput,
} from "react-native";
import { useGlobalContext } from "../ContextProvider";
import { useState } from "react";
import { withTheme } from "styled-components";
import { fetchFilms } from "../fetch";
import { Film, OmdbapiResult } from "../interfaces";

export default function Home({ navigation }: any) {
  const [searchString, setSearchString] = useState("");
  const {setCurrentFilm, films, setFilms } = useGlobalContext();

  function handleFilmInfo(film: Film) {
    setCurrentFilm(film);
    navigation.navigate("FilmInfo");
  }
  async function search() {
    const data: OmdbapiResult | null = await fetchFilms<OmdbapiResult>(
      searchString
    );
    if (data) {
      setFilms(data.Search);
    }
  }
  return (
    <View style={styles.container}>
      <FlatList
        data={films}
        style={{ width: "100%" }}
        contentContainerStyle={{
          width: "100%",
          gap: 5,
          justifyContent: 'center',
        }}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Image style={styles.image} source={{ uri: item.Poster }} />
            <View style={styles.shortDescription}>
              <Text>{item.Title}</Text>
              <Text>{item.Year}</Text>
              <Button title="Подробнее" onPress={()=>{handleFilmInfo(item)}} />
            </View>
          </View>
        )}
      />
      <View style={styles.footer}>
        <TextInput
          style={styles.input}
          placeholder="..."
          value={searchString}
          onChangeText={setSearchString}
        />
        <Button title="Поиск" onPress={search} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    height: 140,
    width: 100,
  },
  row: {
    flexDirection: "row",
  },
  footer: {
    width: "100%",
    flexDirection: "row",
    padding: 10,
    backgroundColor: "white",
    justifyContent: "space-around",
    borderTopColor: "black",
    borderTopWidth: 1,
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    borderColor: "black",
    padding: 5,
  },
  shortDescription: {
    justifyContent: "space-between",
    gap: 20,
    width: '40%'
  },
  item: {
    width: "100%",
    padding: 10,
    flexDirection: "row",
    borderBottomColor: "black",
    borderBottomWidth: 1,
    justifyContent: 'space-around'
  },
});
