import { View, Text, StyleSheet, Button, Image, FlatList, ScrollView } from "react-native";
import { useGlobalContext } from "../ContextProvider";
import { useEffect, useState } from "react";
import { FilmDetail } from "../interfaces";
import { fetchFilmDetail } from "../fetch";

export default function FilmInfo({ navigation }: any) {
  const [filmDetail, setFelmDetail] = useState<FilmDetail | null>(null);
  const { currentFilm } = useGlobalContext();

  useEffect(() => {
    async function handleFetch() {
      const data: FilmDetail | null = await fetchFilmDetail<FilmDetail>(
        currentFilm.imdbID
      );
      if (data) setFelmDetail(data);
    }
    handleFetch();
  }, []);

  return (
    <ScrollView>
      {filmDetail ? (
        <View style={[styles.container,{gap: 30,padding: 20}]}>
          <View style={[styles.row,{gap: 30}]}>
            <Image style={styles.image} source={{ uri: filmDetail.Poster }} />
            <View style={styles.shortDescription}>
              <Text>{filmDetail.Title}</Text>
              <Text>Год: {filmDetail.Year}</Text>
              <Text>{filmDetail.Rated}</Text>
              <Text>Жанры: {filmDetail.Genre}</Text>
              <Text>Рейтинг: {filmDetail.imdbRating} / 10</Text>
              <Text>Длительность: {filmDetail.Runtime}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <Text>Дата выпуска: {filmDetail.Released}</Text>
            <Text>Описание: {filmDetail.Plot}</Text>
            <Text>Актеры: {filmDetail.Actors}</Text>
            <Text>Страна: {filmDetail.Country}</Text>
            <Text>Награждения: {filmDetail.Awards}</Text>
            <Text>Директор: {filmDetail.Director}</Text>
            <Text>Писатели: {filmDetail.Writer}</Text>
            <Text></Text>
          </View>
          <FlatList
            data={filmDetail.Ratings}
            contentContainerStyle={{gap: 5}}
            renderItem={({item}) => <View style={styles.item}>
                <Text>Источник: {item.Source}</Text>
                <Text>Оценка: {item.Value}</Text>
            </View>}
          />
        </View>
      ) : (
        <View>
          <Text>Идет загрузка...</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  row: {
    flexDirection: "row",
  },
  image: {
    height: 180,
    width: 120,
  },
  shortDescription:{
    justifyContent: 'space-between',
    width: '50%'
  },
  item:{
    borderTopColor: 'black',
    borderTopWidth: 1,
    padding: 5
  },
  description:{
    gap: 10,
  }
});
