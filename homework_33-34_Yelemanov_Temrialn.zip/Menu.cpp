#include <iostream>
#include <string>
#include "Win10.h"
using namespace std;

int Menu(string* menu, int length,  int row, int col, int select = 0) {
  system("cls");
  while (true) {
    for (size_t i = 0; i < length; i++)
    {
      SetPos(row+i, col);
      cout << menu[i];
      if (select == i)cout << " <--";
      else cout << "        ";
    }
    int key = _getch();
    switch (key) {
    case _KEY::UP:
      (select == 0)? select = length-1: select--;
      system("cls");
      break;
    case _KEY::DOWN:
      (select == length - 1) ? select = 0 : select++;
      system("cls");
      break;
    case _KEY::ENTER:
      system("cls");
      return select;
    case _KEY::ESC: return -1;
    }
  }
}