﻿#include <iostream>
#include <conio.h>
#include <string>
#include <time.h>
#include <iomanip>
#include <algorithm>
#include <random>
#include "win10.h"
#include "problem1.h"
#include "about.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"

using namespace std;

//Задание 1
//Используя функцию Menu() реализовать программу с меню для решения двух - трех домашних работ.
//Например, на экран вывести пункты меню :
//
//Решение задачи №1
//Решение задачи №2
//Решение задачи про Васю
//Об авторе
//Выход

int Menu(string* menu, int length, int row, int col, int select = 0);

void BullAndCow(int row, int col);

string mainMenu[]{
  "Problem-1",
  "Problem-2",
  "Problem-3",
  "Problem-4",
  "Game \"Bull and Cow\"",
  "About",
  "Exit"
};
int length = sizeof(mainMenu) / sizeof(mainMenu[0]);

int row = 5, col = 10;

int main()
{
  srand(time(NULL));
  CursorHide();
  while (true) {
    switch (Menu(mainMenu, length, row, col, 0)) {
    case 0:problem1();
      break;
    case 1:problem2();
      break;
    case 2:problem3();
      break;
    case 3:problem4();
      break;
    case 4:BullAndCow(row,col);
      break;
    case 5:about();
      break;
    case 6:return 0;
    case -1: return 0;
    }
  }

  cout << "\nend!\n";
}


void SetColor(int colBkgr, int colSym)
{
  int wAttributes = colBkgr * 16 + colSym;
  HANDLE hOUTPUT = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(hOUTPUT, wAttributes);
}

void SetPos(int Row, int Col)
{
  COORD cd;
  cd.X = Col;
  cd.Y = Row;
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cd);
}

void CursorHide(BOOL bVisible, DWORD dwSize)
{
  HANDLE hOUTPUT = GetStdHandle(STD_OUTPUT_HANDLE); // Get console handle
  // Hide console cursor
  CONSOLE_CURSOR_INFO cursorInfo;
  cursorInfo.dwSize = dwSize;
  cursorInfo.bVisible = bVisible;
  SetConsoleCursorInfo(hOUTPUT, &cursorInfo);
}