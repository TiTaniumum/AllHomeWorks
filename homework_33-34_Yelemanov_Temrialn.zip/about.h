#pragma once
using namespace std;




void about() {
  SetPos(5, 10);
  SetColor(0, 1);
  cout << "Made by Yelemanov Temirlan";
  cin.get();
  SetColor(0, 7);
}