﻿using CommonTools.ConsoleShortCuts;
using CommonTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp7
{
    public class Game2
    {
        private string word;
        private List<string> guesses;
        public Game2()
        {
            word = string.Empty;
            guesses = new List<string>();
        }
        public void Display()
        {
            Console.Clear();
            Console.SetCursorPosition(10, 10);
            C.Out("Number:");
            for (int i = 0; word.Length > i; i++)
            {
                C.Out("*");
            }
            int pos = 10;
            for (int i = 0; i < guesses.Count; i++)
            {
                Console.SetCursorPosition(40, pos+i);
                PrintGuess(guesses[i]);
            }
        }

        private void PrintGuess(string str)
        {
            if (word.Length == 0) return;
            for (int i = 0; i < word.Length; i++)
            {
                if (str[i] == word[i])
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                else if (isInside(str[i]))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }
                else
                {
                    Console.ForegroundColor= ConsoleColor.Red;
                }
                C.Out(str[i]);
            }
            Console.ForegroundColor = ConsoleColor.White;
        }

        private bool isInside(char ch)
        {
            for (int i = 0; word.Length > i; i++)
            {
                if (word[i] == ch) return true;
            }
            return false;
        }

        private void AskUserNum()
        {
            int length = 0;
            int i = 0;
            string str = string.Empty;
            while (word.Length != str.Length)
            {
                Console.SetCursorPosition(10, 11+i);
                ++i;
                C.In(ref str);
            }
            str = str.ToLower();
            guesses.Add(str);
        }

        private int getLength(int num)
        {
            int length = 0;
            while (num >0)
            {
                ++length;
                num /=10;
            }
            return length;
        }

        private bool isGameOver()
        {
            for (int i = 0; i < guesses.Count; i++)
            {
                if (guesses[i] == word)
                {
                    return true;
                }
            }
            return false;
        }

        private void PrintGameOver()
        {
            Console.Clear();
            Console.SetCursorPosition(10, 10);
            C.Out("You win! The Number is: ");
            Console.ForegroundColor = ConsoleColor.Green;
            for (int i = 0; i < word.Length; i++)
            {
                C.Out(word[i]);
            }
            Console.ForegroundColor= ConsoleColor.White;
            Console.ReadLine();
        }
        private void Init()
        {
            int cnt = 0;
            C.Out("Type in lengt of the number ");
            C.In(ref cnt);
            word = string.Empty;
            for (int i = 0; i < cnt; i++)
            {
                word += (char)Alg.rand.Next('a', 'z'+1);
            }
        }
        public void Start()
        {
            Init();
            while (!isGameOver())
            {
                Display();
                AskUserNum();
            }
            PrintGameOver();
        }
    }
}
