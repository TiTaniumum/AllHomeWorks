﻿using System;

namespace csharp7
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            Snake snake = new Snake();
            snake.Start();

            //Game game = new Game();
            //game.Start();

            //Game2 game2 = new Game2();
            //game2.Start();
        }
    }
}