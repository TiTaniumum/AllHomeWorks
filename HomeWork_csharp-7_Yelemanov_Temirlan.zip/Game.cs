﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonTools.ConsoleShortCuts;
using CommonTools;
using System.Runtime.InteropServices;
using System.Collections.Specialized;

namespace csharp7
{
    public class Game
    {
        private List<int> number;
        private List<int> guesses;
        public Game()
        {
            number = new List<int>();
            guesses = new List<int>();
        }
        public void Display()
        {
            Console.Clear();
            Console.SetCursorPosition(10, 10);
            C.Out("Number:");
            for (int i = 0; number.Count > i; i++) {
                C.Out("*");
            }
            int pos = 10;
            for (int i = 0; i < guesses.Count; i++)
            {
                Console.SetCursorPosition(40, pos+i);
                PrintGuess(guesses[i]);
            }
        }

        private void PrintGuess(int num)
        {
            if (number.Count ==0) return;
            List<int> templist = new List<int>();
            for (int i = 0; number.Count > i; i++)
            {
                templist.Add(num%10);
                num/=10;
            }
            for (int i = 0; i < number.Count; i++)
            {
                if (templist[templist.Count-1-i] == number[i])
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                else if (isInside(templist[templist.Count-1-i]))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }
                else
                {
                    Console.ForegroundColor= ConsoleColor.Red;
                }
                C.Out(templist[templist.Count-1-i]);
            }
            Console.ForegroundColor = ConsoleColor.White;
        }

        private bool isInside(int num)
        {
            for (int i = 0;number.Count > i; i++)
            {
                if (number[i] == num) return true;
            }
            return false;
        }

        private void AskUserNum()
        {
            int length = 0;
            int i = 0;
            int num = 0;
            while (number.Count != length)
            {
                Console.SetCursorPosition(10, 11+i);
                ++i;
                C.In(ref num);
                length = getLength(num);

            }
            guesses.Add(num);
        }

        private int getLength(int num)
        {
            int length = 0;
            while(num >0)
            {
                ++length;
                num /=10;
            }
            return length;
        }

        private bool isGameOver()
        {
            int tempNumber = number[0];
            for (int i = 1; i < number.Count; i++)
            {
                tempNumber*=10;
                tempNumber+=number[i];
            }
            for(int i = 0;i < guesses.Count; i++)
            {
                if(guesses[i] == tempNumber)
                {
                    return true;
                }
            }
            return false;
        }

        private void PrintGameOver()
        {
            Console.Clear();
            Console.SetCursorPosition(10, 10);
            C.Out("You win! The Number is: ");
            Console.ForegroundColor = ConsoleColor.Green;
            for (int i = 0; i < number.Count; i++)
            {

                C.Out(number[i]);
            }
            Console.ForegroundColor= ConsoleColor.White;
            Console.ReadLine();
        }
        private void Init()
        {
            int cnt = 0;
            C.Out("Type in lengt of the number ");
            C.In(ref cnt);
            number.Clear();
            for (int i = 0; i < cnt; i++)
            {
                number.Add(Alg.rand.Next(1, 10));
            }
        }
        public void Start()
        {
            Init();
            while (!isGameOver())
            {
                Display();
                AskUserNum();
            }
            PrintGameOver();
        }
    }
}
