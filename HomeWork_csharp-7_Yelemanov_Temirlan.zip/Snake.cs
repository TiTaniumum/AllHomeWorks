﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonTools;
using CommonTools.ConsoleShortCuts;
using static CommonTools.ConsoleShortCuts.C;

namespace csharp7
{
    public class Snake
    {
        private int width;
        private int height;
        public Snake(int width, int height)
        {
            this.width = width;
            this.height = height;
        }
        public Snake()
        {
            this.width = 0;
            this.height = 0;
        }
        private void AskUserMeasures()
        {
            OutLine("(Width)");
            In(ref width);
            OutLine("(Height)");
            In(ref height);
            Console.Clear();
        }
        private void Draw()
        {
            int cnt = 0;
            for (int i = 0; i < width; i++)
            {
                if(i%2== 0)
                for (int j = 0; j < height; j++)
                {
                        Console.SetCursorPosition(i*4, j);
                        Out(cnt++);
                }
                else
                for (int j = width-1;j >=0; j--)
                {
                        Console.SetCursorPosition(i*4,j);
                        Out(cnt++);
                }
            }
        }
        public void Start()
        {
            AskUserMeasures();
            Draw();
            Console.ReadLine();
        }
    }
}
