﻿#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <algorithm>
#include <random>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
#include "problem7.h"
#include "problem8.h"
using namespace std;

int main()
{
  setlocale(LC_CTYPE, "Russian");
  srand(time(NULL));
  //problem1(); // ОБЯЗАТЕЛЬНО ЗАГЛЯНИТЕ В ЭТУ ЗАДАЧУ!!!!!!!!!! это уникальная задача
  //problem1_1(); // ОБЯЗАТЕЛЬНО ЗАГЛЯНИТЕ В ЭТУ ЗАДАЧУ!!!!!!!!!!

  //homework
  //problem2();
  //problem3();
  //problem3_1(); // мой метод транспонировки.
  //problem4(); // перемножение матриц.
  //problem5();
  //problem6();
  //problem7(); // дополнительная задача
  //problem8(); // дополнительная задача

  cout << "\nend! . . . . .. . . . . . . .\n";
}

