<?php
$binary = isset($_POST["binary"]) ? @$_POST["binary"] : null;
$hex = "";
$binarylen = (int) (strlen($binary) / 4);
for ($i = strlen($binary) - 4, $j = 0; $j < $binarylen; $j++, $i -= 4) {
    $substr = substr($binary, $i, 4);
    switch ($substr) {
        case "0000":
            $hex = "0" . $hex;
            break;
        case "0001":
            $hex = "1" . $hex;
            break;
        case "0010":
            $hex = "2" . $hex;
            break;
        case "0011":
            $hex = "3" . $hex;
            break;
        case "0100":
            $hex = "4" . $hex;
            break;
        case "0101":
            $hex = "5" . $hex;
            break;
        case "0110":
            $hex = "6" . $hex;
            break;
        case "0111":
            $hex = "7" . $hex;
            break;
        case "1000":
            $hex = "8" . $hex;
            break;
        case "1001":
            $hex = "9" . $hex;
            break;
        case "1010":
            $hex = "A" . $hex;
            break;
        case "1011":
            $hex = "B" . $hex;
            break;
        case "1100":
            $hex = "C" . $hex;
            break;
        case "1101":
            $hex = "D" . $hex;
            break;
        case "1110":
            $hex = "E" . $hex;
            break;
        case "1111":
            $hex = "F" . $hex;
            break;
        default:
            $hex .= "Error";
            break;
    }
}
if ($binarylen != strlen($binary) / 4) {
    $substr = substr($binary, 0, strlen($binary) % 4);
    $hex = bindec($substr) . $hex;
}


//---------------------
$num = isset($_POST["rome"]) ? @$_POST["rome"] : null;
$rome = "";
if ($num != null) {
    $length = strlen($num);
    $num = strrev($num);
    for ($i = 0; $i < $length; $i++) {
        switch ($i) {
            case 0:
                switch ($num[$i]) {
                    case 3:
                        $rome .= "I";
                    case 2:
                        $rome .= "I";
                    case 1:
                        $rome .= "I";
                        break;
                    case 4:
                        $rome .= "VI";
                        break;
                    case 5:
                        $rome .= "V";
                        break;
                    case 6:
                        $rome .= "IV";
                        break;
                    case 7:
                        $rome .= "IIV";
                        break;
                    case 8:
                        $rome .= "IIIV";
                        break;
                    case 9:
                        $rome .= "XI";
                        break;
                }
                break;
            case 1:
                switch ($num[$i]) {
                    case 3:
                        $rome .= "X";
                    case 2:
                        $rome .= "X";
                    case 1:
                        $rome .= "X";
                        break;
                    case 4:
                        $rome .= "LX";
                        break;
                    case 5:
                        $rome .= "L";
                        break;
                    case 6:
                        $rome .= "XL";
                        break;
                    case 7:
                        $rome .= "XXL";
                        break;
                    case 8:
                        $rome .= "XXXL";
                        break;
                    case 9:
                        $rome .= "CX";
                        break;
                }
                break;
            case 2:
                switch ($num[$i]) {
                    case 3:
                        $rome .= "C";
                    case 2:
                        $rome .= "C";
                    case 1:
                        $rome .= "C";
                        break;
                    case 4:
                        $rome .= "DC";
                        break;
                    case 5:
                        $rome .= "D";
                        break;
                    case 6:
                        $rome .= "CD";
                        break;
                    case 7:
                        $rome .= "CCD";
                        break;
                    case 8:
                        $rome .= "CCCD";
                        break;
                    case 9:
                        $rome .= "MC";
                        break;
                }
                break;
            case 3:
                switch ($num[$i]) {
                    case 3:
                        $rome .= "M";
                    case 2:
                        $rome .= "M";
                    case 1:
                        $rome .= "M";
                        break;
                    case 4:
                        $rome .= "_VM";
                        break;
                    case 5:
                        $rome .= "_V";
                        break;
                    case 6:
                        $rome .= "M_V";
                        break;
                    case 7:
                        $rome .= "MM_V";
                        break;
                    case 8:
                        $rome .= "MMM_V";
                        break;
                    case 9:
                        $rome .= "_XM";
                        break;
                }
                break;
            case 4:
                switch ($num[$i]) {
                    case 3:
                        $rome .= "_X";
                    case 2:
                        $rome .= "_X";
                    case 1:
                        $rome .= "_X";
                        break;
                    case 4:
                        $rome .= "_L_X";
                        break;
                    case 5:
                        $rome .= "_L";
                        break;
                    case 6:
                        $rome .= "_X_L";
                        break;
                    case 7:
                        $rome .= "_X_X_L";
                        break;
                    case 8:
                        $rome .= "_X_X_X_L";
                        break;
                    case 9:
                        $rome .= "_C_X";
                        break;
                }
                break;
            case 5:
                switch ($num[$i]) {
                    case 3:
                        $rome .= "_C";
                    case 2:
                        $rome .= "_C";
                    case 1:
                        $rome .= "_C";
                        break;
                    case 4:
                        $rome .= "_D_C";
                    case 5:
                        $rome .= "_D";
                        break;
                    case 6:
                        $rome .= "_C_D";
                        break;
                    case 7:
                        $rome .= "_C_C_D";
                        break;
                    case 8:
                        $rome .= "_C_C_C_D";
                        break;
                    case 9:
                        $rome .= "_M_C";
                        break;
                }
                break;
            case 6:
                switch ($num[$i]) {
                    case 9:
                        $rome .= "_M";
                    case 8:
                        $rome .= "_M";
                    case 7:
                        $rome .= "_M";
                    case 6:
                        $rome .= "_M";
                    case 5:
                        $rome .= "_M";
                    case 4:
                        $rome .= "_M";
                    case 3:
                        $rome .= "_M";
                    case 2:
                        $rome .= "_M";
                    case 1:
                        $rome .= "_M";
                        break;
                }
                break;
            default:
                $rome .= "~";
                $i = $length;
                break;
        }
    }
    $rome = strrev($rome);
}

//---------------------------
$rev = isset($_POST["rev"]) ? @$_POST["rev"] : null;
if ($rev != null) {
    $length = strlen($rev);
    $temp = "";
    for ($i = $length - 1; $i >= 0; $i--) {
        $temp .= $rev[$i];
    }
    $rev = $temp;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <hr>
    <form action="index.php" method="post">
        <div>
            input binary:
            <input type="text" name="binary">
            <button type="submit">Check</button>
            <p>
                <?= "Result = " . $hex ?>
            </p>
        </div>
    </form>
    <hr>
    <div>
        <?php
        $mirror = 0;
        $even = 0;
        $odd = 0;
        $rising = 0;
        $evenNum = 0;
        $oddNum = 0;
        for ($i = 1000; $i < 10000; $i++) {
            $num = (string) $i;
            if (substr($i, 0, 2) == strrev(substr($i, 2, 2)))
                $mirror++;
            if ($num[0] % 2 == 0 && $num[1] % 2 == 0 && $num[2] % 2 == 0 && $num[3] % 2 == 0)
                $even++;
            if ($num[0] % 2 == 1 && $num[1] % 2 == 1 && $num[2] % 2 == 1 && $num[3] % 2 == 1)
                $odd++;
            if ($i % 2 == 0)
                $evenNum++;
            else
                $oddNum++;
            if ($num[0] > $num[1] && $num[1] > $num[2] && $num[2] > $num[3])
                $rising++;
        }
        echo "В опсиании задания опечатка связанная с четностью цифр. в ответе указано колличество четных чисел а не колличество чисел с четными цифрами <br>";
        echo "Mirrored: " . $mirror . "<br>";
        echo "Even: " . $even . "<br>";
        echo "Odd: " . $odd . "<br>";
        echo "Rising: " . $rising . "<br>";
        echo "Even num" . $evenNum . "<br>";
        echo "Odd num" . $oddNum . "<br>";
        ?>
    </div>
    <hr>
    <form action="index.php" method="post">
        <input type="number" name="rome">
        <button type="submit">Translate</button>
        <p>
            <?= $rome ?>
        </p>
    </form>
    <hr>
    <div>
        <?php
        $arr = [];
        for ($i = 0; $i < 100; $i++) {
            $arr[] = rand(0, 10000);
        }
        $max = $arr[0];
        $min = $arr[0];
        for ($i = 1; $i < 100; $i++) {
            $max = $arr[$i] > $max ? $arr[$i] : $max;
            $min = $arr[$i] < $min ? $arr[$i] : $min;
        }
        echo "Min = " . $min;
        echo "<br>Max = " . $max;
        ?>
    </div>
    <hr>
    <form action="index.php" method="post">
        <input type="number" name="rev">
        <button type="submit">reverse</button>
        <?= "Reverse result: " . $rev ?>
    </form>
    <hr>
    <div>
        <?php
        $date = date("m");
        switch ($date) {
            case 1:
            case 3:
            case 8:
            case 12:
            case 5:
            case 7:
            case 10:
                $length = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                $length = 30;
                break;
            case 2:
                if(date("L"))$length = 29;
                else $length = 28;
                break;
        }
        $isPrint = false;
        for($i = 1; $i <= $length; $i++, $isPrint = false){
            if($i>=10){
                $temp = (string)$i;
                if($i==11 || $i == 22)$isPrint = true;
                if($temp[0]%2 ==0 && $temp[1]%2 == 0 || $temp[0]%2 == 1 && $temp[1]%2 == 1) $isPrint = true;
                if($temp[0]>$temp[1])$isPrint = true;
            }else $isPrint = true;
            if($isPrint){
                $Day = date_create(date("y-m-$i"))->format("D");
                if($i == date("d")) echo "<div class='currentday'>";
                if($Day == "Sat" || $Day == "Sun") echo "<p style='color:red'>$i</p>";
                else echo "$i<br>";
                if($i == date("d")) echo "</div>";
            }
        }
        ?>
        <style>
            .currentday{
                width:fit-content;
                border: 1px solid red;
                border-radius: 100%;
            }
        </style>
    </div>
    <hr>
</body>

</html>