﻿#include <iostream>
#include <iomanip>
#include <algorithm> 
#include "problem1.h"
#include "problem2.h"
using namespace std;

int main()
{
  setlocale(LC_CTYPE, "Russian");
  problem1(); //задания из homework8


  /*все комплексные аудиторные задачи были решены в аудитории.*/ 
  problem2();   // сортировка A,B,C,D используя циклы.          НАСТОЯТЕЛЬНО РЕКОМЕНДУЮ ВЗГЛЯНУТЬ!!!!!!!!!!!!!!!!!!
  problem2_1(); // сортировка A,B,C,D используя цикл и функции. НАСТОЯТЕЛЬНО РЕКОМЕНДУЮ ВЗГЛЯНУТЬ!!!!!!!!!!!!!!!!!!
  problem2_2(); // сортировка через массив и sort
  cout << "\nend! . .. . .. .. \n";
}
