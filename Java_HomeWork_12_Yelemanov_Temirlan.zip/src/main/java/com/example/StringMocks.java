package com.example;

import java.util.Arrays;
import java.util.List;

public class StringMocks {
    public static final List<String> vowel = List.of("a","e","i","o","w","y","u");
    public static final List<String> consonants = List.of("q", "r","t","p","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m");
    public static boolean isPolindrom(String str){ return str.substring(0, str.length()%2 == 1? str.length()/2+1 : str.length()/2).equals(Arrays.asList(str.substring(str.length()/2).split("")).reversed().stream().reduce((a,b)->a+b).get());}
    public static int VowelCount(String str){ return (int)Arrays.asList(str.toLowerCase().split("")).stream().filter(s -> vowel.stream().anyMatch(s::contains)).count();}
    public static int ConsonantCount(String str){ return (int)Arrays.asList(str.toLowerCase().split("")).stream().filter(s -> consonants.stream().anyMatch(s::contains)).count();}
    public static int WordPresenceCount(String line, String word){ return (int)Arrays.asList(line.split(" ")).stream().map(String::toLowerCase).filter(str-> str.contains(word.toLowerCase())).count();}
}
