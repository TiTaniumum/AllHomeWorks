package com.example;

public class Shapes {
    public static float AreaTriangle(float a, float b, float c){
        float p = (a + b + c)/2;
        return (float)Math.sqrt(p*(p-a)*(p-b)*(p-c));
    }

    public static float AreaRect(float a, float b){
        return a*b;
    }

    public static float AreaSquare(float a, float b){
        return a*b;
    }
    public static float AreaRhomb(float d1, float d2){
        return d1*d2/2;
    }
}
