package com.example;

public class MoneyExchange {
    public static float DollarToTenge(float dollars){
        return dollars * 442.31f;
    }    
    public static float TengeToDollar(float tenge){
        return tenge * 0.0023f;
    }
}
