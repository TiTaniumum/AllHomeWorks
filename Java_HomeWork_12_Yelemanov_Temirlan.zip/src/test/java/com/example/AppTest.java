package com.example;
import org.junit.Assert;
import org.junit.Test;

public class AppTest 
{
    @Test
    public void AreaOfShapes()
    {
        Assert.assertEquals(6, Shapes.AreaTriangle(3, 4, 5), 0);
        Assert.assertEquals(12, Shapes.AreaRect(3, 4), 0);
        Assert.assertEquals(12, Shapes.AreaSquare(3, 4), 0);
        Assert.assertEquals(6, Shapes.AreaRhomb(3, 4), 0);
    }

    @Test
    public void CurrencyExchange(){
        Assert.assertEquals(4423.11f, MoneyExchange.DollarToTenge(10), 0.01f);
        Assert.assertEquals(2.3f, MoneyExchange.TengeToDollar(1000), 0f);
    }

    @Test
    public void StringTests(){
        Assert.assertEquals(true, StringMocks.isPolindrom("TENET"));
        Assert.assertEquals(false, StringMocks.isPolindrom("Hello world!"));
        Assert.assertEquals(4,StringMocks.VowelCount("Hello world"));
        Assert.assertEquals(6,StringMocks.ConsonantCount("Hello world"));
        Assert.assertEquals(2,StringMocks.WordPresenceCount("Hello World! My name is Temirlan, my age is 24", "My"));
    }

    //остальное не стал делать так как задания однообразные.
}
