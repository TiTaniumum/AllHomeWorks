import { StatusBar } from "expo-status-bar";
import { Pressable, StyleSheet, Text, View } from "react-native";
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const RootStack = createNativeStackNavigator();

import { FinancesProvider } from "./FinancesContext";
import Home from "./pages/Home";
import Add from "./pages/Add";

export default function App() {
  return (
    <FinancesProvider>
      <NavigationContainer>
        <RootStack.Navigator>
          <RootStack.Group>
            <RootStack.Screen
              name="Home"
              component={Home}
              options={({ navigation }) => ({
                headerRight: () => (
                  <Pressable style={styles.button} onPress={() => navigation.navigate("Add")}>
                    <Text style={{color: "white", fontWeight: 700, fontSize: 18}}>+ Добавить расход</Text>
                  </Pressable>
                ),
              })}
            />
          </RootStack.Group>
          <RootStack.Group screenOptions={{ presentation: "modal" }}>
            <RootStack.Screen
              name="Add"
              component={Add}
              options={({ navigation }) => ({})}
            />
          </RootStack.Group>
        </RootStack.Navigator>
      </NavigationContainer>
    </FinancesProvider>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  button: {
    padding:10,
    borderRadius: 100,
    backgroundColor: '#00bfff',
    alignItems: 'center',
    justifyContent: 'center'
  }
});