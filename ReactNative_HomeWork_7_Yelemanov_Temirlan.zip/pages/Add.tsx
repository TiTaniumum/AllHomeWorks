import React, { useState } from "react";
import { View, TextInput, Button, StyleSheet, Platform, Alert } from "react-native";
import { useFinances } from "../FinancesContext";

export default function Add({ navigation }: any) {
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState((new Date()).toLocaleDateString());

  const { addFinance } = useFinances();
  function handleAddFinance() {
    //console.log(new Date(date));
    if (name && amount && date && !isNaN((new Date(date)).getTime())) {
      addFinance(name, parseFloat(amount), (new Date(date)).getTime());
      navigation.goBack();
    }else{
      console.log(name, amount, date);
        if(Platform.OS === 'web'){
            alert("Введите вид расходов и сумму");
        }else{
            Alert.alert("Ошибка","Введите вид расходов и сумму");
        }
    }
  }
  return (
    <View>
        <TextInput placeholder="Вид расхода" value={name} onChangeText={setName}/>
        <TextInput placeholder="Сумма" value={amount} onChangeText={setAmount} keyboardType="numeric"/>
        <TextInput placeholder='Дата' value={date} onChangeText={setDate}/>
        <Button title="Добавить" onPress={handleAddFinance}/>
    </View>
  )
}
