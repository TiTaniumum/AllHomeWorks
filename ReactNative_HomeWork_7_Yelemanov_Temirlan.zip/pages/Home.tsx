import React, { useState } from "react";
import {
  View,
  Text,
  Button,
  FlatList,
  StyleSheet,
  TextInput,
} from "react-native";
import { Currency, Finance, useFinances } from "../FinancesContext";

function RenderItem(
  item: Finance,
  AmountByCurrency: (currency: Currency) => string,
  removeFinance: (id: string | number[]) => void,
  prepareToEdit: (finance: Finance) => void
) {
  function formatDate(timestamp: number) {
    const date = new Date(timestamp);
    const day = date.getDate().toString().padStart(2, "");
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const year = date.getFullYear();
    return `${day}.${month}.${year}`;
  }
  return (
    <View>
      <View style={styles.item}>
        <Text> {item.name}: {AmountByCurrency(item.amount)} | </Text>
        <Text>{formatDate(item.date)}</Text>
      </View>

      <View style={styles.item}>
        <Button
          title="Редактировать"
          onPress={() => {
            prepareToEdit(item);
          }}
        />
        <Button title="Удалить" onPress={() => removeFinance(item.id)} />
      </View>
    </View>
  );
}

function EditFinance(
  finance: Finance,
  amount: string,
  setAmount: (amount: string) => void,
  setIsEdit: (isEdited: boolean) => void
) {
  return (
    <View style={styles.edit}>
      <Text>Изменение финанса: {finance.name}</Text>
      <TextInput
        placeholder="..."
        style={styles.input}
        value={amount}
        onChangeText={setAmount}
      />
      <Button
        title="Готово"
        onPress={() => {
          finance.amount = parseFloat(amount);
          setIsEdit(false);
        }}
      />
    </View>
  );
}

export default function Home({ navigation }: any) {
  const [isEdit, setIsEdit] = useState(false);
  const [selectedFinance, setSelectedFinance] = useState<Finance | null>(null);
  const [amount, setAmount] = useState("");
  const { finances } = useFinances();
  const { setCurrency } = useFinances();
  const { removeFinance } = useFinances();
  const { AmountByCurrency } = useFinances();

  function prepareToEdit(item: Finance) {
    console.log(item);
    setSelectedFinance(item);
    setAmount(item.amount + "");
    setIsEdit(true);
  }

  return (
    <View style={styles.container}>
      <FlatList
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 20,
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
          gap: 10,
        }}
        data={finances}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) =>
          RenderItem(item, AmountByCurrency, removeFinance, prepareToEdit)
        }
      />
      <View style={styles.footer}>
        <Button title="Тенге" onPress={() => setCurrency(Currency.TENGE)} />
        <Button title="Доллары" onPress={() => setCurrency(Currency.USD)} />
      </View>

      {isEdit && selectedFinance
        ? EditFinance(selectedFinance, amount, setAmount, setIsEdit)
        : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  item: {
    flexDirection: "row",
  },
  footer: {
    width: "100%",
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 5,
    borderTopColor: "#e6e6e6",
    borderTopWidth: 1,
  },
  edit: {
    position: "absolute",
    width: "90%",
    height: "80%",
    backgroundColor: "white",
    borderRadius: 30,
    padding: 10,
    borderWidth: 1,
    borderColor: "black",
    justifyContent: "center",
    alignItems: "center",
    gap: 10,
  },
  input: {
    borderColor: "black",
    borderWidth: 1,
    padding: 5,
    width: "100%",
    borderRadius: 10,
  },
});
