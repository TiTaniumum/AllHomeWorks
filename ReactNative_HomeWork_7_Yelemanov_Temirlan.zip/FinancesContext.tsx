import React, {
  createContext,
  useState,
  useContext,
  useEffect,
  ReactNode,
  Children,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import uuid from "react-native-uuid";
import { View } from "react-native";

export enum Currency {
  USD,
  TENGE,
}

export type Finance = {
  id: string | number[];
  name: string;
  amount: number;
  date: number;
};

type FinancesContext = {
  finances: Finance[];
  currency: Currency;
  addFinance: (name: string, amount: number, date: number) => void;
  removeFinance: (id: string | number[]) => void;
  AmountByCurrency: (currency: Currency) => string;
  setCurrency: (currency: Currency)=>void;
};

const FinanceContext = createContext<FinancesContext>({} as FinancesContext);

export function FinancesProvider({ children }: { children: ReactNode }) {
  const [finances, setFinances] = useState<Finance[]>([]);
  const [currency, setCurrency] = useState(Currency.TENGE);

  useEffect(() => {
    async function loadFinances() {
      try {
        const jsonFinances = await AsyncStorage.getItem("finances");
        if (jsonFinances) {
          setFinances(JSON.parse(jsonFinances));
        }
      } catch (ex) {
        console.error("FinancesContext::AsyncStorage: ", ex);
      }
    }
    loadFinances();
  }, []);

  useEffect(() => {
    async function saveFinances() {
      await AsyncStorage.setItem("finances", JSON.stringify(finances));
    }
    saveFinances();
  }, [finances]);

  function addFinance(name: string, amount: number, date: number) {
    setFinances([
      ...finances,
      {
        id: uuid.v4(),
        name,
        amount,
        date,
      },
    ]);
  }

  function removeFinance(id: string | number[]) {
    setFinances(finances.filter((finance) => finance.id !== id));
  }

  function AmountByCurrency(amount: number) {
    switch (currency) {
      case Currency.TENGE:
        return amount.toFixed(3) + " ₸";
      case Currency.USD:
        return (amount / 453).toFixed(3) + " $";
    }
  }

  return (
    <FinanceContext.Provider
      value={{
        finances,
        currency,
        addFinance,
        removeFinance,
        AmountByCurrency,
        setCurrency
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
}

export function useFinances() {
  const context = useContext(FinanceContext);
  if (context === undefined) {
    throw new Error("useFinances должен использовать FinanceProvider");
  }
  return context;
}
