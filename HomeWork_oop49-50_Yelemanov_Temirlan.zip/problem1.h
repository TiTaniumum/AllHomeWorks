#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <list>
#include <algorithm>
#include <list>
#include <iomanip>
using namespace std;
#define RAND(min, max) min+rand()%(max - (min) +1)
struct LC { LC() { srand(time(NULL)); } ~LC() { cout << "\nEND . . . . . . . .\n"; cin.get(); } }_;

enum Group {
  A1,A2,A3,
  B1,B2,B3,
  C1,C2,C3,
  GroupLenght
};

string getRandString(int length) {
  string temp;
  temp = char(RAND('A', 'Z'));
  for (size_t i = 0; i < length-1; i++)
  {
    temp += RAND('a', 'z');
  }
  return temp;
}

#define MARKSLENGTH 20

class Student {
  string Name;
  Group group;
  vector<int> marks;
  int average;
public:
  Student():Name(), group(), marks(), average(){
    
    RandomInit();
   
  }
  void RandomInit() {
    Name = getRandString(RAND(5, 10));
    group = Group(rand() % GroupLenght);
    marks.resize(20);
    int sum = 0;
    for (size_t i = 0; i < marks.size(); i++)
    {
      //marks[i] = RAND(6,12);
      marks[i] = RAND(1, 12);
      sum += marks[i];
    }
    average = sum / marks.size();
  }
  friend ostream& operator<<(ostream& os, const Student& S) {
    os << setw(11) << S.Name << " | Group: " << S.group << " : ";
    for (size_t i = 0; i < S.marks.size(); i++)
    {
      os << S.marks[i] << " ";
    }
    return os;
  }
  bool isBadStudent() {

    if (average <= 6) { return true; }
    else return false;


    int cnt(0);
    for (size_t i = 0; i < marks.size(); i++)
    {
      if (marks[i] <= 3)cnt++;
    }
    if (cnt >= (marks.size() / 2)) { return true; }
    else return false;
  }
  bool isGreateStudent() {

    if (average > 6) { return true; }
    else return false;


    int cnt(0);
    for (size_t i = 0; i < marks.size(); i++)
    {
      if (marks[i] >= 9)cnt++;
    }
    if (cnt >= ((marks.size() / 4) + (marks.size()/2)) )return true;
    else return false;
  }
};

using StIter = typename list<Student>::iterator;

void problem1() {
  list<Student> StList;
  cout << "type in Student Count: ";
  int length;
  cin >> length;
  for (size_t i = 0; i < length; i++)
  {
    Student temp;
    StList.push_back(temp);
  }
  for (auto& s: StList)
  {
    cout << s;
    cout << endl;
  }
  cout << endl; 
  cout << "Bad Students: \n";
  for (auto&s : StList)
  {
    if (s.isBadStudent()) {
      cout << s;
      cout << endl;
    }
  }
  cout << "\nGreate Students: \n";
  for (auto& s: StList)
  {
    if (s.isGreateStudent()) {
      cout << s;
      cout << endl;
    }
  }
  cout << endl;
}