#include "problem1.h"

int main() {
  problem1();
}