<?php 
class Product{
    public string $name;
    public int $count;
    public int $price;
    public function __construct(string $name, int $count, int $price){
        $this->name = $name;
        $this->count = $count;
        $this->price = $price;
    }
    public function ToString(){
        return "Product:: name->".$this->name.", count->".$this->count.", price->".$this->price.", total->".($this->count*$this->price);
    }
}
?>