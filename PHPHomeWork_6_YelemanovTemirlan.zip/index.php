<?php
require_once("ProductContainer.php");
$productContainer = ProductContainer::Deserialize();
if (isset($_POST["buttonClick"]) && $_POST["buttonClick"] == "add") {
    if (isset($_POST["name"]) && isset($_POST["count"]) && isset($_POST["price"])) {
        $product = new Product($_POST["name"], $_POST["count"], $_POST["price"]);
        ProductContainer::SerializeOne($product);
    }
}
if (isset($_POST["buttonClick"]) && $_POST["buttonClick"] == "clear") {
    ProductContainer::ClearJSON();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class=FormContainer>
        <form action="index.php" method=post class=>
            <input type="text" placeholder="name" name=name><br>
            <input type="number" placeholder="count" name=count><br>
            <input type="number" placeholder="price" name=price><br>
            <button type=submit name=buttonClick value=add>Add Item</button>
            <button type=submit name=buttonClick value=clear>Clear</button>
            <button type=submit name=buttonClick value=get>Get Ticket</button>
        </form>
    </div>
    <hr>
    <?php if (isset($_POST["buttonClick"]) && $_POST["buttonClick"] == "get"): ?>
        <ul>
            <?php foreach ($productContainer->products as $product): ?>
                <li><?= $product->ToString(); ?></li>
            <?php endforeach; ?>
        </ul>
        <hr>
    <?php endif; ?>
</body>

</html>

<style>
    * {
        margin: 0px;
        padding: 0px;
    }

    ul {
        padding-left: 25px;
        background-color: lightgray;
    }
    ul li{
        font-size: 20px;
        padding-top: 5px;
        padding-bottom: 5px;
    }
    .FormContainer{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>