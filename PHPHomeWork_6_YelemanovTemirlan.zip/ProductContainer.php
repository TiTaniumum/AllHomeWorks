<?php 
require_once("Product.php");
class ProductContainer{
    public array $products = [];
    public function __construct(array $products){
        $this->products = $products;
    }
    public function Add(Product $product){
        $this->products[] = $product;
    }
    public static function SerializeArray(array $products){
        $Arr = json_decode(file_get_contents("products.json"));
        foreach($products as $product){
            $Arr[] = $product;
        }
        file_put_contents("products.json", json_encode($Arr));
    }
    public static function SerializeOne(Product $product){
        $arr = [];
        $arr[] = $product;
        ProductContainer::SerializeArray($arr);
    }
    public static function Deserialize(){
        $Arr = json_decode(file_get_contents("products.json"));
        $result = new ProductContainer([]);
        foreach($Arr as $product){
            $result->Add( new Product($product->name, $product->count, $product->price));
        }
        return $result;
    }
    public static function ClearJSON(){
        file_put_contents("products.json", "[]");
    }
}
?>