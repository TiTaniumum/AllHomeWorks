<?php 
class Controller_ProductList extends Controller{
    public function __construct(){
        $this->model = new Model_ProductList;
        parent::__construct();
    }

    public function action_index(){
        $products = $this->model->getData();
        $this->view->generate("product_view.php","productList_view.php",$products);
    }
}
?>