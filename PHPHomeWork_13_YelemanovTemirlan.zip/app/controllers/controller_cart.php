<?php 
class Controller_cart extends Controller{
    public function __construct(){
        $this->model = new Model_cart;
        parent::__construct();
    }
    public function action_index(){
        $this->model->getData();
        $this->view->generate("","",$this->model);
    }
}

?>