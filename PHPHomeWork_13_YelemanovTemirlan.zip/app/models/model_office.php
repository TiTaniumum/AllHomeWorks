<?php 

class Model_office implements ICreatable{
    public int $officeId;
    public string $city;
    public string $phone;
    public string $addressLine1;
    public string $addressLine2;
    public string $state;
    public string $country; 
    public string $postalCode; 
    public string $territory;
    public function Create($row){
        //code ....
    }
}
?>