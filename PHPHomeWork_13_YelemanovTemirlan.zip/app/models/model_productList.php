<?php 
require_once("app/models/model_product.php");
class Model_ProductList implements Model{
    public function getData(){
        $sql = "select productId, productName, buyPrice from products;";
        $products = Database::getAll($sql);
        return Model_ProductList::GetList($products);
    }
    public static function GetList($products){
        $productList = [];
        foreach($products as $product){
            $p = new Model_Product();
            $p->Create($product);
            $productList[] = $p;
        }
        return $productList;   
    }
}
?>