<link rel="stylesheet" href="assets/shop.css">
<form action="http://localhost/Temirlan/PHP/HomeWork13/shop/performTransaction" method=post class=cart id=cart>
    <p>Cart:</p>
    <button type=submit>Buy</button>
    <p>Choose Customer:</p>
    <?php include("app/views/$view");?>
    <p>Added Products:</p>
    <div class=productList name=productlist id=cartproductlist>
    </div>
</form>