<select name="customerList" id="customerList">
    <?php foreach($data as $customer):?>
        <?php include("app/views/customer_view.php");?>
    <?php endforeach;?>
</select>