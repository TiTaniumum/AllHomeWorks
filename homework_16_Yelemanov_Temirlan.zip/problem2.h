﻿#pragma once
using namespace std;

//Problem 00 - knightMoves
//Напишите функцию knightMoves, принимающую координаты клетки шахматной доски(x: 1 - 8, y : 1 - 8) и возвращающую количество возможных ходов коня с данной клетки.
//Используя данную функцию, распечатайте диаграмму шахматной доски с указанием количества возможных ходов с каждой клетки.

int knightMoves(int x, int y) {
  int cnt = 0;
  if (x + 2 < 8 && y + 1 < 8) cnt++;
  if (x + 2 < 8 && y - 1 >= 0) cnt++;
  if (x - 2 >= 0 && y + 1 < 8) cnt++;
  if (x - 2 >= 0 && y - 1 >= 0) cnt++;
  if (y + 2 < 8 && x + 1 < 8) cnt++;
  if (y + 2 < 8 && x - 1 >= 0) cnt++;
  if (y - 2 >= 0 && x + 1 < 8) cnt++;
  if (y - 2 >= 0 && x - 1 >= 0) cnt++;
  return cnt;
}
// ▓ 178
// ░ 176
void printLine(int i, int length) {
  if (i % 2 == 1)
    for (size_t j = 1; j <= length; j++)
    {
      if (j % 2 == 1) cout << char(178) << char(178) << char(178) << char(178) << char(178) << char(178);
      else cout << char(176) << char(176) << char(176) << char(176) << char(176) << char(176);
    }
  else 
    for (size_t j = 1; j <= length; j++)
    {
      if (j % 2 == 1)cout << char(176) << char(176) << char(176) << char(176) << char(176) << char(176);
      else cout << char(178) << char(178) << char(178) << char(178) << char(178) << char(178);
    }
  cout << "\n";
}

void print(int i, int x, int y) {
  if (x % 2 == 1)
    if (y % 2 == 1) cout << char(178) << char(178) << " " << i << char(178) << char(178);
    else cout << char(176) << char(176) << " " << i << char(176) << char(176);
  else
    if (y % 2 == 1) cout << char(176) << char(176) << " " << i << char(176) << char(176);
    else cout << char(178) << char(178) << " " << i << char(178) << char(178);
}

void problem2() {
  const int length = 8;
  int arr[length][length]{};
  for (size_t i = 0; i < length; i++)
  {
    for (size_t j = 0; j < length; j++)
    {
      arr[i][j] = knightMoves(i, j);
    }
  }
  for (size_t i = 0; i < length; i++)
  {
    printLine(i+1, length);
    for (size_t j = 0; j < length; j++)
    {
      print(arr[i][j], i+1, j+1);
    }
    cout << "\n";
    printLine(i+1, length);
  }
}