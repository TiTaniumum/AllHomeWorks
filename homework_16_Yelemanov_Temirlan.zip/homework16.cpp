﻿#include <iostream>
#include <algorithm>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
using namespace std;

int main()
{
  //problem1(); // усложненная
  //problem2(); // усложненная
  problem3(); // дз
  cout << "\nend! . . . . .. . . . \n";
}