#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <random>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"

using namespace std;

int main() {
  //problem1();
  //problem2();
  //problem3();
  //problem4();
  //problem5();
  problem6();
  cout << "\nEND  . . . . . . . . . . . . . . . . \n";
  cin.get(), cin.get();
}