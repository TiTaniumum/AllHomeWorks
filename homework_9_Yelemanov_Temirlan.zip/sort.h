#pragma once
using namespace std;

//���������� �����.

void sort() {
  int a, b, c, d, i = 0;
  int temp;
  cin >> a >> b >> c >> d;
  while (i < 3) {
    if (a < b) {
      temp = b;
      b = a;
      a = temp;
    }
    if (b < c) {
      temp = c;
      c = b;
      b = temp;
    }
    if (c < d) {
      temp = c;
      c = d;
      d = temp;
    }
    i++;
  }
  cout << a << " " << b << " " << c << " " << d << "\n";
}

void sort_() {
  int a, b, c, d;
  int temp;
  cin >> a >> b >> c >> d;
  if (a < b) {
    temp = b;
    b = a;
    a = temp;
  }
  if (b < c) {
    temp = c;
    c = b;
    b = temp;
  }
  if (c < d) {
    temp = c;
    c = d;
    d = temp;
  }
  if (a < b) {
    temp = b;
    b = a;
    a = temp;
  }
  if (b < c) {
    temp = c;
    c = b;
    b = temp;
  }
  if (c < d) {
    temp = c;
    c = d;
    d = temp;
  }
  if (a < b) {
    temp = b;
    b = a;
    a = temp;
  }
  if (b < c) {
    temp = c;
    c = b;
    b = temp;
  }
  if (c < d) {
    temp = c;
    c = d;
    d = temp;
  }
  cout << a << " " << b << " " << c << " " << d << "\n";
}
