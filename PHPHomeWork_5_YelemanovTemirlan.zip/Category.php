<?php 
require_once("Product.php");
class Category{
    public string $name;
    public $filters=[];
    public $listProducts= [];
    public function __construct(string $name, $filters){
        $this->name = $name;
        $this->filters = $filters;
        $this->filters[] = "Price";
    }
    public static function AddProduct(array $categoryList,string $categoryName,Product $product){
        foreach($categoryList as $category){
            if($category->name == $categoryName){
                $category->listProducts[]=$product;
                break;
            }
        }
    }
    public static function GetCategory(array $categoryList, string $categoryName){
        foreach($categoryList as $category){
            if($category->name == $categoryName){
                return $category;
            }
        }
        return null;
    }
}
?>