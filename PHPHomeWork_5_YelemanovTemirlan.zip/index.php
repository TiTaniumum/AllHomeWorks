<?php
require_once("PhoneCategory.php");
require_once("MonitorCategory.php");

$categories = [];
$categories["Phone"] = new PhoneCategory();
$categories["Monitor"] = new MonitorCategory();
$productPhones = [];
$productMonitors = [];
$productPhones[] = new Phone("IPhone 1", "16Mb", "1", "64Mb", "Mac");
$productPhones[] = new Phone("IPhone 2", "32Mb", "1", "128Mb", "Mac");
$productPhones[] = new Phone("IPhone 3", "64Mb", "1", "256Mb", "Mac");
$productMonitors[] = new Monitor("Lenovo D27-40", "27", "75Mhz");
$productMonitors[] = new Monitor("Lenovo G24-20", "23.8", "144Mhz");
$productMonitors[] = new Monitor("Lenovo L24i-30", "23.8", "75Mhz");

foreach ($productPhones as $product) {
    Category::AddProduct($categories, "Phone", $product);
}
foreach ($productMonitors as $product) {
    Category::AddProduct($categories, "Monitor", $product);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <form action="index.php" method=post>
        <div class=CategoryContainer>
            <ul>
                <?php foreach ($categories as $category): ?>
                    <li>
                        <button class="CategoryButton <?php if(isset($_POST["buttonClick"]) && $_POST["buttonClick"] == $category->name):?>blue<?php endif;?>" 
                                type=submit 
                                name=buttonClick 
                                value=<?= $category->name ?>>
                                <?= $category->name ?>
                        </button>
                    </li>
                <?php endforeach; ?>
            </ul>
            <?php if (isset($_POST["buttonClick"])): ?>
                <?php $category = Category::GetCategory($categories, $_POST["buttonClick"]);?>
                <ol>
                    <?php foreach ($category->listProducts as $product): ?>
                        <li><?=$product->ToString();?></li>
                    <?php endforeach; ?>
                </ol>
            <?php endif; ?>
        </div>
    </form>
</body>

</html>