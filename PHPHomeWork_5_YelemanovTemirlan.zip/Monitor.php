<?php require_once("Product.php");
class Monitor extends Product{
    public string $diagonal;
    public string $frequency;
    public function __construct(string $name,string $diagonal, string $frequency){
        $this->diagonal = $diagonal;
        $this->frequency = $frequency;
        parent::__construct($name);
    }
    #[Product]
    public function ToString(){
        return parent::ToString().", Diagonal->".$this->diagonal.", Frequency->".$this->frequency;
    }
}
?>