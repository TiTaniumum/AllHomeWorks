<?php 
require_once("Product.php");

class Phone extends Product{
    public string $ram;
    public string $SimCount;
    public string $MemoryCapacity;
    public string $OS;
    public function __construct(string $name, string $ram, string $SimCount, string $MemoryCapacity, string $OS){
        $this->ram = $ram;
        $this->SimCount = $SimCount;
        $this->MemoryCapacity = $MemoryCapacity;
        $this->OS = $OS;
        parent::__construct($name);
    }
    #[Product]
    public function ToString(){
        return parent::ToString().", Ram->".$this->ram.", Sim Count->".$this->SimCount.", Memory Capacity->".$this->MemoryCapacity.", OS->".$this->OS;
    }
}
?>