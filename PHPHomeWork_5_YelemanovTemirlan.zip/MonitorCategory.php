<?php 
require_once("Category.php");
require_once("Monitor.php");
class MonitorCategory extends Category{
    public function __construct(){
        $filters = [];
        $filters[] = "Diagonal";
        $filters[] = "Frequency";
        parent::__construct("Monitor",$filters);
    }
}
?>