<?php 
require_once("Category.php");
require_once("Phone.php");
class PhoneCategory extends Category{
    public function __construct(){
        $filters = [];
        $filters[] = "Ram";
        $filters[] = "CountSim";
        $filters[] = "Hdd";
        $filters[] = "OS";
        parent::__construct("Phone", $filters);
    }
}
?>