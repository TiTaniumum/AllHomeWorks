<?php 
require_once("API.php");

if(isset($_GET["id"])){
    API::getCustomerByID((int)$_GET["id"]);
}
?>