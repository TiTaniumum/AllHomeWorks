async function getJson(url){
    let response = await fetch(url);
    let promise = await response.json();
    return promise
}

window.onload  = (event) =>{
    let select = document.querySelector("select#salesRepemployeeId")
    getJson("getEmployees.php").then(employees=>{
        employees.forEach(employee => {
            let option = document.createElement("option");
            option.value = employee.employeeId;
            option.innerText = `${employee.employeeId} - ${employee.firstName} ${employee.lastName}`;
            select.append(option);
        });
    })
    let select3 = document.querySelector("select#productLine");
    getJson("getProductLines.php").then(productlines=>{
        productlines.forEach(productline=>{
            let option = document.createElement("option");
            option.value = productline.productLine;
            option.innerText = productline.productLine;
            select3.append(option);
        });
    });
    let form = document.querySelector("form#addCustomer");
    form.onsubmit = (event)=>{
        event.preventDefault();
        let formData = new FormData(form);
        //console.log(Object.fromEntries(formData.entries()));
        let formObj = Object.fromEntries(formData.entries());
        console.log(formObj);
        sendForm(form.action, form.method, formObj).then(response=>{
            console.log(response);
        })
    }
    let form2 = document.querySelector("form#addOffice")
    form2.onsubmit = (event)=>{
        event.preventDefault();
        let formData = new FormData(form2);
        let formObj = Object.fromEntries(formData.entries());
        console.log(formObj);
        sendForm(form2.action, form2.method, formObj).then(response=>{
            console.log(response);
        })
    }
    let form3 = document.querySelector("form#addProduct");
    form3.onsubmit = (event)=>{
        event.preventDefault();
        let formData = new FormData(form3);
        let formObj = Object.fromEntries(formData.entries());
        console.log(formObj);
        sendForm(form3.action, form3.method, formObj).then(response=>{
            console.log(response);
        });

    }
}

async function sendForm(url, method = "get", formData) {
    let response = await fetch(url, {
        "method": method,
        body: JSON.stringify(formData),
        headers: {
            "Content-type": "application/json; charset=utf-8"
        }
    });
    let promise = await response.json();
    return promise;
}