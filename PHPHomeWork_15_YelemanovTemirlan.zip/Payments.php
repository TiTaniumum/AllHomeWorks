<?php 
class Payments {
    public int $customerId;
    public string $checkNumber; 
    public DateTime $paymentDate; 
    public float $amount;

    public function getCustomerId(){
        return $this->customerId;
    }
    public function getCheckNumber(){
        return $this->checkNumber;
    }
    public function getPaymentDate(){
        return $this->paymentDate;
    }
    public function getAmount(){
        return $this->amount;
    }
    public function Create($row){
        $this->customerId = $row->customerId;
        $this->checkNumber = $row->checkNumber;
        $this->paymentDate = $row->paymentDate;
        $this->amount = $row->amount;
    }
}
?>