<?php
require_once("Database.php");
class API
{
    public static function getCustomers()
    {
        require_once("Customer.php");

        $sql = "select * from customers;";
        $customers = Database::getAll($sql);
        $array = [];
        foreach ($customers as $customer) {
            $array[] = new Customer($customer);
        }
        header("Content-type: application/json; charset=utf-8");
        echo json_encode($array);
    }

    public static function getCustomerByID($id)
    {
        require_once("Customer.php");
        $customer = new Customer($id);
        header("Content-type: application/json; charset=utf-8");
        echo json_encode($customer);
    }
    public static function getEmployees()
    {
        $sql = "SELECT * FROM employees";
        $employees = Database::getAll($sql);
        header("Content-type: application/json; charset=utf-8");
        echo json_encode($employees, JSON_PRETTY_PRINT);
    }

    public static function getProductLines(){
        $sql = "SELECT * FROM productLines";
        $employees = Database::getAll($sql);
        header("Content-type: application/json; charset=utf-8");
        echo json_encode($employees, JSON_PRETTY_PRINT);
    }

    public static function getOrders(){
        require_once("Orders.php");
        if(isset($_GET["id"])){
            $sql = "SELECT * FROM orders WHERE orderId = ?;";
            $order = Database::getRow($sql, $_GET["id"]);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($order, JSON_PRETTY_PRINT);
        }else{
            $sql = "SELECT * FROM orders;";
            $orders = Database::getAll($sql);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($orders, JSON_PRETTY_PRINT);
        }
    }
    public static function getPayments(){
        require_once("Payments.php");
        if(isset($_GET["id"])){
            $sql = "SELECT * FROM payments WHERE customerId = ?;";
            $payment = Database::getRow($sql, $_GET["id"]);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($payment, JSON_PRETTY_PRINT);
        }else{
            $sql = "SELECT * FROM payments;";
            $payments = Database::getAll($sql);
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($payments, JSON_PRETTY_PRINT);
        }
    }
    public static function insertCustomer()
    {
        $data = json_decode(file_get_contents("php://input"));

        $sql = "INSERT INTO customers(
            addressLine1,
            addressLine2,
            city,
            contactFirstName,
            contactLastName,
            country,
            customerName,
            phone,
            postalCode,
            salesRepemployeeId,
            state) values(:addressLine1,:addressLine2,:city,:contactFirstName,:contactLastName,:country,:customerName,:phone,:postalCode,:salesRepemployeeId,:state);";

        $array = [];
        $array["addressLine1"] = $data->addressLine1;
        $array["addressLine2"] = $data->addressLine2;
        $array["city"] = $data->city;
        $array["contactFirstName"] = $data->contactFirstName;
        $array["contactLastName"] = $data->contactLastName;
        $array["country"] = $data->country;
        $array["customerName"] = $data->customerName;
        $array["phone"] = $data->phone;
        $array["postalCode"] = $data->postalCode;
        $array["salesRepemployeeId"] = $data->salesRepemployeeId !== "0" ? (int) $data->salesRepemployeeId : null;
        $array["state"] = $data->state;

        Database::insert($sql, $array);

        header("Content-type: application/json; charset=utf-8");
        echo "[]";
    }
    public static function insertOffice()
    {
        $data = json_decode(file_get_contents("php://input"));

        $sql = "INSERT INTO offices(
        officeId,
        city,
        phone,
        addressLine1,
        addressLine2,
        state,
        country,
        postalCode,
        territory) VALUES(
        :officeId,
        :city,
        :phone,
        :addressLine1,
        :addressLine2,
        :state,
        :country,
        :postalCode,
        :territory)";

        $array = [];
        $array["officeId"] = $data->officeId;
        $array["city"] = $data->city;
        $array["phone"] = $data->phone;
        $array["addressLine1"] = $data->addressLine1;
        $array["addressLine2"] = $data->addressLine2;
        $array["state"] = $data->state;
        $array["country"] = $data->country;
        $array["postalCode"] = $data->postalCode;
        $array["territory"] = $data->territory;

        Database::insert($sql, $array);
        header("Content-type: application/json; charset=utf-8");
        echo "[]";
    }
    public static function insertProduct()
    {
        $data = json_decode(file_get_contents("php://input"));
        $sql = "INSERT INTO products(
        productId,
        productName,
        productLine,
        productScale,
        productVendor,
        productDescription,
        quantityInStock,
        buyPrice,
        MSRP)
        values
        (
        :productId,
        :productName,
        :productLine,
        :productScale,
        :productVendor,
        :productDescription,
        :quantityInStock,
        :buyPrice,
        :MSRP
        )";
        $array = [];
        $array["productId"] = $data->productId;
        $array["productName"] = $data->productName;
        $array["productLine"] = $data->productLine;
        $array["productScale"] = $data->productScale;
        $array["productVendor"] = $data->productVendor;
        $array["productDescription"] = $data->productDescription;
        $array["quantityInStock"] = $data->quantityInStock;
        $array["buyPrice"] = $data->buyPrice;
        $array["MSRP"] = $data->MSRP;
        Database::insert($sql, $array);
        header("Content-type: application/json; charset=utf-8");
        echo "[]";
    }
}
?>