<?php 
require_once("Database.php");
require_once("Customer.php");
$sql = "select * from customers;";
$customers = Database::getAll($sql);

$array = [];

foreach($customers as $customer){
    $array[]= new Customer($customer);
}

header("Content-type: application/json; charset=utf-8");
echo json_encode($array);
?>