<?php 
require_once("UserController.php");
session_start();
$user = UserController::GetAuthorizedUser();
if($user == null)header("Location: auth.php");
if(isset($_POST["buttonClick"])){
    UserController::EditUser($user);
}
?>

<a href="profile.php"><-- Go back</a>

<form action="edit.php" method=post>
    <input type="text" placeholder="Full name" name=fullName> <br>
    <input type="text" placeholder="login" name=login><br>
    <input type="text" placeholder="pic url" name=pic><br>
    <input type="text" placeholder="email" name=email><br>
    <button type=submit name=buttonClick value=edituser>save</button>
</form>