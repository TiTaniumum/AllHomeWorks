<?php
require_once("User.php");
class UserController
{
    public static function Create()
    {
        $login = isset($_POST["login"]) ? $_POST["login"] : null;
        $password = isset($_POST["password"]) ? $_POST["password"] : null;
        $email = isset($_POST["email"]) ? $_POST["email"] : null;
        $fullName = isset($_POST["fullName"]) ? $_POST["fullName"] : null;
        $pic = isset($_POST["pic"]) ? $_POST["pic"] : null;
        $registrationDate = date("Y-m-d H:i:s");
        if ($login != null && $password != null && $email != null && $fullName != null && $pic != null) {
            $user = new User($login, $password, $fullName, $registrationDate, $pic, $email);
            return $user;
        } else
            return null;
    }
    public static function UserLoginExists(string $login): bool
    {
        $Arr = json_decode(file_get_contents("Users.json"));
        foreach ($Arr as $key => $value) {
            if ($value->login == $login) {
                return true;
            }
        }
        return false;
    }
    public static function UserExists(User $user): bool
    {
        $Arr = json_decode(file_get_contents("Users.json"));
        foreach ($Arr as $key => $value) {
            if ($value->login == $user->login || $value->email == $user->email) {
                return true;
            }
        }
        return false;
    }
    public static function Checks(User $user)
    {
        $passwordCheck = isset($_POST["passwordCheck"]) ? $_POST["passwordCheck"] : null;
        if (
            $user->login == null ||
            $user->password == null ||
            $user->email == null ||
            $user->fullName == null ||
            $passwordCheck == null
        )
            return "Error: Not All fields are filled!";
        if ($user->password != $passwordCheck)
            return "Error: Passwords are not matching!";
        if (UserController::UserExists($user))
            return "Error: Such user exists! Try another login and email";
        return true;
    }
    public static function Register($user)
    {
        if ($user == null)
            return "";
        $result = UserController::Checks($user);
        if ($result === true) {
            UserController::Serialize($user);
            return "Success!";
        } else {
            return $result;
        }
    }
    public static function Serialize(User $user)
    {
        $Arr = json_decode(file_get_contents("Users.json"));
        $user->id = count($Arr);
        $Arr[] = $user;
        file_put_contents("Users.json", json_encode($Arr));
    }
    private static function Deserialize(): array{
        $Arr = json_decode(file_get_contents("Users.json"));
        $users = [];
        foreach ($Arr as $User) {
            $tempuser = new User($User->login, $User->password, $User->fullName, $User->registrationDate, $User->pic, $User->email);
            $tempuser->id = $User->id;
            $users[] = $tempuser;
        }
        return $users;
    }
    public static function Authorize()
    {
        $loginAuth = isset($_POST["loginAuth"]) ? $_POST["loginAuth"] : null;
        $passwordAuth = isset($_POST["passwordAuth"]) ? $_POST["passwordAuth"] : null;
        $userAuthorized = null;
        if ($loginAuth != null && UserController::UserLoginExists($loginAuth)) {
            $userAuthorized = UserController::AuthorizeUser($loginAuth, $passwordAuth);
        }
        if ($userAuthorized != null) {
            $_SESSION["user"] = $userAuthorized->login;
        }
    }
    public static function AuthorizeUser($login, $password){
        $user = null;
        $Arr = json_decode(file_get_contents("Users.json"));
        foreach ($Arr as $key => $value)
        {
            if($value->login == $login && $value->password == $password){
                $user = $value;
                break;
            }
        }
        return $user;
    }
    public static function GetAuthorizedUser(){
        if(!isset($_SESSION["user"]) || $_SESSION["user"] == null){
            return null;
        }
        $users = UserController::Deserialize();
        foreach ($users as $key => $value){
            if($value->login == $_SESSION["user"])
            return $value;
        }
        return null;
    }
    public static function EditUser(User $user){
        $arr = json_decode(file_get_contents("users.json"));
        if(isset($_POST["fullName"]) && $_POST["fullName"] != ""){
            foreach ($arr as $key => $value){
                if($value->login == $user->login){
                    $value->fullName = $_POST["fullName"];
                    break;
                }
            }
        }
        if(isset($_POST["email"])&& $_POST["email"] != ""){
            foreach ($arr as $key => $value){
                if($value->login == $user->login){
                    $value->email = $_POST["email"];
                    break;
                }
            }
        }
        if(isset($_POST["pic"])&& $_POST["pic"] != ""){
            foreach ($arr as $key => $value){
                if($value->login == $user->login){
                    $value->pic = $_POST["pic"];
                    break;
                }
            }
        }
        if(isset($_POST["login"])&& $_POST["login"] != ""){
            foreach ($arr as $key => $value){
                if($value->login == $user->login){
                    $value->login = $_POST["login"];
                    $_SESSION["user"] = $_POST["login"];
                    break;
                }
            }
        }
        file_put_contents("Users.json", json_encode($arr));
    }
}
?>