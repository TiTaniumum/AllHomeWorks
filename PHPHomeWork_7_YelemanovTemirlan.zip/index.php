<?php
session_start();

if(isset($_POST["text"])){
    setcookie("text", $_POST["text"], time()+ 1*24*60*60);
    setcookie("time", date("Y-m-d H:i:s"), time()+ 1*24*60*60);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

<a href="reg.php">Register</a><br>
<a href="auth.php">Athorize</a><br>
<a href="profile.php">Profile</a><br>
<br>
<hr>
<br>
<form action="index.php" method=post>
    <input type="text" placeholder="Type anything you want..." name=text>
    <button type=submit>save</button>
</form>
<?php if(isset($_COOKIE["text"])):?>
    <p>Your input: <?=$_COOKIE["text"];?></p>
    <p>Date of input: <?=$_COOKIE["time"];?></p>
    <?php endif;?>
</body>

</html>