<?php 
require_once("UserController.php");
session_start();
if(isset($_POST["buttonClick"])){
    unset($_SESSION["user"]);
}
$user = UserController::GetAuthorizedUser();
if($user == null)header("Location: auth.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <main>
        <a href="index.php"><-- Go Back</a>
        <div class=user>
            <div class=userinfo>
                <p>Full name: <?=$user->fullName?></p>
                <p>Login: <?=$user->login?></p>
                <p>Registration date: <?=$user->registrationDate?></p>
                <p>Email: <?=$user->email?></p>
            </div>
            <div class=userpic>
                <img src="<?=$user->pic?>" alt="No picture">
            </div>
        </div>
        <form action="profile.php" method="post">
            <a href="edit.php">Edit Profile</a>
            <button type=submit name=buttonClick value=unauthorize>Unauthorize</button>
        </form>
    </main>
</body>
</html>