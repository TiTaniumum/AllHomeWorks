<?php 
class User{
    public int $id;
    public string $login;
    public string $password;
    public string $fullName;
    public string $registrationDate;
    public string $pic;
    public string $email;
    public function __construct(string $login, string $password, string $fullName, string $registrationDate, string $pic, string $email)
    {
        $this->id = 0;
        $this->registrationDate = $registrationDate;
        $this->login = $login;
        $this->password = $password;
        $this->fullName = $fullName;
        $this->pic = $pic;
        $this->email = $email;
    }
}
?>