<?php
require_once("UserController.php");
session_start();
UserController::Authorize();
?>

<a href="index.php"><-- Go back</a>
<form action="auth.php" method="post">
    Authorization:
    <input type="text" name="loginAuth" placeholder="login">
    <input type="text" name="passwordAuth" placeholder="password">
    <button type="submit">Authorize</button> <br>
    <?php if (isset($_SESSION["user"])): ?>
        <p>
            <?= "Authorized as " . @$_SESSION["user"]; ?>
        </p>
    <?php endif; ?>
</form>