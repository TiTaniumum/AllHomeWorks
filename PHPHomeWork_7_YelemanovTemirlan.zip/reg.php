<?php 
require_once("UserController.php");
$user = UserController::Create();
?>
<a href="index.php"><-- Go back</a><br><br>
<form action="reg.php" method ="post">
    <input type="text" name="fullName" placeholder="fullName"> <br>
    <input type="text" name="login" placeholder="login"> <br>
    <input type="password" name="password" placeholder="password"> 
    <input type="password" name="passwordCheck" placeholder="repeat password"> <br>
    <input type="text" name="email" placeholder="email"><br>
    <input type="text" name="pic" placeholder="img url..."> <br>
    <button>Register</button>
</form>
<p><?=UserController::Register($user);?></p>