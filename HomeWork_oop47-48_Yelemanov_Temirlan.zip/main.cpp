#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
int main() {
  //problem1();
  //problem2();
  problem3();
}