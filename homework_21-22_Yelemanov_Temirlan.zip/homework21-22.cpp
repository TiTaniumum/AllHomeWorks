﻿#include <iostream> // печатаю их всех что бы не забывать о них
#include <iomanip>
#include <random>
#include <stdlib.h>
#include <algorithm>
#include <chrono>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
using namespace std;



int main()
{
  srand(time(NULL));
  //problem1();
  //problem2();
  //problem3(); // перегрузку функции я воспринял по другому 
  //problem4();
  //problem5();

  //problem6(); // доп задание из классных задачь
  cout << "\nend! . . .. . . . . . . . . . .\n";
}