﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace winformsWPF12
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public FontInfo fontInfo = new FontInfo();
        public Window1()
        {
            InitializeComponent();
            InitFonts();
        }
        private void InitFonts()
        {
            foreach(FontFamily font in Fonts.SystemFontFamilies)
            {
                fontPicker.Items.Add(font);
            }
            fontPicker.SelectedIndex = 0;
        }
        public void SetFontInfo(FontInfo fontinfo)
        {
            this.fontInfo = fontinfo;
            buttonBackground.Background = fontInfo.backgroundColor;
            buttonForeground.Foreground = fontInfo.foregroundColor;
            textBlockSize.Text = fontInfo.fontSize.ToString();
            for(int i = 0; i< fontPicker.Items.Count; i++)
            {
                if (fontPicker.Items[i] == fontInfo.font)
                {
                    fontPicker.SelectedIndex = i;
                }
            }
            textBlockSample.Background = fontInfo.backgroundColor;
            textBlockSample.Foreground = fontInfo.foregroundColor;
            textBlockSample.FontFamily = fontInfo.font;
            textBlockSample.FontSize = fontInfo.fontSize;
        }

        private void buttonBackground_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ColorDialog colorDialog = new System.Windows.Forms.ColorDialog();
            if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                buttonBackground.Background = new SolidColorBrush(Color.FromArgb(colorDialog.Color.A, colorDialog.Color.R, colorDialog.Color.G, colorDialog.Color.B));
                fontInfo.backgroundColor = buttonBackground.Background;
                textBlockSample.Background = fontInfo.backgroundColor;
            }
        }

        private void buttonForeground_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ColorDialog colorDialog = new System.Windows.Forms.ColorDialog();
            if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                buttonForeground.Foreground = new SolidColorBrush(Color.FromArgb(colorDialog.Color.A, colorDialog.Color.R, colorDialog.Color.G, colorDialog.Color.B));
                fontInfo.foregroundColor = buttonForeground.Foreground;
                textBlockSample.Foreground = buttonForeground.Foreground;
            }
        }

        private void buttonPlus_Click(object sender, RoutedEventArgs e)
        {
            int size = int.Parse(textBlockSize.Text);
            if (size>=100) return;
            textBlockSize.Text = (++size).ToString();
            UpdateFontSize();
        }

        private void buttonMinus_Click(object sender, RoutedEventArgs e)
        {
            int size = int.Parse(textBlockSize.Text);
            if (size<=0) return;
            textBlockSize.Text = (--size).ToString();
            UpdateFontSize();
        }
        private void UpdateFontSize()
        {
            fontInfo.fontSize = double.Parse(textBlockSize.Text);
            textBlockSample.FontSize = fontInfo.fontSize;
        }

        private void fontPicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            fontInfo.font = fontPicker.SelectedItem as FontFamily;
            textBlockSample.FontFamily = fontInfo.font;
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            (Owner as MainWindow).SetFontInfo(fontInfo);
        }
    }
}
