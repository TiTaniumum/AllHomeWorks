﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace winformsWPF12
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private string fileName = string.Empty;

        private FontInfo fontInfo = new FontInfo();
        public MainWindow()
        {
            InitializeComponent();
            fontInfo.font = textBlock.FontFamily;
            fontInfo.fontStyle = textBlock.FontStyle;
            fontInfo.backgroundColor = textBlock.Background;
            fontInfo.foregroundColor = textBlock.Foreground;
            fontInfo.fontWeight = textBlock.FontWeight;
            fontInfo.fontStyle = textBlock.FontStyle;
            fontInfo.fontSize = textBlock.FontSize;
        }

        private void menuItem1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt";
            if(openFileDialog.ShowDialog() == true)
            {
                textBlock.Text = File.ReadAllText(openFileDialog.FileName);
                fileName = openFileDialog.FileName;
            }
        }

        private void menuItem3_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.SetFontInfo(fontInfo);
            window1.Owner = this;
            window1.ShowDialog();
        }

        public void SetFontInfo(FontInfo fontInfo)
        {
            this.fontInfo = fontInfo;
            textBlock.FontSize = this.fontInfo.fontSize;
            textBlock.FontFamily = this.fontInfo.font;
            textBlock.Background = this.fontInfo.backgroundColor;
            textBlock.Foreground = this.fontInfo.foregroundColor;
        }

        private void menuItem2_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text file (*.txt)|*.txt";
            if(saveFileDialog.ShowDialog() == true)
            {
                File.WriteAllText( saveFileDialog.FileName, textBlock.Text );
            }
        }
    }
}
