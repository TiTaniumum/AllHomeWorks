﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace winformsWPF12
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
    public class FontInfo
    {
        public FontFamily font { get; set; }
        public FontStyle fontStyle { get; set; }
        public FontWeight fontWeight { get; set; }
        public FontStretch fontStretch { get; set; }
        public Brush backgroundColor { get; set; }
        public Brush foregroundColor { get; set; }
        public double fontSize { get; set; }

        public FontInfo()
        {
        }
    }
}
