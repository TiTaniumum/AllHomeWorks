﻿#pragma once
using namespace std;

//Заполните массив из десяти элементов значениями, вводимыми с клавиатуры в ходе выполнения программы.

void problem1() {
	const int n = 5;
	int arr[n];
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}
	for (int i = 0; i < n; i++) {
		cout << arr[i] << " ";
	}
}

//Problem_00 fillArray
//Заполните массив из пятнадцати элементов случайным образом :
//а) вещественными значениями, лежащими в диапазоне от 0 до 1;
//б) вещественными значениями х(22 ≤ х < 23);
//в) вещественными значениями х(0 ≤ х < 10);
//г) вещественными значениями х(–50 ≤ х < 50);
//д) целыми значениями, лежащими в диапазоне от 0 до 10 включительно.

void problem1_1() {
	const int n = 15;
	double arr[n];
	double min=0, max=1;
	srand(time(NULL));
	for (int i = 0; i < n; i++) {
		arr[i] = min + (double)rand() / RAND_MAX * (max - min);
	}
	for (int i = 0; i < n; i++) {
		cout << arr[i] << " ";
	}
}

void problem1_2() {
	const int n = 15;
	double arr[n];
	double min = 22, max = 23;
	srand(time(NULL));
	for (int i = 0; i < n; i++) {
		arr[i] = min + (double)rand() / RAND_MAX * (max - min);
	}
	for (int i = 0; i < n; i++) {
		cout << arr[i] << " ";
	}
}


void problem1_3() {
	const int n = 15;
	int arr[n]{};
	//int min = 0, max = 10;
	srand(time(NULL));
	for (int i = 0; i < 10; i++) {
		arr[i] = rand();
	}
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}
}

//Problem_00
//Напишите программу, которая выводит одномерный массив в обратном порядке.

void problem1_4() {
	const int length = 10;
	int arr[length]{};
	srand(time(NULL));
	for (size_t i = 0; i < length; i++)
	{
		arr[i] = rand();
	}
	for (size_t i = 0; i < length; i++)
	{
		cout << arr[i] << " ";
	}
	for (int64_t i = 9; i >= 0 ; i--)
	{
		cout << arr[i] << " ";
	}
}