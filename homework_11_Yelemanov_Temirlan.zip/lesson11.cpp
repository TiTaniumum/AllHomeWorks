﻿#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "problem1.h"
#include "problem2.h"
#include "problem3.h"
#include "problem4.h"
#include "problem5.h"
#include "problem6.h"
#include "problem7.h"
#include "sort.h"
#include "problem8.h"
#include "problem9.h"
#include "problem10.h"
#include "problem11.h"
#include "problem12.h"
#include "problem13.h"

using namespace std;

int main()
{
    setlocale(LC_CTYPE, "Russian");
    //задачи решенные в аудитории
    //problem1();
    //problem1_1();
    //problem1_2();
    //problem1_3();
    //problem1_4();
    //problem2();
    //problem3();
    //problem4();
    //problem5();
    //problem6();
    //problem7(); //усложненная
    //sort();

    //homework --------------
    //problem8(); //дз
    //problem9(); //дз
    //problem10(); // не решенное в аудитории простая 
    //problem11(); // не решенное в аудитории простая
    //problem12(); // усложненная
    problem13(); // усложненная 
    cout << "\nend! . . . . . . . . . .\n";
}

